-- ============================================================
--  KI'AD Barbershop booking system - CLEAN INSTALL
--  Made 2026-10-06 18:46 by tools/export-for-hosting.php
--  Import this ONE file into an empty database (phpMyAdmin -> Import).
--  It has every table, the settings, services and staff logins,
--  but no customers, bookings or other test data.
-- ============================================================

SET NAMES utf8mb4;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `work_date` date NOT NULL,
  `clock_in` datetime NOT NULL,
  `clock_out` datetime DEFAULT NULL,
  `late_minutes` int(11) NOT NULL DEFAULT 0,
  `edited_by_owner` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`attendance_id`),
  UNIQUE KEY `staff_day` (`staff_id`,`work_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `cust_id` int(255) NOT NULL AUTO_INCREMENT,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`cust_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `holiday`;
CREATE TABLE `holiday` (
  `holiday_date` date NOT NULL,
  `note` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`holiday_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `login_attempt`;
CREATE TABLE `login_attempt` (
  `attempt_id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) NOT NULL,
  `username` varchar(255) NOT NULL,
  `attempted_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`attempt_id`),
  KEY `ip_time` (`ip`,`attempted_at`),
  KEY `user_time` (`username`,`attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `payroll`;
CREATE TABLE `payroll` (
  `payroll_id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `month` char(7) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `note` varchar(255) NOT NULL DEFAULT '',
  `paid_at` datetime DEFAULT NULL,
  PRIMARY KEY (`payroll_id`),
  UNIQUE KEY `staff_month` (`staff_id`,`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `receipt`;
CREATE TABLE `receipt` (
  `receipt_ID` int(255) NOT NULL AUTO_INCREMENT,
  `cust_id` int(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time(6) NOT NULL,
  `notes` text NOT NULL,
  `total` decimal(8,2) DEFAULT NULL,
  `payment_method` varchar(10) DEFAULT NULL,
  `payment_proof` varchar(255) DEFAULT NULL,
  `payment_status` varchar(10) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `barber_id` int(11) DEFAULT NULL,
  `job_status` varchar(10) NOT NULL DEFAULT 'booked',
  `chosen_barber` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`receipt_ID`),
  KEY `cust_id` (`cust_id`),
  KEY `barber_date` (`barber_id`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `receipt_item`;
CREATE TABLE `receipt_item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_ID` int(11) NOT NULL,
  `service_name` varchar(100) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `receipt_ID` (`receipt_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `review`;
CREATE TABLE `review` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `receipt_ID` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `barber_id` int(11) NOT NULL,
  `stars` tinyint(1) NOT NULL,
  `comment` varchar(500) NOT NULL DEFAULT '',
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`review_id`),
  UNIQUE KEY `receipt` (`receipt_ID`),
  KEY `barber` (`barber_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `service`;
CREATE TABLE `service` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `name` varchar(50) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'staff',
  `is_barber` tinyint(1) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp(),
  `start_time` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`staff_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `setting` (`name`, `value`) VALUES ('attendance_secret', '');
INSERT INTO `setting` (`name`, `value`) VALUES ('closed_days', '');
INSERT INTO `setting` (`name`, `value`) VALUES ('close_time', '22:00');
INSERT INTO `setting` (`name`, `value`) VALUES ('kiosk_key', '');
INSERT INTO `setting` (`name`, `value`) VALUES ('late_grace_minutes', '5');
INSERT INTO `setting` (`name`, `value`) VALUES ('login_bg', 'video');
INSERT INTO `setting` (`name`, `value`) VALUES ('login_bg_dim', '20');
INSERT INTO `setting` (`name`, `value`) VALUES ('logo_image', 'images/logo.png');
INSERT INTO `setting` (`name`, `value`) VALUES ('map_embed', '');
INSERT INTO `setting` (`name`, `value`) VALUES ('open_time', '10:00');
INSERT INTO `setting` (`name`, `value`) VALUES ('policy_privacy', 'We keep your username, email and bookings so you can make appointments and see your receipts.\n\nPayment receipts you upload are only used by the shop to check your payment.\n\nWe do not sell or share your details with anyone else.\n\nYour password is stored in a protected (hashed) form. Nobody at the shop can see it.\n\nTo delete your account, contact the shop on WhatsApp.');
INSERT INTO `setting` (`name`, `value`) VALUES ('policy_terms', 'Please arrive a few minutes before your booking time. If you are late, the barber may need to serve the next customer first.\n\nTo cancel or change a booking, contact the shop on WhatsApp as early as possible.\n\nOnline payments are checked by the shop before your appointment. If a payment receipt cannot be verified, the booking may be cancelled.\n\nPrices are in Malaysian Ringgit (RM). The price shown on your receipt is the price you pay.');
INSERT INTO `setting` (`name`, `value`) VALUES ('qr_image', 'images/qr-payment.png');
INSERT INTO `setting` (`name`, `value`) VALUES ('shop_address', 'No 46, Kampung Matang Bonglai Kecil, Ayer Hitam, Kedah');
INSERT INTO `setting` (`name`, `value`) VALUES ('shop_phone', '+6014-259 7948');
INSERT INTO `setting` (`name`, `value`) VALUES ('slot_minutes', '30');
INSERT INTO `setting` (`name`, `value`) VALUES ('social_facebook', '');
INSERT INTO `setting` (`name`, `value`) VALUES ('social_instagram', '');
INSERT INTO `setting` (`name`, `value`) VALUES ('social_twitter', '');
INSERT INTO `setting` (`name`, `value`) VALUES ('whatsapp_number', '60142597948');

INSERT INTO `service` (`service_id`, `name`, `price`, `image`) VALUES ('1', 'Haircut', '15.00', 'images/services/haircut.jpg');
INSERT INTO `service` (`service_id`, `name`, `price`, `image`) VALUES ('2', 'Low Fade', '18.00', 'images/services/low-fade.jpg');
INSERT INTO `service` (`service_id`, `name`, `price`, `image`) VALUES ('3', 'Mid Fade', '18.00', 'images/services/mid-fade.jpg');
INSERT INTO `service` (`service_id`, `name`, `price`, `image`) VALUES ('4', 'High Fade', '20.00', 'images/services/high-fade.jpg');
INSERT INTO `service` (`service_id`, `name`, `price`, `image`) VALUES ('5', 'Buzz Cut', '12.00', 'images/services/buzz-cut.jpg');
INSERT INTO `service` (`service_id`, `name`, `price`, `image`) VALUES ('6', 'Pompadour', '25.00', 'images/services/pompadour.jpg');
INSERT INTO `service` (`service_id`, `name`, `price`, `image`) VALUES ('7', 'Kids Haircut', '10.00', 'images/services/kids-haircut.jpg');
INSERT INTO `service` (`service_id`, `name`, `price`, `image`) VALUES ('8', 'Beard Trim', '8.00', 'images/services/beard-trim.jpg');
INSERT INTO `service` (`service_id`, `name`, `price`, `image`) VALUES ('9', 'Haircut + Wash + Beard', '30.00', 'images/services/haircut-wash-beard.jpg');

INSERT INTO `staff` (`staff_id`, `name`, `username`, `password_hash`, `role`, `is_barber`, `active`, `created_at`, `start_time`) VALUES ('1', 'Admin', 'admin', '$2y$10$Y/mvSBVb2EbF0TJU87N4n.z61m7gPlcV1PQXLj1v5VWu5AhU19Mhq', 'owner', '0', '1', '2026-09-24 00:40:34', NULL);
INSERT INTO `staff` (`staff_id`, `name`, `username`, `password_hash`, `role`, `is_barber`, `active`, `created_at`, `start_time`) VALUES ('2', 'Barber 1', 'barber1', '$2y$10$mxVBCpkmIsQNbkkYFaJ/v.mlHdgEb0YUIT9RV5m6/GzxLUQ.ut7q.', 'staff', '1', '1', '2026-09-24 00:40:34', NULL);
INSERT INTO `staff` (`staff_id`, `name`, `username`, `password_hash`, `role`, `is_barber`, `active`, `created_at`, `start_time`) VALUES ('3', 'Barber 2', 'barber2', '$2y$10$UBNz9z9PiUa8PoFH.kQ4Ku0YR5Dv1GKgCgOjkqp0EjyHnoiNtPL5.', 'staff', '1', '1', '2026-09-24 00:40:34', NULL);
INSERT INTO `staff` (`staff_id`, `name`, `username`, `password_hash`, `role`, `is_barber`, `active`, `created_at`, `start_time`) VALUES ('4', 'Barber 3', 'barber3', '$2y$10$ccCBQh8v82KZfm5u45knRuWkovgpLt6y0G7arhSB3ct4l/wyj.Fza', 'staff', '1', '1', '2026-09-24 00:40:34', NULL);

