<?php
// Customer passwords.
// Old accounts stored the password as plain text; they are switched to a hash the next time they log in.

function customer_password_ok($conn, $customer, $password) {
    $stored = $customer['password'];
    $is_hash = password_get_info($stored)['algoName'] !== 'unknown';
    $ok = $is_hash ? password_verify($password, $stored) : hash_equals($stored, $password);

    if ($ok && (!$is_hash || password_needs_rehash($stored, PASSWORD_DEFAULT))) {
        set_customer_password($conn, $customer['cust_id'], $password, 0);
    }
    return $ok;
}

// $must_change = 1 when the owner gives a temporary password
function set_customer_password($conn, $cust_id, $password, $must_change) {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = mysqli_prepare($conn, "UPDATE customer SET password = ?, must_change_password = ? WHERE cust_id = ?");
    mysqli_stmt_bind_param($stmt, 'sii', $hash, $must_change, $cust_id);
    mysqli_stmt_execute($stmt);
}

// Shop WhatsApp link with a message already typed in
function whatsapp_link($conn, $message) {
    $number = preg_replace('/\D/', '', setting($conn, 'whatsapp_number'));
    return 'https://wa.me/' . $number . '?text=' . rawurlencode($message);
}
