<?php
include __DIR__ . '/../bootstrap.php';

// Only log out the staff account, a customer session in the same browser stays
unset($_SESSION['staff_id'], $_SESSION['csrf']);

header("Location: ../Login.php");
exit();
