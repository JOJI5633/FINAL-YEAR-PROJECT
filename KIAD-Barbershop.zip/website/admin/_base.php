<?php
// Loaded by every /admin page (including the login page)
include __DIR__ . '/../bootstrap.php';

function e($text) {
    return htmlspecialchars((string)$text, ENT_QUOTES);
}

// Message shown once on the next page
function flash($message, $type = 'success') {
    $_SESSION['flash'] = [$type, $message];
}

function payment_badge($method, $status) {
    $badges = [
        'cash'     => ['bg-secondary', 'Cash at shop'],
        'pending'  => ['bg-warning text-dark', 'Waiting check'],
        'verified' => ['bg-success', 'Paid'],
        'rejected' => ['bg-danger', 'Rejected'],
    ];
    if (!isset($badges[$status])) {
        return '<span class="text-muted">-</span>';
    }
    return '<span class="badge ' . $badges[$status][0] . '">' . $badges[$status][1] . '</span>';
}

function job_badge($status) {
    $badges = [
        'booked'    => ['bg-light text-dark border', 'Booked'],
        'done'      => ['bg-dark', 'Done'],
        'cancelled' => ['bg-danger', 'Cancelled'],
    ];
    [$class, $label] = $badges[$status] ?? ['bg-light text-dark', $status];
    return '<span class="badge ' . $class . '">' . $label . '</span>';
}

// A random secret kept in the setting table, created the first time it is needed
function secret_setting($conn, $name, $renew = false) {
    static $made = [];
    if (isset($made[$name]) && !$renew) {
        return $made[$name];
    }
    $value = setting($conn, $name);
    if ($value === '' || $renew) {
        $value = bin2hex(random_bytes(16));
        $stmt = mysqli_prepare($conn, "REPLACE INTO setting (name, value) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, 'ss', $name, $value);
        mysqli_stmt_execute($stmt);
    }
    return $made[$name] = $value;
}

// Full link to a page in /admin, using the address the browser used to reach us
// (so a QR made on http://192.168.1.5:8095 also works from a phone on the same Wi-Fi)
function admin_url($page) {
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
    $host = $_SERVER['HTTP_HOST'];

    // "localhost" only works on this PC. When testing at home, use the PC's Wi-Fi address
    // instead so a phone can open the link (on real hosting the host is the domain name).
    if (preg_match('/^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/', $host, $m)) {
        $lan = gethostbyname(gethostname());
        if ($lan && strpos($lan, '127.') !== 0) {
            $host = $lan . ($m[2] ?? '');
        }
    }
    return ($https ? 'https' : 'http') . '://' . $host . $dir . '/' . $page;
}

// ---------- attendance QR ----------
// The counter QR changes every minute, so a photo of it stops working quickly
define('QR_WINDOW_SECONDS', 60);
define('QR_VALID_WINDOWS', 3);

function attendance_token($conn, $window = null) {
    $window = $window ?? intdiv(time(), QR_WINDOW_SECONDS);
    $sig = substr(hash_hmac('sha256', (string)$window, secret_setting($conn, 'attendance_secret')), 0, 20);
    return $window . '-' . $sig;
}

function attendance_token_ok($conn, $token) {
    if (!preg_match('/^(\d+)-[a-f0-9]{20}$/', $token, $m)) {
        return false;
    }
    $now = intdiv(time(), QR_WINDOW_SECONDS);
    $window = (int)$m[1];
    return $window <= $now && $window > $now - QR_VALID_WINDOWS
        && hash_equals(attendance_token($conn, $window), $token);
}

// When this staff should arrive (their own start time, or shop opening time)
function start_time_for($conn, $staff) {
    return !empty($staff['start_time']) ? $staff['start_time'] : setting($conn, 'open_time');
}

// "Early 10 min" / "On time" / "Late 12 min" with a Bootstrap colour
function arrival_label($conn, $late_minutes) {
    $grace = (int)setting($conn, 'late_grace_minutes');
    if ($late_minutes > $grace) {
        return ['danger', 'Late ' . $late_minutes . ' min'];
    }
    if ($late_minutes < 0) {
        return ['success', 'Early ' . abs($late_minutes) . ' min'];
    }
    return ['success', 'On time'];
}

function hours_worked($in, $out) {
    if (!$out) {
        return '-';
    }
    $minutes = intdiv(strtotime($out) - strtotime($in), 60);
    return intdiv($minutes, 60) . 'h ' . str_pad($minutes % 60, 2, '0', STR_PAD_LEFT) . 'm';
}

// Save an uploaded image into $folder, returns the new path or an error message
function save_image_upload($file, $folder, $prefix) {
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!$file || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['error' => 'Please choose an image.'];
    }
    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > 3 * 1024 * 1024) {
        return ['error' => 'Upload failed. The image must be smaller than 3MB.'];
    }
    $type = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($allowed[$type])) {
        return ['error' => 'The image must be a JPG, PNG or WEBP file.'];
    }
    $path = $folder . '/' . $prefix . bin2hex(random_bytes(8)) . '.' . $allowed[$type];
    if (!move_uploaded_file($file['tmp_name'], __DIR__ . '/../' . $path)) {
        return ['error' => 'Could not save the image. Please try again.'];
    }
    return ['path' => $path];
}
