<?php
// Opened by the phone camera after scanning the counter QR.
// First scan of the day = arrive, next scan = go home.
include __DIR__ . '/_auth.php';
include __DIR__ . '/_layout.php';

$today = date('Y-m-d');
$now = date('Y-m-d H:i:s');
$result = null;   // [icon colour, title, detail]

$stmt = mysqli_prepare($conn, "SELECT * FROM attendance WHERE staff_id = ? AND work_date = ?");
mysqli_stmt_bind_param($stmt, 'is', $me['staff_id'], $today);
mysqli_stmt_execute($stmt);
$record = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!attendance_token_ok($conn, $_GET['t'] ?? '')) {
    $result = ['warning', 'QR code expired', 'The code at the counter changes every minute. Please scan it again.'];
} elseif (!$record) {
    // Arrive: compare with this staff's start time
    $stmt = mysqli_prepare($conn, "SELECT start_time FROM staff WHERE staff_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $me['staff_id']);
    mysqli_stmt_execute($stmt);
    $start = start_time_for($conn, mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)));
    $late = (int)floor((time() - strtotime("$today $start")) / 60);

    // IGNORE: two scans in the same second must not crash the page
    $stmt = mysqli_prepare($conn, "INSERT IGNORE INTO attendance (staff_id, work_date, clock_in, late_minutes) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, 'issi', $me['staff_id'], $today, $now, $late);
    mysqli_stmt_execute($stmt);

    [$colour, $label] = arrival_label($conn, $late);
    $result = [$colour, 'Welcome, ' . $me['name'] . '!', 'Arrived at ' . date('g:i A') . ' &middot; ' . $label . ' (start ' . date('g:i A', strtotime($start)) . ')'];
} elseif (time() - strtotime($record['clock_in']) < 5 * 60) {
    // Scanned twice by accident
    $result = ['info', 'Already clocked in', 'You arrived at ' . date('g:i A', strtotime($record['clock_in'])) . '. Scan again when you go home.'];
} else {
    // Go home (scanning again later just moves the home time)
    $stmt = mysqli_prepare($conn, "UPDATE attendance SET clock_out = ? WHERE attendance_id = ?");
    mysqli_stmt_bind_param($stmt, 'si', $now, $record['attendance_id']);
    mysqli_stmt_execute($stmt);
    $result = ['dark', 'See you tomorrow, ' . $me['name'] . '!', 'Went home at ' . date('g:i A') . ' &middot; worked ' . hours_worked($record['clock_in'], $now)];
}

admin_header('Attendance scan', 'attendance');
[$colour, $title, $detail] = $result;
?>
<div class="row justify-content-center">
    <div class="col-md-6 col-lg-4">
        <div class="card text-center p-4">
            <div class="display-4 text-<?php echo $colour; ?> mb-2">
                <i class="fa-solid <?php echo $colour === 'warning' ? 'fa-rotate' : ($colour === 'danger' ? 'fa-clock' : 'fa-circle-check'); ?>"></i>
            </div>
            <h1 class="h4"><?php echo e($title); ?></h1>
            <p class="mb-3"><?php echo $detail; ?></p>
            <a href="attendance.php" class="btn <?php echo $colour === 'warning' ? 'btn-brand' : 'btn-outline-dark'; ?>"><?php echo $colour === 'warning' ? 'Scan again' : 'My attendance'; ?></a>
        </div>
    </div>
</div>
<?php admin_footer(); ?>
