<?php
// Page frame for the admin panel: top menu + flash message
function admin_header($title, $active) {
    global $me, $is_owner, $conn;
    // page => [label, icon, owner only]
    $links = [
        'index'       => ['Dashboard', 'fa-gauge', false],
        'bookings'    => ['Bookings', 'fa-calendar-check', false],
        'attendance'  => ['Attendance', 'fa-clock', false],
        'performance' => ['Performance', 'fa-ranking-star', true],
        'payroll'     => [$is_owner ? 'Payroll' : 'My salary', 'fa-money-bill-wave', false],
    ];
    // Owner-only setup pages, grouped under "Manage"
    $manage = [
        'services'  => ['Services', 'fa-scissors'],
        'staff'     => ['Staff', 'fa-users'],
        'customers' => ['Customers', 'fa-address-book'],
        'settings'  => ['Settings', 'fa-gear'],
    ];
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?> | KI'AD Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
    rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
     integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
     crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="admin.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark admin-nav">
  <div class="container-fluid px-4">
    <a class="navbar-brand" href="index.php"><img src="../<?php echo e(logo($conn)); ?>" alt=""> <span><?php echo $is_owner ? 'ADMIN' : 'STAFF'; ?></span></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminMenu" aria-controls="adminMenu" aria-expanded="false" aria-label="Menu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="adminMenu">
      <ul class="navbar-nav me-auto">
        <?php foreach ($links as $page => [$label, $icon, $owner_only]) {
            if ($owner_only && !$is_owner) continue; ?>
        <li class="nav-item">
          <a class="nav-link <?php echo $active === $page ? 'active' : ''; ?>" href="<?php echo $page; ?>.php"><i class="fa-solid <?php echo $icon; ?> me-1"></i><?php echo $label; ?></a>
        </li>
        <?php } ?>
        <?php if ($is_owner) { ?>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?php echo isset($manage[$active]) ? 'active' : ''; ?>" href="#" id="manageMenu" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-sliders me-1"></i>Manage</a>
          <ul class="dropdown-menu" aria-labelledby="manageMenu">
            <?php foreach ($manage as $page => [$label, $icon]) { ?>
            <li><a class="dropdown-item <?php echo $active === $page ? 'active' : ''; ?>" href="<?php echo $page; ?>.php"><i class="fa-solid <?php echo $icon; ?> me-2"></i><?php echo $label; ?></a></li>
            <?php } ?>
          </ul>
        </li>
        <?php } ?>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link <?php echo $active === 'account' ? 'active' : ''; ?>" href="account.php"><i class="fa-solid fa-user me-1"></i><?php echo e($me['name']); ?> <span class="role-tag"><?php echo $is_owner ? 'Owner' : 'Staff'; ?></span></a>
        </li>
        <li class="nav-item"><a class="nav-link" href="logout.php"><i class="fa-solid fa-right-from-bracket me-1"></i>Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<main class="container-fluid px-4 py-4">
    <?php if (!empty($_SESSION['flash'])) {
        [$type, $message] = $_SESSION['flash'];
        unset($_SESSION['flash']); ?>
    <div class="alert alert-<?php echo e($type); ?> alert-dismissible fade show" role="alert">
        <?php echo e($message); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php } ?>
<?php
}

function admin_footer() {
    ?>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
<?php
}
