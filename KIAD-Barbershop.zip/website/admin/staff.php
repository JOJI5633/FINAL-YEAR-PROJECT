<?php
include __DIR__ . '/_auth.php';
include __DIR__ . '/_layout.php';
require_owner();

function find_staff($conn, $id) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM staff WHERE staff_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

$editing = isset($_GET['edit']) ? find_staff($conn, (int)$_GET['edit']) : null;
$form = $editing ?? ['staff_id' => 0, 'name' => '', 'username' => '', 'role' => 'staff', 'is_barber' => 1, 'active' => 1, 'start_time' => ''];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form = [
        'staff_id'  => (int)($_POST['staff_id'] ?? 0),
        'name'      => trim($_POST['name'] ?? ''),
        'username'  => strtolower(trim($_POST['username'] ?? '')),
        'role'      => ($_POST['role'] ?? '') === 'owner' ? 'owner' : 'staff',
        'is_barber' => isset($_POST['is_barber']) ? 1 : 0,
        'active'    => isset($_POST['active']) ? 1 : 0,
        'start_time' => trim($_POST['start_time'] ?? ''),
    ];
    $password = $_POST['password'] ?? '';
    $old = $form['staff_id'] ? find_staff($conn, $form['staff_id']) : null;
    $is_me = $old && (int)$old['staff_id'] === (int)$me['staff_id'];

    // You can't lock yourself out
    if ($is_me) {
        $form['role'] = 'owner';
        $form['active'] = 1;
    }

    $stmt = mysqli_prepare($conn, "SELECT staff_id FROM staff WHERE username = ? AND staff_id <> ?");
    mysqli_stmt_bind_param($stmt, 'si', $form['username'], $form['staff_id']);
    mysqli_stmt_execute($stmt);
    $taken = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($form['name'] === '' || strlen($form['name']) > 100) {
        $error = 'Please enter a name.';
    } elseif (!preg_match('/^[a-z0-9_.]{3,50}$/', $form['username'])) {
        $error = 'Username must be 3-50 letters or numbers (no spaces).';
    } elseif ($taken) {
        $error = 'That username is already used by another staff.';
    } elseif ($form['start_time'] !== '' && !preg_match('/^\d{2}:\d{2}$/', $form['start_time'])) {
        $error = 'Please enter a start time like 10:00, or leave it empty.';
    } elseif (!$old && strlen($password) < 6) {
        $error = 'Please set a password of at least 6 characters.';
    } elseif ($old && $password !== '' && strlen($password) < 6) {
        $error = 'The new password must be at least 6 characters.';
    }

    if ($error === '') {
        if ($old) {
            $stmt = mysqli_prepare($conn, "UPDATE staff SET name = ?, username = ?, role = ?, is_barber = ?, active = ?, start_time = NULLIF(?, '') WHERE staff_id = ?");
            mysqli_stmt_bind_param($stmt, 'sssiisi', $form['name'], $form['username'], $form['role'], $form['is_barber'], $form['active'], $form['start_time'], $old['staff_id']);
            mysqli_stmt_execute($stmt);
            if ($password !== '') {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = mysqli_prepare($conn, "UPDATE staff SET password_hash = ? WHERE staff_id = ?");
                mysqli_stmt_bind_param($stmt, 'si', $hash, $old['staff_id']);
                mysqli_stmt_execute($stmt);
            }
            unset($_SESSION['weak_passwords']);   // re-check the starter-password warning
            $message = '"' . $form['name'] . '" updated.' . ($password !== '' ? ' New password saved.' : '');

            // Warn when someone who still has bookings stops taking customers
            if (!$form['active'] || !$form['is_barber']) {
                $stmt = mysqli_prepare($conn, "SELECT COUNT(*) FROM receipt WHERE barber_id = ? AND date >= CURDATE() AND job_status = 'booked'");
                mysqli_stmt_bind_param($stmt, 'i', $old['staff_id']);
                mysqli_stmt_execute($stmt);
                $left = mysqli_fetch_row(mysqli_stmt_get_result($stmt))[0];
                if ($left > 0) {
                    flash($message . " They still have $left upcoming booking(s). Move them to another barber in Bookings.", 'warning');
                    header("Location: bookings.php?when=upcoming&barber=" . $old['staff_id']);
                    exit();
                }
            }
            flash($message);
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($conn, "INSERT INTO staff (name, username, password_hash, role, is_barber, active, start_time) VALUES (?, ?, ?, ?, ?, ?, NULLIF(?, ''))");
            mysqli_stmt_bind_param($stmt, 'ssssiis', $form['name'], $form['username'], $hash, $form['role'], $form['is_barber'], $form['active'], $form['start_time']);
            mysqli_stmt_execute($stmt);
            flash('"' . $form['name'] . '" added. They can log in on the normal login page with username "' . $form['username'] . '".');
        }
        header("Location: staff.php");
        exit();
    }
    $editing = $old;
}

$staff = mysqli_fetch_all(mysqli_query($conn, "
    SELECT s.*,
           (SELECT COUNT(*) FROM receipt r WHERE r.barber_id = s.staff_id AND r.date >= CURDATE() AND r.job_status = 'booked') AS upcoming
    FROM staff s ORDER BY s.active DESC, s.role = 'owner' DESC, s.staff_id"), MYSQLI_ASSOC);
$editing_me = $editing && (int)$editing['staff_id'] === (int)$me['staff_id'];

admin_header('Staff', 'staff');
?>
<h1 class="h3 mb-3">Staff &amp; barbers</h1>

<div class="row g-4">
    <div class="col-lg-4">
        <form method="post" class="card" id="staff-form">
            <div class="card-header"><?php echo $editing ? 'Edit ' . e($editing['name']) : 'Add staff'; ?></div>
            <div class="card-body">
                <?php if ($error) { ?><div class="alert alert-danger py-2"><?php echo e($error); ?></div><?php } ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="staff_id" value="<?php echo (int)$form['staff_id']; ?>">
                <div class="mb-3">
                    <label class="form-label" for="name">Name</label>
                    <input class="form-control" id="name" name="name" maxlength="100" required value="<?php echo e($form['name']); ?>">
                    <div class="form-text">Customers see this name when they choose a barber.</div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="username">Username</label>
                    <input class="form-control" id="username" name="username" maxlength="50" required value="<?php echo e($form['username']); ?>" autocomplete="off">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="password"><?php echo $editing ? 'New password' : 'Password'; ?></label>
                    <input class="form-control" id="password" name="password" type="password" minlength="6" <?php echo $editing ? '' : 'required'; ?> autocomplete="new-password">
                    <?php if ($editing) { ?><div class="form-text">Leave empty to keep the current password.</div><?php } ?>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="role">Role</label>
                    <select class="form-select" id="role" name="role" <?php echo $editing_me ? 'disabled' : ''; ?>>
                        <option value="staff" <?php echo $form['role'] === 'staff' ? 'selected' : ''; ?>>Staff: sees own bookings, marks cash received and done</option>
                        <option value="owner" <?php echo $form['role'] === 'owner' ? 'selected' : ''; ?>>Owner: can do everything</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="start_time">Starts work at</label>
                    <input class="form-control" type="time" id="start_time" name="start_time" style="max-width: 160px" value="<?php echo e($form['start_time'] ?? ''); ?>">
                    <div class="form-text">Used to tell if they came late. Empty = shop opening time (<?php echo date('g:i A', strtotime(setting($conn, 'open_time'))); ?>).</div>
                </div>
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" id="is_barber" name="is_barber" <?php echo $form['is_barber'] ? 'checked' : ''; ?>>
                    <label class="form-check-label" for="is_barber">Cuts hair (customers can choose them)</label>
                </div>
                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" id="active" name="active" <?php echo $form['active'] ? 'checked' : ''; ?> <?php echo $editing_me ? 'disabled' : ''; ?>>
                    <label class="form-check-label" for="active">Active (untick when they stop working here)</label>
                </div>
                <?php if ($editing_me) { ?>
                <p class="small text-muted">This is your own account, so you stay owner and active.</p>
                <input type="hidden" name="active" value="1">
                <?php } ?>
                <button class="btn btn-brand"><?php echo $editing ? 'Save changes' : 'Add staff'; ?></button>
                <?php if ($editing) { ?><a href="staff.php" class="btn btn-link">Cancel</a><?php } ?>
            </div>
        </form>
    </div>

    <div class="col-lg-8">
        <div class="card">
            <div class="table-responsive">
            <table class="table mb-0">
                <thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Barber</th><th>Starts work</th><th class="num">Upcoming</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($staff as $s) { ?>
                    <tr class="<?php echo $s['active'] ? '' : 'text-muted'; ?>">
                        <td><?php echo e($s['name']); ?><?php echo $s['active'] ? '' : ' <span class="badge bg-secondary">Disabled</span>'; ?></td>
                        <td><?php echo e($s['username']); ?></td>
                        <td><?php echo $s['role'] === 'owner' ? '<span class="badge bg-dark">Owner</span>' : '<span class="badge bg-light text-dark border">Staff</span>'; ?></td>
                        <td><?php echo $s['is_barber'] ? '<i class="fa-solid fa-scissors" aria-label="Yes"></i>' : '<span class="text-muted">-</span>'; ?></td>
                        <td><?php echo date('g:i A', strtotime(start_time_for($conn, $s))); ?><?php echo $s['start_time'] ? '' : ' <span class="text-muted small">(shop opens)</span>'; ?></td>
                        <td class="num"><?php echo $s['upcoming']; ?></td>
                        <td class="text-end"><a href="staff.php?edit=<?php echo $s['staff_id']; ?>#staff-form" class="btn btn-sm btn-outline-dark"><i class="fa-solid fa-pen"></i> Edit</a></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
            </div>
        </div>
        <p class="small text-muted mt-2">Staff log in on the same login page as customers (<strong>Login.php</strong>). A disabled account can't log in and customers can't choose them, but their old bookings stay.</p>
    </div>
</div>
<?php admin_footer(); ?>
