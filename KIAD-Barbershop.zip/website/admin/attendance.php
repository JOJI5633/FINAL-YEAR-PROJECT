<?php
include __DIR__ . '/_auth.php';
include __DIR__ . '/_layout.php';
include __DIR__ . '/_stats.php';

$today = date('Y-m-d');

// ---------- owner actions ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_owner) {
    $action = $_POST['action'] ?? '';
    $date = $_POST['date'] ?? $today;

    if ($action === 'new_kiosk_link') {
        secret_setting($conn, 'kiosk_key', true);
        flash('New counter link made. The old link stops working, open the new one on the counter screen.', 'warning');
        header("Location: attendance.php");
        exit();
    }

    $staff_id = (int)($_POST['staff_id'] ?? 0);
    $stmt = mysqli_prepare($conn, "SELECT * FROM staff WHERE staff_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $staff_id);
    mysqli_stmt_execute($stmt);
    $person = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    $valid_date = DateTime::createFromFormat('Y-m-d', $date) && $date <= $today;

    if (!$person || !$valid_date) {
        flash('Please choose a staff and a date that has passed.', 'danger');
    } elseif ($action === 'save_record') {
        // Owner fixes a forgotten scan
        $in = $_POST['clock_in'] ?? '';
        $out = $_POST['clock_out'] ?? '';
        if (!preg_match('/^\d{2}:\d{2}$/', $in) || ($out !== '' && (!preg_match('/^\d{2}:\d{2}$/', $out) || $out <= $in))) {
            flash('Arrive time is needed, and home time must be after it.', 'danger');
        } else {
            $clock_in = "$date $in:00";
            $clock_out = $out !== '' ? "$date $out:00" : null;
            $late = (int)floor((strtotime($clock_in) - strtotime($date . ' ' . start_time_for($conn, $person))) / 60);
            $stmt = mysqli_prepare($conn, "INSERT INTO attendance (staff_id, work_date, clock_in, clock_out, late_minutes, edited_by_owner)
                                           VALUES (?, ?, ?, ?, ?, 1)
                                           ON DUPLICATE KEY UPDATE clock_in = VALUES(clock_in), clock_out = VALUES(clock_out),
                                                                   late_minutes = VALUES(late_minutes), edited_by_owner = 1");
            mysqli_stmt_bind_param($stmt, 'isssi', $staff_id, $date, $clock_in, $clock_out, $late);
            mysqli_stmt_execute($stmt);
            flash($person['name'] . "'s attendance on " . date('j M', strtotime($date)) . ' saved.');
        }
    } elseif ($action === 'delete_record') {
        $stmt = mysqli_prepare($conn, "DELETE FROM attendance WHERE staff_id = ? AND work_date = ?");
        mysqli_stmt_bind_param($stmt, 'is', $staff_id, $date);
        mysqli_stmt_execute($stmt);
        flash($person['name'] . "'s attendance on " . date('j M', strtotime($date)) . ' removed.', 'warning');
    }
    header("Location: attendance.php?d=" . urlencode($date));
    exit();
}

$month = month_param();
$summary = attendance_summary($conn, $month);

if ($is_owner) {
    $day = $_GET['d'] ?? $today;
    if (!DateTime::createFromFormat('Y-m-d', $day) || $day > $today) {
        $day = $today;
    }
    $editing = (int)($_GET['edit'] ?? 0);
    $rows = mysqli_fetch_all(mysqli_query($conn, "
        SELECT s.staff_id, s.name, s.start_time, s.active, a.clock_in, a.clock_out, a.late_minutes, a.edited_by_owner
        FROM staff s LEFT JOIN attendance a ON a.staff_id = s.staff_id AND a.work_date = '$day'
        WHERE (s.active = 1 AND s.role = 'staff') OR a.attendance_id IS NOT NULL
        ORDER BY a.clock_in IS NULL, a.clock_in, s.staff_id"), MYSQLI_ASSOC);
    $staff_list = mysqli_fetch_all(mysqli_query($conn, "SELECT staff_id, name, active, role FROM staff ORDER BY active DESC, staff_id"), MYSQLI_ASSOC);
    $kiosk = admin_url('kiosk.php?key=' . secret_setting($conn, 'kiosk_key'));
} else {
    [$from, $to] = month_range($month);
    $mine = mysqli_fetch_all(mysqli_query($conn, "
        SELECT * FROM attendance WHERE staff_id = " . (int)$me['staff_id'] . " AND work_date BETWEEN '$from' AND '$to'
        ORDER BY work_date DESC"), MYSQLI_ASSOC);
    $today_record = null;
    foreach ($mine as $r) {
        if ($r['work_date'] === $today) {
            $today_record = $r;
        }
    }
    $stmt = mysqli_prepare($conn, "SELECT start_time FROM staff WHERE staff_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $me['staff_id']);
    mysqli_stmt_execute($stmt);
    $my_start = start_time_for($conn, mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)));
}

admin_header('Attendance', 'attendance');
?>
<h1 class="h3 mb-3"><?php echo $is_owner ? 'Attendance' : 'My attendance'; ?></h1>

<?php if ($is_owner) { ?>
<!-- counter screen -->
<div class="card mb-4">
    <div class="card-body d-flex flex-wrap gap-3 align-items-center">
        <div class="display-6 text-muted"><i class="fa-solid fa-qrcode"></i></div>
        <div class="flex-grow-1" style="min-width: 240px">
            <strong>Counter QR screen</strong>
            <p class="small text-muted mb-2">Open this link on the tablet or PC at the counter and leave it on. Staff scan it with their phone camera: first scan = arrive, second scan = go home. The link doesn't give access to the admin panel.</p>
            <div class="input-group input-group-sm">
                <input class="form-control" id="kiosk-link" value="<?php echo e($kiosk); ?>" readonly aria-label="Counter screen link">
                <button class="btn btn-outline-dark" type="button" onclick="navigator.clipboard.writeText(document.getElementById('kiosk-link').value); this.textContent='Copied'">Copy</button>
                <a class="btn btn-brand" href="<?php echo e($kiosk); ?>" target="_blank">Open screen</a>
            </div>
        </div>
        <form method="post">
            <?php echo csrf_field(); ?>
            <button class="btn btn-sm btn-outline-danger" name="action" value="new_kiosk_link" onclick="return confirm('Make a new link? The old counter link will stop working.')">New link</button>
        </form>
    </div>
</div>

<!-- one day -->
<div class="card mb-4">
    <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span><?php echo $day === $today ? 'Today' : date('l, j F Y', strtotime($day)); ?></span>
        <form method="get" class="d-flex gap-2 align-items-center">
            <label for="d" class="small mb-0">Day</label>
            <input type="date" id="d" name="d" class="form-control form-control-sm" value="<?php echo e($day); ?>" max="<?php echo $today; ?>" onchange="this.form.submit()">
        </form>
    </div>
    <div class="table-responsive">
    <table class="table mb-0 align-middle">
        <thead><tr><th>Staff</th><th>Starts</th><th>Arrived</th><th>Went home</th><th>Status</th><th>Worked</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r) {
            $start = start_time_for($conn, $r);
            if ($editing === (int)$r['staff_id']) { ?>
            <tr class="table-warning">
                <td><?php echo e($r['name']); ?></td>
                <td><?php echo date('g:i A', strtotime($start)); ?></td>
                <td colspan="5">
                    <form method="post" class="d-flex flex-wrap gap-2 align-items-center">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="staff_id" value="<?php echo $r['staff_id']; ?>">
                        <input type="hidden" name="date" value="<?php echo e($day); ?>">
                        <label class="small">Arrived <input type="time" name="clock_in" class="form-control form-control-sm d-inline-block w-auto" required value="<?php echo $r['clock_in'] ? date('H:i', strtotime($r['clock_in'])) : ''; ?>"></label>
                        <label class="small">Went home <input type="time" name="clock_out" class="form-control form-control-sm d-inline-block w-auto" value="<?php echo $r['clock_out'] ? date('H:i', strtotime($r['clock_out'])) : ''; ?>"></label>
                        <button class="btn btn-sm btn-brand" name="action" value="save_record">Save</button>
                        <?php if ($r['clock_in']) { ?>
                        <button class="btn btn-sm btn-outline-danger" name="action" value="delete_record" onclick="return confirm('Remove this attendance record?')">Remove</button>
                        <?php } ?>
                        <a href="attendance.php?d=<?php echo e($day); ?>" class="btn btn-sm btn-link">Cancel</a>
                    </form>
                </td>
            </tr>
            <?php } else { ?>
            <tr>
                <td><?php echo e($r['name']); ?><?php echo $r['active'] ? '' : ' <span class="badge bg-secondary">Disabled</span>'; ?></td>
                <td><?php echo date('g:i A', strtotime($start)); ?></td>
                <?php if ($r['clock_in']) {
                    [$colour, $label] = arrival_label($conn, (int)$r['late_minutes']); ?>
                <td><?php echo date('g:i A', strtotime($r['clock_in'])); ?><?php echo $r['edited_by_owner'] ? ' <i class="fa-solid fa-pen text-muted small" title="Changed by owner"></i>' : ''; ?></td>
                <td><?php echo $r['clock_out'] ? date('g:i A', strtotime($r['clock_out'])) : '<span class="text-muted">-</span>'; ?></td>
                <td><span class="badge bg-<?php echo $colour; ?>"><?php echo $label; ?></span></td>
                <td><?php echo hours_worked($r['clock_in'], $r['clock_out']); ?></td>
                <?php } else { ?>
                <td colspan="4"><span class="text-muted">No scan</span></td>
                <?php } ?>
                <td class="text-end"><a href="attendance.php?d=<?php echo e($day); ?>&amp;edit=<?php echo $r['staff_id']; ?>" class="btn btn-sm btn-outline-dark"><?php echo $r['clock_in'] ? 'Fix' : 'Add'; ?></a></td>
            </tr>
            <?php } ?>
        <?php } ?>
        </tbody>
    </table>
    </div>
</div>

<!-- month -->
<div class="card">
    <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span><?php echo date('F Y', strtotime("$month-01")); ?></span>
        <?php month_picker($month); ?>
    </div>
    <div class="table-responsive">
    <table class="table mb-0">
        <thead><tr><th>Staff</th><th class="num">Days worked</th><th class="num">Times late</th><th class="num">Minutes late</th><th class="num">Hours worked</th></tr></thead>
        <tbody>
        <?php foreach ($staff_list as $s) {
            $a = $summary[$s['staff_id']] ?? null;
            // Owners and disabled staff only show when they have scanned this month
            if (!$a && (!$s['active'] || $s['role'] === 'owner')) continue; ?>
            <tr>
                <td><?php echo e($s['name']); ?></td>
                <td class="num"><?php echo $a['days'] ?? 0; ?></td>
                <td class="num <?php echo ($a['late_count'] ?? 0) > 0 ? 'text-danger fw-semibold' : ''; ?>"><?php echo $a['late_count'] ?? 0; ?></td>
                <td class="num"><?php echo $a['late_minutes'] ?? 0; ?></td>
                <td class="num"><?php echo hours_text($a['minutes'] ?? 0); ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
    </div>
    <div class="card-footer small text-muted">Late = arrived more than <?php echo (int)setting($conn, 'late_grace_minutes'); ?> minutes after their start time (change in Settings; start times are set per staff in Staff).</div>
</div>

<?php } else {
    // Camera opens by itself until the staff has clocked in AND gone home today
    $scan_now = !$today_record || !$today_record['clock_out']; ?>
<!-- staff: scan the counter QR right here -->
<div class="card mb-4">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center gap-2 mb-3">
            <h2 class="h5 mb-0"><i class="fa-solid fa-qrcode me-1"></i><?php echo !$today_record ? 'Scan to clock in' : ($today_record['clock_out'] ? 'Scan again' : 'Scan when you go home'); ?></h2>
            <button type="button" class="btn btn-sm btn-brand" id="scan-toggle"><?php echo $scan_now ? 'Stop camera' : 'Open camera'; ?></button>
        </div>
        <div class="scanner" id="scanner" data-autostart="<?php echo $scan_now ? '1' : '0'; ?>" <?php echo $scan_now ? '' : 'hidden'; ?>>
            <video id="scan-video" playsinline muted></video>
            <div class="scan-frame" aria-hidden="true"></div>
        </div>
        <p class="text-center mt-3 mb-1" id="scan-status" role="status"><?php echo $scan_now ? 'Starting camera&hellip;' : 'Tap "Open camera" to scan the counter QR.'; ?></p>
        <?php if (!$today_record) { ?>
        <p class="text-muted small text-center mb-0">Your work starts at <strong><?php echo date('g:i A', strtotime($my_start)); ?></strong>:
            scanning after <?php echo date('g:i A', strtotime($my_start) + (int)setting($conn, 'late_grace_minutes') * 60); ?> counts as late.</p>
        <?php } ?>
        <details class="small mt-3" id="scan-other-way">
            <summary>Camera not working? Use your phone's camera app</summary>
            <ol class="scan-steps mt-2 mb-0">
                <li>Open your phone's <strong>camera app</strong> and point it at the QR on the counter screen.</li>
                <li>Tap the link that pops up. Log in if it asks.</li>
                <li>You will see <em>"Welcome"</em>.</li>
            </ol>
        </details>
    </div>
</div>

<!-- staff: today -->
<div class="card mb-4">
    <div class="card-body text-center py-4">
        <?php if (!$today_record) { ?>
            <div class="display-5 text-muted mb-2"><i class="fa-regular fa-clock"></i></div>
            <h2 class="h5 mb-0">Not clocked in yet today</h2>
        <?php } else {
            [$colour, $label] = arrival_label($conn, (int)$today_record['late_minutes']); ?>
            <div class="display-5 text-<?php echo $colour; ?> mb-2"><i class="fa-solid fa-circle-check"></i></div>
            <h2 class="h5">Arrived at <?php echo date('g:i A', strtotime($today_record['clock_in'])); ?> <span class="badge bg-<?php echo $colour; ?>"><?php echo $label; ?></span></h2>
            <p class="text-muted mb-0">
                <?php echo $today_record['clock_out']
                    ? 'Went home at ' . date('g:i A', strtotime($today_record['clock_out'])) . ' &middot; worked ' . hours_worked($today_record['clock_in'], $today_record['clock_out'])
                    : 'Scan the counter QR again when you go home.'; ?>
            </p>
        <?php } ?>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span><?php echo date('F Y', strtotime("$month-01")); ?> &middot; <?php echo $summary[$me['staff_id']]['days'] ?? 0; ?> days, late <?php echo $summary[$me['staff_id']]['late_count'] ?? 0; ?> times</span>
        <?php month_picker($month); ?>
    </div>
    <div class="table-responsive">
    <table class="table mb-0">
        <thead><tr><th>Date</th><th>Arrived</th><th>Went home</th><th>Status</th><th>Worked</th></tr></thead>
        <tbody>
        <?php if (count($mine) === 0) { ?>
            <tr><td colspan="5" class="text-center text-muted py-4">No attendance this month.</td></tr>
        <?php } ?>
        <?php foreach ($mine as $r) {
            [$colour, $label] = arrival_label($conn, (int)$r['late_minutes']); ?>
            <tr>
                <td><?php echo date('D, j M', strtotime($r['work_date'])); ?></td>
                <td><?php echo date('g:i A', strtotime($r['clock_in'])); ?></td>
                <td><?php echo $r['clock_out'] ? date('g:i A', strtotime($r['clock_out'])) : '-'; ?></td>
                <td><span class="badge bg-<?php echo $colour; ?>"><?php echo $label; ?></span></td>
                <td><?php echo hours_worked($r['clock_in'], $r['clock_out']); ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
    </div>
</div>

<script type="module">
// Scan the counter QR inside the page: camera -> read QR -> open scan.php with its code
import jsQR from 'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/+esm';

const box = document.getElementById('scanner');
const video = document.getElementById('scan-video');
const status = document.getElementById('scan-status');
const toggle = document.getElementById('scan-toggle');
const canvas = document.createElement('canvas');
const ctx = canvas.getContext('2d', { willReadFrequently: true });
let stream = null;
let timer = null;

function say(text, isProblem = false) {
    status.textContent = text;
    status.classList.toggle('text-danger', isProblem);
    if (isProblem) document.getElementById('scan-other-way').open = true;
}

// Only accept the KI'AD attendance QR: .../scan.php?t=<code>
function codeFrom(text) {
    try {
        const url = new URL(text, location.href);
        const t = url.searchParams.get('t');
        return url.pathname.endsWith('/scan.php') && /^\d+-[a-f0-9]{20}$/.test(t || '') ? t : null;
    } catch (e) {
        return null;
    }
}

async function start() {
    box.hidden = false;
    toggle.textContent = 'Stop camera';
    // Browsers only allow the camera on https (or on this computer itself)
    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        box.hidden = true;
        toggle.hidden = true;
        say('The camera only works when the website uses https. It will work on the real website - for now use your phone\'s camera app (see below).', true);
        return;
    }
    try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
    } catch (e) {
        box.hidden = true;
        toggle.textContent = 'Try again';
        say(e.name === 'NotAllowedError'
            ? 'Camera is blocked. Allow the camera for this website in your browser settings, then tap "Try again".'
            : e.name === 'NotFoundError'
                ? 'No camera found on this device.'
                : 'Could not open the camera. Tap "Try again".', true);
        return;
    }
    video.srcObject = stream;
    await video.play();
    say('Point the camera at the QR on the counter screen.');
    look();
}

function stop() {
    if (stream) stream.getTracks().forEach(track => track.stop());
    stream = null;
    clearTimeout(timer);
    box.hidden = true;
    toggle.textContent = 'Open camera';
}

function look() {
    if (!stream) return;
    if (video.readyState >= 2 && video.videoWidth) {
        canvas.width = 480;
        canvas.height = Math.round(480 * video.videoHeight / video.videoWidth);
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const found = jsQR(ctx.getImageData(0, 0, canvas.width, canvas.height).data, canvas.width, canvas.height);
        if (found) {
            const code = codeFrom(found.data);
            if (code) {
                if (navigator.vibrate) navigator.vibrate(80);
                say('QR found - saving your attendance...');
                stop();
                location.href = 'scan.php?t=' + encodeURIComponent(code);
                return;
            }
            say('That is not the KI\'AD attendance QR. Scan the QR on the counter screen.', true);
        }
    }
    timer = setTimeout(look, 150);
}

toggle.addEventListener('click', () => (stream ? stop() : start()));
// Turn the camera off when leaving the page or switching apps
document.addEventListener('visibilitychange', () => { if (document.hidden && stream) stop(); });
window.addEventListener('pagehide', stop);

if (box.dataset.autostart === '1') start();
</script>
<?php } ?>
<?php admin_footer(); ?>
