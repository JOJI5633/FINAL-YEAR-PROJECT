<?php
// Monthly numbers per staff, shared by Attendance, Performance, Payroll and the dashboard.
// $month is 'YYYY-MM'.

function month_range($month) {
    $start = $month . '-01';
    return [$start, date('Y-m-t', strtotime($start))];
}

// Clean ?m=YYYY-MM from the URL, defaults to this month
function month_param() {
    $m = $_GET['m'] ?? '';
    return preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $m) ? $m : date('Y-m');
}

// [staff_id => days, late_count, late_minutes, minutes]
function attendance_summary($conn, $month) {
    [$from, $to] = month_range($month);
    $grace = (int)setting($conn, 'late_grace_minutes');
    $result = mysqli_query($conn, "
        SELECT staff_id,
               COUNT(*) AS days,
               SUM(late_minutes > $grace) AS late_count,
               SUM(CASE WHEN late_minutes > $grace THEN late_minutes ELSE 0 END) AS late_minutes,
               COALESCE(SUM(TIMESTAMPDIFF(MINUTE, clock_in, clock_out)), 0) AS minutes
        FROM attendance WHERE work_date BETWEEN '$from' AND '$to'
        GROUP BY staff_id");
    $out = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $out[$row['staff_id']] = $row;
    }
    return $out;
}

// [barber_id => customers, sales, bookings, chosen, rating, reviews]
// customers/sales = finished haircuts; chosen = bookings where the customer picked them by name
function performance_summary($conn, $month) {
    [$from, $to] = month_range($month);
    $out = [];
    $result = mysqli_query($conn, "
        SELECT barber_id,
               COUNT(*) AS bookings,
               SUM(job_status = 'done') AS customers,
               COALESCE(SUM(CASE WHEN job_status = 'done' THEN total END), 0) AS sales,
               SUM(chosen_barber) AS chosen
        FROM receipt
        WHERE barber_id IS NOT NULL AND date BETWEEN '$from' AND '$to'
          AND job_status <> 'cancelled' AND (payment_status IS NULL OR payment_status <> 'rejected')
        GROUP BY barber_id");
    while ($row = mysqli_fetch_assoc($result)) {
        $out[$row['barber_id']] = $row + ['rating' => null, 'reviews' => 0];
    }
    // Ratings given this month
    $result = mysqli_query($conn, "
        SELECT barber_id, AVG(stars) AS rating, COUNT(*) AS reviews FROM review
        WHERE created_at BETWEEN '$from 00:00:00' AND '$to 23:59:59' GROUP BY barber_id");
    while ($row = mysqli_fetch_assoc($result)) {
        $out[$row['barber_id']] = ($out[$row['barber_id']] ?? ['bookings' => 0, 'customers' => 0, 'sales' => 0, 'chosen' => 0])
                                  + ['rating' => null, 'reviews' => 0];
        $out[$row['barber_id']]['rating'] = (float)$row['rating'];
        $out[$row['barber_id']]['reviews'] = (int)$row['reviews'];
    }
    return $out;
}

function hours_text($minutes) {
    return intdiv((int)$minutes, 60) . 'h ' . str_pad((int)$minutes % 60, 2, '0', STR_PAD_LEFT) . 'm';
}

// ★★★★☆ 4.2 (5)   - or just the stars for a single review
function stars_text($rating, $count, $with_numbers = true) {
    if (!$count) {
        return '<span class="text-muted">No ratings</span>';
    }
    $full = (int)round($rating);
    $html = '<span class="stars" role="img" aria-label="' . number_format($rating, 1) . ' out of 5 stars">'
          . str_repeat('<i class="fa-solid fa-star"></i>', $full)
          . str_repeat('<i class="fa-regular fa-star"></i>', 5 - $full)
          . '</span>';
    return $with_numbers ? $html . ' ' . number_format($rating, 1) . ' <span class="text-muted">(' . $count . ')</span>' : $html;
}

// Month picker used on several pages
function month_picker($month) {
    ?>
    <form method="get" class="d-flex align-items-center gap-2">
        <label for="m" class="form-label mb-0 small">Month</label>
        <input type="month" id="m" name="m" class="form-control form-control-sm" style="width: auto" value="<?php echo e($month); ?>" max="<?php echo date('Y-m'); ?>" onchange="this.form.submit()">
        <noscript><button class="btn btn-sm btn-dark">Show</button></noscript>
    </form>
    <?php
}
