<?php
// Everyone (customers, staff, owner) now logs in on the main login page.
// This old address still works: it forwards there, keeping ?next= and ?disabled.
$query = $_SERVER['QUERY_STRING'] ?? '';
header("Location: ../Login.php" . ($query !== '' ? '?' . $query : ''));
exit();
