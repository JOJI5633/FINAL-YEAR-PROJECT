<?php
include __DIR__ . '/_auth.php';
include __DIR__ . '/_layout.php';
include __DIR__ . '/_stats.php';
require_owner();

$month = month_param();
[$from, $to] = month_range($month);
$perf = performance_summary($conn, $month);
$attend = attendance_summary($conn, $month);

// Barbers who worked this month (or are active now)
$barbers = mysqli_fetch_all(mysqli_query($conn, "SELECT staff_id, name, active FROM staff WHERE is_barber = 1 ORDER BY staff_id"), MYSQLI_ASSOC);
$barbers = array_values(array_filter($barbers, fn($b) => $b['active'] || isset($perf[$b['staff_id']])));

// Most requested first, then best rating
usort($barbers, function ($a, $b) use ($perf) {
    $pa = $perf[$a['staff_id']] ?? [];
    $pb = $perf[$b['staff_id']] ?? [];
    return (($pb['chosen'] ?? 0) <=> ($pa['chosen'] ?? 0)) ?: (($pb['rating'] ?? 0) <=> ($pa['rating'] ?? 0));
});
$most_chosen = max(array_map(fn($b) => (int)($perf[$b['staff_id']]['chosen'] ?? 0), $barbers) ?: [0]);
$best_rating = max(array_map(fn($b) => (float)($perf[$b['staff_id']]['rating'] ?? 0), $barbers) ?: [0]);

// Sales each day per barber (finished haircuts)
$daily = [];
$result = mysqli_query($conn, "
    SELECT date, barber_id, SUM(total) AS sales, COUNT(*) AS n FROM receipt
    WHERE job_status = 'done' AND barber_id IS NOT NULL AND date BETWEEN '$from' AND '$to'
      AND (payment_status IS NULL OR payment_status <> 'rejected')
    GROUP BY date, barber_id");
while ($row = mysqli_fetch_assoc($result)) {
    $daily[$row['date']][$row['barber_id']] = $row;
}
$last_day = min($to, date('Y-m-d'));

$reviews = mysqli_fetch_all(mysqli_query($conn, "
    SELECT v.*, s.name AS barber, c.username FROM review v
    LEFT JOIN staff s ON s.staff_id = v.barber_id LEFT JOIN customer c ON c.cust_id = v.cust_id
    WHERE v.created_at BETWEEN '$from 00:00:00' AND '$to 23:59:59'
    ORDER BY v.created_at DESC LIMIT 30"), MYSQLI_ASSOC);

admin_header('Performance', 'performance');
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h3 mb-0">Staff performance &middot; <?php echo date('F Y', strtotime($from)); ?></h1>
    <?php month_picker($month); ?>
</div>

<div class="card mb-4">
    <div class="card-header">Who customers like most</div>
    <div class="table-responsive">
    <table class="table mb-0 align-middle">
        <thead>
            <tr>
                <th>Barber</th>
                <th class="num">Picked by name</th>
                <th>Rating</th>
                <th class="num">Customers done</th>
                <th class="num">Sales brought in</th>
                <th class="num">Days worked</th>
                <th class="num">Times late</th>
            </tr>
        </thead>
        <tbody>
        <?php if (count($barbers) === 0) { ?>
            <tr><td colspan="7" class="text-center text-muted py-4">No barbers yet.</td></tr>
        <?php } ?>
        <?php foreach ($barbers as $b) {
            $p = $perf[$b['staff_id']] ?? ['bookings' => 0, 'customers' => 0, 'sales' => 0, 'chosen' => 0, 'rating' => null, 'reviews' => 0];
            $a = $attend[$b['staff_id']] ?? ['days' => 0, 'late_count' => 0];
            $share = $p['bookings'] > 0 ? round($p['chosen'] / $p['bookings'] * 100) : 0; ?>
            <tr>
                <td>
                    <strong><?php echo e($b['name']); ?></strong>
                    <?php if ($most_chosen > 0 && (int)$p['chosen'] === $most_chosen) { ?><span class="badge bg-dark ms-1">Most requested</span><?php } ?>
                    <?php if ($best_rating > 0 && $p['reviews'] > 0 && (float)$p['rating'] === $best_rating) { ?><span class="badge badge-tan ms-1">Top rated</span><?php } ?>
                    <?php echo $b['active'] ? '' : ' <span class="badge bg-secondary">Disabled</span>'; ?>
                </td>
                <td class="num"><?php echo (int)$p['chosen']; ?> <span class="text-muted small">of <?php echo (int)$p['bookings']; ?> (<?php echo $share; ?>%)</span></td>
                <td><?php echo stars_text($p['rating'], $p['reviews']); ?></td>
                <td class="num"><?php echo (int)$p['customers']; ?></td>
                <td class="num"><?php echo rm($p['sales']); ?></td>
                <td class="num"><?php echo (int)$a['days']; ?></td>
                <td class="num <?php echo $a['late_count'] > 0 ? 'text-danger' : ''; ?>"><?php echo (int)$a['late_count']; ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
    </div>
    <div class="card-footer small text-muted"><strong>Picked by name</strong> = the customer chose this barber instead of "Any barber". <strong>Sales brought in</strong> = finished haircuts only.</div>
</div>

<div class="row g-4">
    <div class="col-xl-7">
        <div class="card h-100">
            <div class="card-header">Daily sales per barber</div>
            <div class="table-responsive" style="max-height: 520px">
            <table class="table table-sm mb-0">
                <thead class="sticky-top bg-white">
                    <tr><th>Date</th><?php foreach ($barbers as $b) { ?><th class="num"><?php echo e($b['name']); ?></th><?php } ?></tr>
                </thead>
                <tbody>
                <?php $totals = [];
                if ($from > $last_day) { ?>
                    <tr><td colspan="<?php echo count($barbers) + 1; ?>" class="text-center text-muted py-4">This month hasn't started yet.</td></tr>
                <?php }
                for ($d = $last_day; $d >= $from; $d = date('Y-m-d', strtotime("$d -1 day"))) { ?>
                    <tr class="<?php echo $d === date('Y-m-d') ? 'table-light fw-semibold' : ''; ?>">
                        <td class="text-nowrap"><?php echo date('D j', strtotime($d)); ?></td>
                        <?php foreach ($barbers as $b) {
                            $cell = $daily[$d][$b['staff_id']] ?? null;
                            $totals[$b['staff_id']] = ($totals[$b['staff_id']] ?? 0) + ($cell['sales'] ?? 0); ?>
                        <td class="num"><?php echo $cell ? rm($cell['sales']) . ' <span class="text-muted small">(' . $cell['n'] . ')</span>' : '<span class="text-muted">-</span>'; ?></td>
                        <?php } ?>
                    </tr>
                <?php } ?>
                </tbody>
                <tfoot class="table-light">
                    <tr><th>Total</th><?php foreach ($barbers as $b) { ?><th class="num"><?php echo rm($totals[$b['staff_id']] ?? 0); ?></th><?php } ?></tr>
                </tfoot>
            </table>
            </div>
            <div class="card-footer small text-muted">Number in brackets = customers that day.</div>
        </div>
    </div>
    <div class="col-xl-5">
        <div class="card h-100">
            <div class="card-header">Customer reviews</div>
            <ul class="list-group list-group-flush" style="max-height: 560px; overflow-y: auto">
                <?php if (count($reviews) === 0) { ?>
                <li class="list-group-item text-muted text-center py-4">No reviews this month. Customers can rate a finished haircut from "My bookings".</li>
                <?php } ?>
                <?php foreach ($reviews as $v) { ?>
                <li class="list-group-item">
                    <div class="d-flex justify-content-between">
                        <strong><?php echo e($v['barber'] ?? '-'); ?></strong>
                        <span class="small text-muted"><?php echo date('j M', strtotime($v['created_at'])); ?></span>
                    </div>
                    <div><?php echo stars_text($v['stars'], 1, false); ?></div>
                    <?php if ($v['comment'] !== '') { ?><div class="small">&ldquo;<?php echo e($v['comment']); ?>&rdquo;</div><?php } ?>
                    <div class="small text-muted">&mdash; <?php echo e($v['username'] ?? 'customer'); ?></div>
                </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</div>
<?php admin_footer(); ?>
