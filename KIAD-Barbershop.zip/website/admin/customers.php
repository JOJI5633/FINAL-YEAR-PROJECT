<?php
include __DIR__ . '/_auth.php';
include __DIR__ . '/_layout.php';
include __DIR__ . '/../customer_lib.php';
require_owner();

// Give a customer a temporary password (they must change it after logging in)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reset') {
    $id = (int)($_POST['cust_id'] ?? 0);
    $stmt = mysqli_prepare($conn, "SELECT cust_id, username FROM customer WHERE cust_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $customer = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($customer) {
        // Easy to read out: no 0/O or 1/l
        $letters = 'abcdefghjkmnpqrstuvwxyz23456789';
        $temp = '';
        for ($i = 0; $i < 8; $i++) {
            $temp .= $letters[random_int(0, strlen($letters) - 1)];
        }
        set_customer_password($conn, $customer['cust_id'], $temp, 1);
        $_SESSION['reset_result'] = ['username' => $customer['username'], 'password' => $temp];
    }
    header("Location: customers.php?q=" . urlencode($_POST['q'] ?? ''));
    exit();
}

$reset = $_SESSION['reset_result'] ?? null;
unset($_SESSION['reset_result']);

$q = trim($_GET['q'] ?? '');
$like = '%' . $q . '%';
$stmt = mysqli_prepare($conn, "
    SELECT c.cust_id, c.username, c.email, c.must_change_password,
           COUNT(r.receipt_ID) AS bookings, MAX(r.date) AS last_booking
    FROM customer c LEFT JOIN receipt r ON r.cust_id = c.cust_id
    WHERE c.username LIKE ? OR c.email LIKE ?
    GROUP BY c.cust_id, c.username, c.email, c.must_change_password
    ORDER BY c.cust_id DESC LIMIT 200");
mysqli_stmt_bind_param($stmt, 'ss', $like, $like);
mysqli_stmt_execute($stmt);
$customers = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

$login_url = preg_replace('#/admin/$#', '/', admin_url('')) . 'Login.php';

admin_header('Customers', 'customers');
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h3 mb-0">Customers</h1>
    <form method="get" class="d-flex gap-2">
        <input class="form-control form-control-sm" name="q" value="<?php echo e($q); ?>" placeholder="Search username or email" aria-label="Search customers">
        <button class="btn btn-sm btn-dark">Search</button>
    </form>
</div>

<?php if ($reset) {
    $message = "Hi {$reset['username']}, your temporary password for KI'AD is: {$reset['password']}\n"
             . "Log in at $login_url and choose a new password."; ?>
<div class="card border-success mb-4">
    <div class="card-body">
        <h2 class="h5"><i class="fa-solid fa-key text-success"></i> Temporary password for <?php echo e($reset['username']); ?></h2>
        <p class="display-6 font-monospace mb-2" style="letter-spacing: 3px"><?php echo e($reset['password']); ?></p>
        <p class="small text-muted">Shown only once. Send it to the customer; after logging in they must choose their own password.</p>
        <label class="form-label small" for="reset-message">Message to send</label>
        <textarea class="form-control mb-2" id="reset-message" rows="2" readonly><?php echo e($message); ?></textarea>
        <button class="btn btn-sm btn-outline-dark" type="button" onclick="navigator.clipboard.writeText(document.getElementById('reset-message').value); this.textContent='Copied'">Copy message</button>
    </div>
</div>
<?php } ?>

<div class="alert alert-light border small">
    <i class="fa-solid fa-shield-halved"></i> Before resetting, make sure it's really them &mdash; for example ask for the email on the account or the date of their last booking.
</div>

<div class="card">
<div class="table-responsive">
<table class="table mb-0 align-middle">
    <thead><tr><th>Username</th><th>Email</th><th class="num">Bookings</th><th>Last booking</th><th></th></tr></thead>
    <tbody>
    <?php if (count($customers) === 0) { ?>
        <tr><td colspan="5" class="text-center text-muted py-4"><?php echo $q !== '' ? 'No customer matches "' . e($q) . '".' : 'No customers yet.'; ?></td></tr>
    <?php } ?>
    <?php foreach ($customers as $c) { ?>
        <tr>
            <td><?php echo e($c['username']); ?><?php echo $c['must_change_password'] ? ' <span class="badge bg-warning text-dark">Has temporary password</span>' : ''; ?></td>
            <td><?php echo e($c['email']); ?></td>
            <td class="num"><?php echo (int)$c['bookings']; ?></td>
            <td><?php echo $c['last_booking'] ? date('j M Y', strtotime($c['last_booking'])) : '<span class="text-muted">-</span>'; ?></td>
            <td class="text-end">
                <form method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="cust_id" value="<?php echo $c['cust_id']; ?>">
                    <input type="hidden" name="q" value="<?php echo e($q); ?>">
                    <button class="btn btn-sm btn-outline-dark" name="action" value="reset" onclick="return confirm('Give <?php echo e(addslashes($c['username'])); ?> a temporary password? Their old password stops working.')"><i class="fa-solid fa-key"></i> Reset password</button>
                </form>
            </td>
        </tr>
    <?php } ?>
    </tbody>
</table>
</div>
</div>
<?php admin_footer(); ?>
