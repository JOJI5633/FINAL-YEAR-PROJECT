<?php
// Top of every admin page except login: must be logged in as staff
include __DIR__ . '/_base.php';

if (!isset($_SESSION['staff_id'])) {
    // Come back to this page after logging in (e.g. an attendance scan)
    $here = basename($_SERVER['SCRIPT_NAME']) . (!empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : '');
    header("Location: ../Login.php?next=" . urlencode($here));
    exit();
}

// Read the account again every time, so a disabled account is locked out straight away
$stmt = mysqli_prepare($conn, "SELECT staff_id, name, username, role, is_barber, active FROM staff WHERE staff_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $_SESSION['staff_id']);
mysqli_stmt_execute($stmt);
$me = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$me || !$me['active']) {
    unset($_SESSION['staff_id']);
    header("Location: ../Login.php?disabled=1");
    exit();
}
$is_owner = $me['role'] === 'owner';

check_csrf();

// Pages only the owner may open: services, staff, settings
function require_owner() {
    global $is_owner;
    if (!$is_owner) {
        flash('Only the owner can open that page.', 'danger');
        header("Location: index.php");
        exit();
    }
}
