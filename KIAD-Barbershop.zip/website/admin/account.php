<?php
include __DIR__ . '/_auth.php';
include __DIR__ . '/_layout.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = $_POST['current'] ?? '';
    $new = $_POST['new'] ?? '';

    $stmt = mysqli_prepare($conn, "SELECT password_hash FROM staff WHERE staff_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $me['staff_id']);
    mysqli_stmt_execute($stmt);
    $hash = mysqli_fetch_row(mysqli_stmt_get_result($stmt))[0];

    if (!password_verify($current, $hash)) {
        $error = 'Your current password is wrong.';
    } elseif (strlen($new) < 6) {
        $error = 'The new password must be at least 6 characters.';
    } elseif ($new !== ($_POST['confirm'] ?? '')) {
        $error = 'The two new passwords are not the same.';
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "UPDATE staff SET password_hash = ? WHERE staff_id = ?");
        mysqli_stmt_bind_param($stmt, 'si', $hash, $me['staff_id']);
        mysqli_stmt_execute($stmt);
        unset($_SESSION['weak_passwords']);   // re-check the starter-password warning
        flash('Password changed.');
        header("Location: account.php");
        exit();
    }
}

admin_header('My account', 'account');
?>
<h1 class="h3 mb-3">My account</h1>
<div class="row">
    <div class="col-md-6 col-lg-4">
        <div class="card mb-3">
            <div class="card-body">
                <div><strong><?php echo e($me['name']); ?></strong></div>
                <div class="text-muted small">Username: <?php echo e($me['username']); ?> &middot; <?php echo $is_owner ? 'Owner' : 'Staff'; ?></div>
            </div>
        </div>
        <form method="post" class="card">
            <div class="card-header">Change password</div>
            <div class="card-body">
                <?php if ($error) { ?><div class="alert alert-danger py-2"><?php echo e($error); ?></div><?php } ?>
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label" for="current">Current password</label>
                    <input class="form-control" type="password" id="current" name="current" required autocomplete="current-password">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="new">New password</label>
                    <input class="form-control" type="password" id="new" name="new" minlength="6" required autocomplete="new-password">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="confirm">New password again</label>
                    <input class="form-control" type="password" id="confirm" name="confirm" minlength="6" required autocomplete="new-password">
                </div>
                <button class="btn btn-brand">Change password</button>
            </div>
        </form>
    </div>
</div>
<?php admin_footer(); ?>
