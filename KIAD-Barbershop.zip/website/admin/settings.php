<?php
include __DIR__ . '/_auth.php';
include __DIR__ . '/_layout.php';
require_owner();

function save_setting($conn, $name, $value) {
    $stmt = mysqli_prepare($conn, "REPLACE INTO setting (name, value) VALUES (?, ?)");
    mysqli_stmt_bind_param($stmt, 'ss', $name, $value);
    mysqli_stmt_execute($stmt);
}

// Turn what the owner typed into a full link: a link, "instagram.com/kiad", or just "@kiad"
function social_url($platform, $input) {
    $input = trim($input);
    if ($input === '') {
        return '';
    }
    if (preg_match('#^(www\.)?[a-z0-9-]+(\.[a-z0-9-]+)+/#i', $input)) {
        $input = 'https://' . $input;
    }
    if (preg_match('#^https?://#i', $input)) {
        return filter_var($input, FILTER_VALIDATE_URL) ? $input : null;
    }
    $handle = ltrim($input, '@');
    if (!preg_match('/^[A-Za-z0-9._-]{1,60}$/', $handle)) {
        return null;
    }
    $base = ['instagram' => 'https://www.instagram.com/', 'facebook' => 'https://www.facebook.com/', 'twitter' => 'https://x.com/'];
    return $base[$platform] . $handle;
}

$weekdays = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 0 => 'Sunday'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'hours') {
        $open = $_POST['open_time'] ?? '';
        $close = $_POST['close_time'] ?? '';
        $slot = (int)($_POST['slot_minutes'] ?? 30);
        $grace = $_POST['late_grace_minutes'] ?? '5';
        $closed = array_intersect(array_map('strval', array_keys($weekdays)), (array)($_POST['closed_days'] ?? []));

        if (!preg_match('/^\d{2}:\d{2}$/', $open) || !preg_match('/^\d{2}:\d{2}$/', $close) || $open >= $close) {
            $error = 'Closing time must be after opening time.';
        } elseif (!in_array($slot, [15, 20, 30, 45, 60])) {
            $error = 'Please choose a slot length.';
        } elseif (count($closed) === 7) {
            $error = 'The shop cannot be closed every day.';
        } elseif (!ctype_digit((string)$grace) || $grace > 60) {
            $error = 'Late after must be 0 to 60 minutes.';
        } else {
            save_setting($conn, 'open_time', $open);
            save_setting($conn, 'close_time', $close);
            save_setting($conn, 'slot_minutes', (string)$slot);
            save_setting($conn, 'closed_days', implode(',', $closed));
            save_setting($conn, 'late_grace_minutes', (string)(int)$grace);
            flash('Opening hours saved.');
            header("Location: settings.php");
            exit();
        }
    } elseif ($action === 'qr') {
        $upload = save_image_upload($_FILES['qr'] ?? null, 'images', 'qr-upload-');
        if (isset($upload['error'])) {
            $error = $upload['error'];
        } else {
            // Delete the previous uploaded QR (the sample placeholder is kept)
            $previous = setting($conn, 'qr_image');
            if (strpos($previous, 'images/qr-upload-') === 0 && is_file(__DIR__ . '/../' . $previous)) {
                unlink(__DIR__ . '/../' . $previous);
            }
            save_setting($conn, 'qr_image', $upload['path']);
            flash('New payment QR saved. Customers see it on the payment page now.');
            header("Location: settings.php");
            exit();
        }
    } elseif ($action === 'location') {
        $address = trim($_POST['shop_address'] ?? '');
        $phone = trim($_POST['shop_phone'] ?? '');
        $embed = trim($_POST['map_embed'] ?? '');
        // Google's "Embed a map" gives <iframe src="...">; keep just the link
        if (preg_match('/src="([^"]+)"/', $embed, $m)) {
            $embed = html_entity_decode($m[1]);
        }

        if ($address === '' || strlen($address) > 255) {
            $error = 'Please enter the shop address.';
        } elseif (strlen($phone) > 30) {
            $error = 'The phone number is too long.';
        } elseif ($embed !== '' && !preg_match('#^https://(www\.)?google\.[a-z.]+/maps/embed\?#', $embed)) {
            $error = 'That map link is not a Google Maps embed link. In Google Maps: Share → Embed a map → Copy HTML, then paste it here. Or leave it empty.';
        } else {
            save_setting($conn, 'shop_address', $address);
            save_setting($conn, 'shop_phone', $phone);
            save_setting($conn, 'map_embed', $embed);
            flash('Location saved. The home page shows the new address and map now.');
            header("Location: settings.php#location");
            exit();
        }
    } elseif ($action === 'social') {
        $links = [];
        foreach (['instagram' => 'Instagram', 'facebook' => 'Facebook', 'twitter' => 'Twitter / X'] as $platform => $name) {
            $url = social_url($platform, $_POST[$platform] ?? '');
            if ($url === null) {
                $error = "The $name link doesn't look right. Paste the full link (https://...) or just the username.";
                break;
            }
            $links[$platform] = $url;
        }
        if ($error === '') {
            foreach ($links as $platform => $url) {
                save_setting($conn, 'social_' . $platform, $url);
            }
            flash('Social media links saved. The icons at the bottom of the home page open them now.');
            header("Location: settings.php#social");
            exit();
        }
    } elseif ($action === 'policy') {
        $terms = trim($_POST['policy_terms'] ?? '');
        $privacy = trim($_POST['policy_privacy'] ?? '');
        if ($terms === '' || $privacy === '') {
            $error = 'Terms and privacy policy cannot be empty.';
        } elseif (strlen($terms) > 5000 || strlen($privacy) > 5000) {
            $error = 'Please keep each text under 5000 characters.';
        } else {
            save_setting($conn, 'policy_terms', $terms);
            save_setting($conn, 'policy_privacy', $privacy);
            flash('Terms & privacy saved.');
            header("Location: settings.php#policy");
            exit();
        }
    } elseif ($action === 'whatsapp') {
        // Accept "011-2166 7246" or "+60 11 2166 7246", store as 601121667246
        $number = preg_replace('/\D/', '', $_POST['whatsapp_number'] ?? '');
        if (strpos($number, '0') === 0) {
            $number = '6' . $number;
        }
        if (strlen($number) < 10 || strlen($number) > 15) {
            $error = 'Please enter a WhatsApp number, for example 011-2166 7246.';
        } else {
            save_setting($conn, 'whatsapp_number', $number);
            flash('WhatsApp number saved.');
            header("Location: settings.php");
            exit();
        }
    } elseif ($action === 'logo' || $action === 'logo_default') {
        $new = 'images/logo.png';
        if ($action === 'logo') {
            $upload = save_image_upload($_FILES['logo'] ?? null, 'images', 'logo-upload-');
            $new = $upload['path'] ?? null;
            $error = $upload['error'] ?? '';
        }
        if ($new) {
            // Delete the previous uploaded logo (the original KI'AD logo is kept)
            $previous = setting($conn, 'logo_image');
            if (strpos($previous, 'images/logo-upload-') === 0 && is_file(__DIR__ . '/../' . $previous)) {
                unlink(__DIR__ . '/../' . $previous);
            }
            save_setting($conn, 'logo_image', $new);
            flash($action === 'logo' ? 'New logo saved. It shows on every page now.' : 'Back to the original logo.');
            header("Location: settings.php");
            exit();
        }
    } elseif ($action === 'login_bg') {
        // Choose one of the wallpapers + how dark it is
        $bg = $_POST['login_bg'] ?? '';
        $dim = $_POST['login_bg_dim'] ?? '';
        $choices = array_merge(['plain', 'video', LOGIN_BG_DEFAULT], login_bg_uploads());
        if (!in_array($bg, $choices, true)) {
            $error = 'Please choose a background.';
        } elseif (!ctype_digit((string)$dim) || $dim > 85) {
            $error = 'Darkness must be 0 to 85%.';
        } else {
            save_setting($conn, 'login_bg', $bg);
            save_setting($conn, 'login_bg_dim', (string)(int)$dim);
            flash('Login background saved. Customers see it on the login page now.');
            header("Location: settings.php#login-bg");
            exit();
        }
    } elseif ($action === 'login_bg_upload') {
        if (count(login_bg_uploads()) >= 12) {
            $error = 'You already have 12 backgrounds. Delete one you don\'t use first.';
        } else {
            if (!is_dir(__DIR__ . '/../' . LOGIN_BG_DIR)) {
                mkdir(__DIR__ . '/../' . LOGIN_BG_DIR, 0755, true);
            }
            $upload = save_image_upload($_FILES['login_bg_file'] ?? null, LOGIN_BG_DIR, 'bg-');
            if (isset($upload['error'])) {
                $error = $upload['error'];
            } else {
                // A new picture is used straight away
                save_setting($conn, 'login_bg', $upload['path']);
                flash('New background uploaded and now used on the login page.');
                header("Location: settings.php#login-bg");
                exit();
            }
        }
    } elseif ($action === 'login_bg_delete') {
        $file = $_POST['bg_file'] ?? '';
        if (in_array($file, login_bg_uploads(), true)) {
            unlink(__DIR__ . '/../' . $file);
            if (setting($conn, 'login_bg') === $file) {
                save_setting($conn, 'login_bg', LOGIN_BG_DEFAULT);
                flash('Background deleted. The login page is back to the shop photo.');
            } else {
                flash('Background deleted.');
            }
        }
        header("Location: settings.php#login-bg");
        exit();
    } elseif ($action === 'add_holiday') {
        $date = $_POST['holiday_date'] ?? '';
        $note = trim($_POST['note'] ?? '');
        $d = DateTime::createFromFormat('Y-m-d', $date);
        if (!$d || $d->format('Y-m-d') !== $date) {
            $error = 'Please choose a date.';
        } else {
            $stmt = mysqli_prepare($conn, "REPLACE INTO holiday (holiday_date, note) VALUES (?, ?)");
            mysqli_stmt_bind_param($stmt, 'ss', $date, $note);
            mysqli_stmt_execute($stmt);

            $stmt = mysqli_prepare($conn, "SELECT COUNT(*) FROM receipt WHERE date = ? AND job_status = 'booked'");
            mysqli_stmt_bind_param($stmt, 's', $date);
            mysqli_stmt_execute($stmt);
            $booked = mysqli_fetch_row(mysqli_stmt_get_result($stmt))[0];
            if ($booked > 0) {
                flash("Shop closed on " . date('j M Y', strtotime($date)) . ". There are already $booked booking(s) that day, contact the customers or cancel them.", 'warning');
                header("Location: bookings.php?when=upcoming");
                exit();
            }
            flash('Shop closed on ' . date('j M Y', strtotime($date)) . '. Customers can no longer book that day.');
            header("Location: settings.php");
            exit();
        }
    } elseif ($action === 'remove_holiday') {
        $date = $_POST['holiday_date'] ?? '';
        $stmt = mysqli_prepare($conn, "DELETE FROM holiday WHERE holiday_date = ?");
        mysqli_stmt_bind_param($stmt, 's', $date);
        mysqli_stmt_execute($stmt);
        flash('Holiday removed. Customers can book that day again.');
        header("Location: settings.php");
        exit();
    }
}

$closed_days = array_filter(explode(',', setting($conn, 'closed_days')), 'strlen');
$holidays = mysqli_fetch_all(mysqli_query($conn, "SELECT * FROM holiday WHERE holiday_date >= CURDATE() ORDER BY holiday_date"), MYSQLI_ASSOC);
$qr = setting($conn, 'qr_image');
$login_bg = login_background($conn);
$bg_uploads = login_bg_uploads();

admin_header('Settings', 'settings');
?>
<h1 class="h3 mb-3">Shop settings</h1>
<?php if ($error) { ?><div class="alert alert-danger"><?php echo e($error); ?></div><?php } ?>

<div class="row g-4">
    <div class="col-lg-6">
        <form method="post" class="card h-100">
            <div class="card-header">Opening hours</div>
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="hours">
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label class="form-label" for="open_time">Opens</label>
                        <input class="form-control" type="time" id="open_time" name="open_time" value="<?php echo e(setting($conn, 'open_time')); ?>" required>
                    </div>
                    <div class="col-6">
                        <label class="form-label" for="close_time">Closes</label>
                        <input class="form-control" type="time" id="close_time" name="close_time" value="<?php echo e(setting($conn, 'close_time')); ?>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="slot_minutes">Time per customer</label>
                    <select class="form-select" id="slot_minutes" name="slot_minutes">
                        <?php foreach ([15, 20, 30, 45, 60] as $m) { ?>
                        <option value="<?php echo $m; ?>" <?php echo (int)setting($conn, 'slot_minutes') === $m ? 'selected' : ''; ?>><?php echo $m; ?> minutes</option>
                        <?php } ?>
                    </select>
                    <div class="form-text">Each barber takes one customer per slot.</div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="late_grace_minutes">Staff count as late after</label>
                    <div class="input-group" style="max-width: 220px">
                        <input class="form-control" type="number" id="late_grace_minutes" name="late_grace_minutes" min="0" max="60" required value="<?php echo (int)setting($conn, 'late_grace_minutes'); ?>">
                        <span class="input-group-text">minutes</span>
                    </div>
                    <div class="form-text">Minutes after a staff's start time before the attendance says "Late".</div>
                </div>
                <fieldset class="mb-3">
                    <legend class="form-label fs-6">Closed every</legend>
                    <?php foreach ($weekdays as $num => $day) { ?>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="checkbox" id="day-<?php echo $num; ?>" name="closed_days[]" value="<?php echo $num; ?>" <?php echo in_array((string)$num, $closed_days, true) ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="day-<?php echo $num; ?>"><?php echo $day; ?></label>
                    </div>
                    <?php } ?>
                </fieldset>
                <button class="btn btn-brand">Save hours</button>
            </div>
        </form>
    </div>

    <div class="col-lg-6">
        <form method="post" enctype="multipart/form-data" class="card h-100">
            <div class="card-header">Payment QR</div>
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="qr">
                <div class="d-flex gap-3 align-items-start flex-wrap">
                    <img src="../<?php echo e($qr); ?>" alt="Current payment QR" style="width: 160px; border: 1px solid #ddd; border-radius: 8px;">
                    <div class="flex-grow-1">
                        <p class="small text-muted">Customers who choose <strong>Online payment</strong> scan this QR, then upload their receipt for you to check.</p>
                        <label class="form-label" for="qr">Upload your QR</label>
                        <input class="form-control mb-3" type="file" id="qr" name="qr" accept="image/jpeg,image/png,image/webp" required>
                        <button class="btn btn-brand">Save QR</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="col-12" id="location">
        <form method="post" class="card">
            <div class="card-header">Location &amp; contact (home page)</div>
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="location">
                <div class="row g-4">
                    <div class="col-lg-5">
                        <div class="mb-3">
                            <label class="form-label" for="shop_address">Shop address</label>
                            <textarea class="form-control" id="shop_address" name="shop_address" rows="3" maxlength="255" required><?php echo e(setting($conn, 'shop_address')); ?></textarea>
                            <div class="form-text">The map finds the shop from this address.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="shop_phone">Phone shown on the home page</label>
                            <input class="form-control" id="shop_phone" name="shop_phone" maxlength="30" value="<?php echo e(setting($conn, 'shop_phone')); ?>" inputmode="tel">
                        </div>
                        <details class="mb-3" <?php echo setting($conn, 'map_embed') !== '' ? 'open' : ''; ?>>
                            <summary class="small">Map pin in the wrong place?</summary>
                            <p class="small text-muted mt-2 mb-2">Open <strong>Google Maps</strong>, find your shop, tap <strong>Share &rarr; Embed a map &rarr; Copy HTML</strong>, and paste it below. Leave empty to use the address.</p>
                            <textarea class="form-control form-control-sm font-monospace" id="map_embed" name="map_embed" rows="3" placeholder='<iframe src="https://www.google.com/maps/embed?pb=..."></iframe>' aria-label="Google Maps embed code"><?php echo e(setting($conn, 'map_embed')); ?></textarea>
                        </details>
                        <button class="btn btn-brand">Save location</button>
                    </div>
                    <div class="col-lg-7">
                        <div class="small text-muted mb-1">Map customers see now</div>
                        <iframe src="<?php echo e(map_src($conn)); ?>" title="Current map" style="width: 100%; height: 260px; border: 1px solid #ddd; border-radius: 8px" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="col-lg-6">
        <form method="post" class="card h-100">
            <div class="card-header">Shop WhatsApp</div>
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="whatsapp">
                <p class="small text-muted">Customers who forget their password tap a button that opens WhatsApp to this number. You then reset it in <strong>Manage &rarr; Customers</strong>.</p>
                <label class="form-label" for="whatsapp_number">WhatsApp number</label>
                <div class="d-flex gap-2 flex-wrap">
                    <input class="form-control" id="whatsapp_number" name="whatsapp_number" style="max-width: 240px" required
                           value="<?php echo e('+' . setting($conn, 'whatsapp_number')); ?>" inputmode="tel">
                    <button class="btn btn-brand">Save</button>
                    <a class="btn btn-outline-success" target="_blank" href="https://wa.me/<?php echo e(setting($conn, 'whatsapp_number')); ?>"><i class="fa-brands fa-whatsapp"></i> Test</a>
                </div>
            </div>
        </form>
    </div>

    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header">Logo</div>
            <div class="card-body">
                <div class="d-flex gap-3 align-items-center flex-wrap mb-3">
                    <div class="logo-preview"><img id="logo-preview" src="../<?php echo e(logo($conn)); ?>" alt="Current logo"></div>
                    <p class="small text-muted mb-0 flex-grow-1" style="min-width: 200px">Shows on the home page, booking pages, login and admin. Best: a <strong>PNG with a transparent background</strong> and light-coloured text (the website is dark). Empty space around it is cut off automatically.</p>
                </div>
                <form method="post" enctype="multipart/form-data" class="d-flex flex-wrap gap-2">
                    <?php echo csrf_field(); ?>
                    <input class="form-control" type="file" id="logo" name="logo" accept="image/png,image/webp,image/jpeg" required style="max-width: 320px" aria-label="New logo">
                    <button class="btn btn-brand" name="action" value="logo">Save logo</button>
                </form>
                <?php if (setting($conn, 'logo_image') !== 'images/logo.png') { ?>
                <form method="post" class="mt-2">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-sm btn-link px-0" name="action" value="logo_default">Use the original KI'AD logo again</button>
                </form>
                <?php } ?>
            </div>
        </div>
    </div>

    <div class="col-12" id="login-bg">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                <span>Login page background</span>
                <a href="../Login.php" target="_blank" class="small fw-normal">See the login page &rarr;</a>
            </div>
            <div class="card-body">
                <p class="small text-muted">The wallpaper behind the log in / sign up box &mdash; the first page customers see. Pick one and press <strong>Save background</strong>, or upload your own photo below.</p>
                <?php
                // [value, name, thumbnail]
                $bg_options = [
                    ['plain', 'Plain dark', ''],
                    [LOGIN_BG_DEFAULT, 'Shop photo', '../' . LOGIN_BG_DEFAULT],
                    ['video', 'Shop video (moving)', ''],
                ];
                foreach ($bg_uploads as $file) {
                    $bg_options[] = [$file, 'Uploaded ' . date('j M', filemtime(__DIR__ . '/../' . $file)), '../' . $file];
                }
                ?>
                <form method="post" id="bg-form">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="login_bg">
                    <div class="bg-grid" id="bg-grid" style="--dim: <?php echo $login_bg['dim'] / 100; ?>">
                        <?php foreach ($bg_options as $i => [$value, $name, $thumb]) {
                            $live = $login_bg['bg'] === $value; ?>
                        <div class="bg-option">
                            <input type="radio" name="login_bg" id="bg-<?php echo $i; ?>" value="<?php echo e($value); ?>" <?php echo $live ? 'checked' : ''; ?>>
                            <label for="bg-<?php echo $i; ?>">
                                <span class="bg-thumb <?php echo $value === 'plain' ? 'plain' : ''; ?>" <?php echo $thumb ? 'style="background-image: url(\'' . e($thumb) . '\')"' : ''; ?>>
                                    <?php if ($value === 'video') { ?>
                                    <video src="../background.mp4#t=2" muted playsinline preload="metadata" aria-hidden="true"></video>
                                    <?php } ?>
                                    <span class="bg-dim"></span>
                                    <span class="bg-card"></span>
                                </span>
                                <span class="bg-name"><?php echo e($name); ?><?php if ($live) { ?> <span class="badge badge-tan">In use</span><?php } ?></span>
                            </label>
                            <?php if (in_array($value, $bg_uploads, true)) { ?>
                            <button class="bg-delete" form="bg-delete" name="bg_file" value="<?php echo e($value); ?>" title="Delete this background" aria-label="Delete <?php echo e($name); ?>"
                                    onclick="return confirm('Delete this background?')"><i class="fa-solid fa-trash"></i></button>
                            <?php } ?>
                        </div>
                        <?php } ?>
                    </div>
                    <div class="d-flex flex-wrap align-items-end gap-3 mt-3">
                        <div style="width: 260px">
                            <label class="form-label mb-1" for="login_bg_dim">Darken the picture: <strong id="dim-value"><?php echo $login_bg['dim']; ?>%</strong></label>
                            <input type="range" class="form-range" id="login_bg_dim" name="login_bg_dim" min="0" max="85" step="5" value="<?php echo $login_bg['dim']; ?>">
                        </div>
                        <button class="btn btn-brand">Save background</button>
                        <span class="form-text mt-0 mb-2">Darker makes the words on a bright photo easier to read.</span>
                    </div>
                </form>
                <form method="post" id="bg-delete">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="login_bg_delete">
                </form>

                <hr>
                <form method="post" enctype="multipart/form-data" class="d-flex flex-wrap gap-2 align-items-center">
                    <?php echo csrf_field(); ?>
                    <label class="form-label mb-0 me-1" for="login_bg_file">Your own photo</label>
                    <input class="form-control" type="file" id="login_bg_file" name="login_bg_file" accept="image/jpeg,image/png,image/webp" required style="max-width: 320px">
                    <button class="btn btn-outline-dark" name="action" value="login_bg_upload"><i class="fa-solid fa-upload"></i> Upload &amp; use</button>
                    <span class="form-text mt-0 w-100">JPG, PNG or WEBP. A wide (landscape) photo looks best. Big phone photos are made smaller automatically so the page stays fast.</span>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header">Holidays &amp; days off</div>
            <div class="card-body">
                <form method="post" class="row g-2 align-items-end mb-3">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="add_holiday">
                    <div class="col-sm-4 col-lg-3">
                        <label class="form-label" for="holiday_date">Date</label>
                        <input class="form-control" type="date" id="holiday_date" name="holiday_date" min="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-sm-5 col-lg-4">
                        <label class="form-label" for="note">Reason (optional)</label>
                        <input class="form-control" id="note" name="note" maxlength="100" placeholder="e.g. Hari Raya">
                    </div>
                    <div class="col-auto"><button class="btn btn-brand">Close shop this day</button></div>
                </form>
                <?php if (count($holidays) === 0) { ?>
                <p class="text-muted mb-0">No upcoming holidays.</p>
                <?php } else { ?>
                <ul class="list-group">
                    <?php foreach ($holidays as $h) { ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><strong><?php echo date('l, j F Y', strtotime($h['holiday_date'])); ?></strong> <?php echo $h['note'] !== '' ? '&middot; ' . e($h['note']) : ''; ?></span>
                        <form method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="action" value="remove_holiday">
                            <input type="hidden" name="holiday_date" value="<?php echo e($h['holiday_date']); ?>">
                            <button class="btn btn-sm btn-outline-danger">Remove</button>
                        </form>
                    </li>
                    <?php } ?>
                </ul>
                <?php } ?>
            </div>
        </div>
    </div>

    <div class="col-lg-6" id="social">
        <form method="post" class="card h-100">
            <div class="card-header">Social media (home page icons)</div>
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="social">
                <p class="small text-muted">Paste the link to the shop's page, or just the username. Leave empty to hide that icon.</p>
                <?php foreach (['instagram' => ['Instagram', 'fa-instagram', '@kiadbarber'], 'facebook' => ['Facebook', 'fa-facebook', 'https://www.facebook.com/kiadbarber'], 'twitter' => ['Twitter / X', 'fa-twitter', '@kiadbarber']] as $platform => [$name, $icon, $example]) {
                    $url = setting($conn, 'social_' . $platform); ?>
                <div class="mb-3">
                    <label class="form-label" for="<?php echo $platform; ?>"><i class="fa-brands <?php echo $icon; ?> me-1"></i><?php echo $name; ?></label>
                    <div class="input-group">
                        <input class="form-control" id="<?php echo $platform; ?>" name="<?php echo $platform; ?>" value="<?php echo e($url); ?>" placeholder="<?php echo e($example); ?>">
                        <?php if ($url !== '') { ?><a class="btn btn-outline-secondary" href="<?php echo e($url); ?>" target="_blank" rel="noopener">Open</a><?php } ?>
                    </div>
                </div>
                <?php } ?>
                <p class="small text-muted"><i class="fa-brands fa-whatsapp"></i> The WhatsApp icon uses the <strong>Shop WhatsApp</strong> number above.</p>
                <button class="btn btn-brand">Save links</button>
            </div>
        </form>
    </div>

    <div class="col-12" id="policy">
        <form method="post" class="card">
            <div class="card-header">Terms &amp; privacy (links at the bottom of the home and login pages)</div>
            <div class="card-body">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="policy">
                <div class="row g-3">
                    <div class="col-lg-6">
                        <label class="form-label" for="policy_terms">Terms of booking</label>
                        <textarea class="form-control" id="policy_terms" name="policy_terms" rows="9" maxlength="5000" required><?php echo e(setting($conn, 'policy_terms')); ?></textarea>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-label" for="policy_privacy">Privacy policy</label>
                        <textarea class="form-control" id="policy_privacy" name="policy_privacy" rows="9" maxlength="5000" required><?php echo e(setting($conn, 'policy_privacy')); ?></textarea>
                    </div>
                </div>
                <div class="d-flex gap-2 align-items-center mt-3 flex-wrap">
                    <button class="btn btn-brand">Save</button>
                    <a href="../policy.php" target="_blank" class="small">See the page customers see &rarr;</a>
                    <span class="small text-muted ms-lg-auto">This is starter text &mdash; change it to your shop's real rules.</span>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
// Cut the empty transparent border off a new logo before it is uploaded, and preview it
document.getElementById('logo').addEventListener('change', async (event) => {
    const input = event.target;
    const file = input.files[0];
    if (!file || !/png|webp/.test(file.type)) {
        if (file) document.getElementById('logo-preview').src = URL.createObjectURL(file);
        return;
    }
    const img = await createImageBitmap(file);
    const canvas = document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0);
    const alpha = ctx.getImageData(0, 0, img.width, img.height).data;
    let top = img.height, left = img.width, right = -1, bottom = -1;
    for (let y = 0; y < img.height; y++) {
        for (let x = 0; x < img.width; x++) {
            if (alpha[(y * img.width + x) * 4 + 3] > 8) {
                if (x < left) left = x;
                if (x > right) right = x;
                if (y < top) top = y;
                if (y > bottom) bottom = y;
            }
        }
    }
    if (right < 0) return;   // fully transparent, leave it
    const pad = 6;
    const out = document.createElement('canvas');
    out.width = right - left + 1 + pad * 2;
    out.height = bottom - top + 1 + pad * 2;
    out.getContext('2d').drawImage(canvas, left, top, out.width - pad * 2, out.height - pad * 2, pad, pad, out.width - pad * 2, out.height - pad * 2);
    const blob = await new Promise(resolve => out.toBlob(resolve, 'image/png'));
    const trimmed = new File([blob], file.name.replace(/\.\w+$/, '') + '.png', { type: 'image/png' });
    const list = new DataTransfer();
    list.items.add(trimmed);
    input.files = list.files;
    document.getElementById('logo-preview').src = URL.createObjectURL(trimmed);
});

// Login background: the thumbnails show the darkness while the slider moves
document.getElementById('login_bg_dim').addEventListener('input', (event) => {
    document.getElementById('bg-grid').style.setProperty('--dim', event.target.value / 100);
    document.getElementById('dim-value').textContent = event.target.value + '%';
});

// Phone photos are often 4-8MB: shrink to 1920px wide JPG before uploading (also keeps the login page fast)
document.getElementById('login_bg_file').addEventListener('change', async (event) => {
    const input = event.target;
    const file = input.files[0];
    if (!file || !/jpeg|png|webp/.test(file.type)) return;
    const img = await createImageBitmap(file);
    const scale = Math.min(1, 1920 / Math.max(img.width, img.height));
    if (scale === 1 && file.size < 1.5 * 1024 * 1024) return;   // already small
    const button = input.form.querySelector('button');
    button.disabled = true;   // wait until the smaller copy is ready
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(img.width * scale);
    canvas.height = Math.round(img.height * scale);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#000';   // see-through parts of a PNG become black
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.85));
    const list = new DataTransfer();
    list.items.add(new File([blob], file.name.replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }));
    input.files = list.files;
    button.disabled = false;
});
</script>
<?php admin_footer(); ?>
