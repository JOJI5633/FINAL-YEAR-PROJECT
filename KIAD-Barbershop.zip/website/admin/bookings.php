<?php
include __DIR__ . '/_auth.php';
include __DIR__ . '/_layout.php';

$today = date('Y-m-d');

// ---------- actions ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['receipt_ID'] ?? 0);
    $action = $_POST['action'] ?? '';
    $back = preg_replace('/[^\w=&%.-]/', '', $_POST['back'] ?? '');

    $stmt = mysqli_prepare($conn, "SELECT * FROM receipt WHERE receipt_ID = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $r = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    // Staff may only touch their own bookings
    $allowed = $r && ($is_owner || (int)$r['barber_id'] === (int)$me['staff_id']);
    $sql = null;
    $params = [];

    if (!$allowed) {
        flash('You cannot change that booking.', 'danger');
    } elseif ($action === 'verify' && $is_owner && in_array($r['payment_status'], ['pending', 'rejected'])) {
        $sql = "UPDATE receipt SET payment_status = 'verified' WHERE receipt_ID = ?";
        flash("Booking #$id: online payment verified.");
    } elseif ($action === 'reject' && $is_owner && $r['payment_status'] === 'pending') {
        $sql = "UPDATE receipt SET payment_status = 'rejected' WHERE receipt_ID = ?";
        flash("Booking #$id: payment rejected. The time slot is free again.", 'warning');
    } elseif ($action === 'cash_paid' && $r['payment_status'] === 'cash') {
        $sql = "UPDATE receipt SET payment_status = 'verified' WHERE receipt_ID = ?";
        flash("Booking #$id: cash received.");
    } elseif ($action === 'done' && $r['job_status'] === 'booked') {
        $sql = "UPDATE receipt SET job_status = 'done' WHERE receipt_ID = ?";
        flash("Booking #$id marked as done.");
    } elseif ($action === 'cancel' && $is_owner && $r['job_status'] === 'booked') {
        $sql = "UPDATE receipt SET job_status = 'cancelled' WHERE receipt_ID = ?";
        flash("Booking #$id cancelled. The time slot is free again.", 'warning');
    } elseif ($action === 'reassign' && $is_owner && $r['job_status'] === 'booked') {
        $new = (int)($_POST['barber_id'] ?? 0);
        $time = date('H:i', strtotime($r['time']));
        if (!in_array($new, array_map('intval', array_column(active_barbers($conn), 'staff_id')))) {
            flash('Please choose an active barber.', 'danger');
        } elseif (!barber_is_free($conn, $r['date'], $time, $new)) {
            flash(barber_name($conn, $new) . ' already has a booking at that time.', 'danger');
        } else {
            $sql = "UPDATE receipt SET barber_id = $new WHERE receipt_ID = ?";
            flash("Booking #$id moved to " . barber_name($conn, $new) . '.');
        }
    } else {
        flash('That action is not possible for this booking.', 'danger');
    }

    if ($sql) {
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'i', $id);
        mysqli_stmt_execute($stmt);
    }
    header("Location: bookings.php?$back");
    exit();
}

// ---------- filters ----------
$whens = ['today' => 'Today', 'upcoming' => 'Upcoming', 'past' => 'Past', 'all' => 'All dates'];
$statuses = [
    ''          => 'Any status',
    'pending'   => 'Waiting payment check',
    'cash'      => 'Cash not received yet',
    'verified'  => 'Paid',
    'rejected'  => 'Payment rejected',
    'done'      => 'Done',
    'cancelled' => 'Cancelled',
];
$when = $_GET['when'] ?? 'upcoming';
$when = isset($whens[$when]) ? $when : 'upcoming';
$status = $_GET['status'] ?? '';
$status = isset($statuses[$status]) ? $status : '';
$barber = $is_owner ? (int)($_GET['barber'] ?? 0) : (int)$me['staff_id'];
// "Waiting payment check" is useful across all dates
if (isset($_GET['status']) && !isset($_GET['when'])) {
    $when = 'all';
}

$where = [];
if ($when === 'today')    $where[] = "r.date = '$today'";
if ($when === 'upcoming') $where[] = "r.date >= '$today'";
if ($when === 'past')     $where[] = "r.date < '$today'";
if (in_array($status, ['pending', 'cash', 'verified', 'rejected'])) $where[] = "r.payment_status = '$status'";
if (in_array($status, ['done', 'cancelled'])) $where[] = "r.job_status = '$status'";
if ($barber) $where[] = "r.barber_id = $barber";

$order = $when === 'past' || $when === 'all' ? 'r.date DESC, r.time DESC' : 'r.date, r.time';
$rows = mysqli_fetch_all(mysqli_query($conn, "
    SELECT r.*, s.name AS barber,
           (SELECT GROUP_CONCAT(i.service_name SEPARATOR ', ') FROM receipt_item i WHERE i.receipt_ID = r.receipt_ID) AS services
    FROM receipt r LEFT JOIN staff s ON s.staff_id = r.barber_id
    " . ($where ? 'WHERE ' . implode(' AND ', $where) : '') . "
    ORDER BY $order LIMIT 300"), MYSQLI_ASSOC);

$barbers = active_barbers($conn);
$back = e($_SERVER['QUERY_STRING'] ?? '');

admin_header('Bookings', 'bookings');
?>
<div class="d-flex flex-wrap align-items-center gap-2 mb-3">
    <h1 class="h3 me-auto mb-0"><?php echo $is_owner ? 'Bookings & payments' : 'My bookings'; ?></h1>
</div>

<form class="row g-2 align-items-end mb-3" method="get">
    <div class="col-auto">
        <div class="btn-group" role="group" aria-label="Dates">
            <?php foreach ($whens as $key => $label) { ?>
            <input type="radio" class="btn-check" name="when" id="when-<?php echo $key; ?>" value="<?php echo $key; ?>" <?php echo $when === $key ? 'checked' : ''; ?> onchange="this.form.submit()">
            <label class="btn btn-outline-dark" for="when-<?php echo $key; ?>"><?php echo $label; ?></label>
            <?php } ?>
        </div>
    </div>
    <div class="col-auto">
        <label class="form-label small mb-1" for="status">Status</label>
        <select class="form-select" id="status" name="status" onchange="this.form.submit()">
            <?php foreach ($statuses as $key => $label) { ?>
            <option value="<?php echo $key; ?>" <?php echo $status === $key ? 'selected' : ''; ?>><?php echo $label; ?></option>
            <?php } ?>
        </select>
    </div>
    <?php if ($is_owner) { ?>
    <div class="col-auto">
        <label class="form-label small mb-1" for="barber">Barber</label>
        <select class="form-select" id="barber" name="barber" onchange="this.form.submit()">
            <option value="0">All barbers</option>
            <?php foreach ($barbers as $b) { ?>
            <option value="<?php echo $b['staff_id']; ?>" <?php echo $barber === (int)$b['staff_id'] ? 'selected' : ''; ?>><?php echo e($b['name']); ?></option>
            <?php } ?>
        </select>
    </div>
    <?php } ?>
    <noscript><div class="col-auto"><button class="btn btn-dark">Filter</button></div></noscript>
</form>

<div class="card">
<div class="table-responsive">
<table class="table table-hover mb-0">
  <thead class="table-dark">
    <tr>
      <th>#</th>
      <th>Date / time</th>
      <th>Customer</th>
      <?php if ($is_owner) { ?><th>Barber</th><?php } ?>
      <th>Services &amp; note</th>
      <th class="num">Total</th>
      <th>Payment</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php if (count($rows) === 0) { ?>
    <tr><td colspan="9" class="text-center text-muted py-5">No bookings match these filters.</td></tr>
    <?php } ?>
    <?php foreach ($rows as $r) {
        $booked = $r['job_status'] === 'booked'; ?>
    <tr class="<?php echo $r['payment_status'] === 'pending' && $r['job_status'] !== 'cancelled' ? 'row-pending' : ''; ?>">
      <td><a href="../Receipt.php?receiptID=<?php echo $r['receipt_ID']; ?>" target="_blank" class="link-dark">#<?php echo $r['receipt_ID']; ?></a></td>
      <td class="text-nowrap"><?php echo date('D, j M Y', strtotime($r['date'])); ?><br><strong><?php echo date('g:i A', strtotime($r['time'])); ?></strong></td>
      <td><?php echo e($r['name']); ?></td>
      <?php if ($is_owner) { ?>
      <td>
        <?php if ($booked) { ?>
        <form method="post" class="d-flex gap-1">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="receipt_ID" value="<?php echo $r['receipt_ID']; ?>">
          <input type="hidden" name="back" value="<?php echo $back; ?>">
          <input type="hidden" name="action" value="reassign">
          <select name="barber_id" class="form-select form-select-sm" aria-label="Barber for booking #<?php echo $r['receipt_ID']; ?>" onchange="this.form.submit()">
            <?php if (!$r['barber_id']) { ?><option value="">- none -</option><?php } ?>
            <?php foreach ($barbers as $b) { ?>
            <option value="<?php echo $b['staff_id']; ?>" <?php echo (int)$r['barber_id'] === (int)$b['staff_id'] ? 'selected' : ''; ?>><?php echo e($b['name']); ?></option>
            <?php } ?>
            <?php if ($r['barber_id'] && !in_array($r['barber_id'], array_column($barbers, 'staff_id'))) { ?>
            <option selected disabled><?php echo e($r['barber']); ?> (disabled)</option>
            <?php } ?>
          </select>
        </form>
        <?php } else { echo e($r['barber'] ?? '-'); } ?>
      </td>
      <?php } ?>
      <td>
        <?php echo e($r['services'] ?? '-'); ?>
        <?php if ($r['notes'] !== '') { ?><div class="small text-muted"><i class="fa-regular fa-note-sticky"></i> <?php echo e($r['notes']); ?></div><?php } ?>
      </td>
      <td class="num"><?php echo $r['total'] !== null ? rm($r['total']) : '-'; ?></td>
      <td class="text-nowrap">
        <?php echo ['cash' => 'Cash', 'online' => 'Online (QR)'][$r['payment_method']] ?? '-'; ?><br>
        <?php echo payment_badge($r['payment_method'], $r['payment_status']); ?>
        <?php if ($r['payment_proof']) { ?>
        <a href="../<?php echo e($r['payment_proof']); ?>" target="_blank" class="btn btn-sm btn-outline-primary mt-1"><i class="fa-solid fa-file-invoice"></i> Receipt</a>
        <?php } ?>
      </td>
      <td><?php echo job_badge($r['job_status']); ?></td>
      <td>
        <form method="post" class="d-flex flex-wrap gap-1">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="receipt_ID" value="<?php echo $r['receipt_ID']; ?>">
          <input type="hidden" name="back" value="<?php echo $back; ?>">
          <?php if ($is_owner && $r['payment_status'] === 'pending') { ?>
          <button class="btn btn-sm btn-success" name="action" value="verify">Verify payment</button>
          <button class="btn btn-sm btn-outline-danger" name="action" value="reject" onclick="return confirm('Reject this payment? The time slot will be free again.')">Reject</button>
          <?php } ?>
          <?php if ($is_owner && $r['payment_status'] === 'rejected' && $r['job_status'] !== 'cancelled') { ?>
          <button class="btn btn-sm btn-outline-success" name="action" value="verify">Verify after all</button>
          <?php } ?>
          <?php if ($r['payment_status'] === 'cash' && $r['job_status'] !== 'cancelled') { ?>
          <button class="btn btn-sm btn-success" name="action" value="cash_paid">Cash received</button>
          <?php } ?>
          <?php if ($booked && $r['payment_status'] !== 'rejected') { ?>
          <button class="btn btn-sm btn-dark" name="action" value="done">Done</button>
          <?php } ?>
          <?php if ($is_owner && $booked) { ?>
          <button class="btn btn-sm btn-outline-secondary" name="action" value="cancel" onclick="return confirm('Cancel booking #<?php echo $r['receipt_ID']; ?>? The time slot will be free again.')">Cancel</button>
          <?php } ?>
        </form>
      </td>
    </tr>
    <?php } ?>
  </tbody>
</table>
</div>
</div>
<?php if (count($rows) === 300) { ?>
<p class="text-muted small mt-2">Showing the first 300 bookings. Use the filters to narrow down.</p>
<?php } ?>
<?php admin_footer(); ?>
