<?php
// Counter screen: shows the attendance QR that staff scan when they arrive and leave.
// Opened with a secret link (Admin -> Attendance), so the counter tablet needs no admin login.
include __DIR__ . '/_base.php';

if (!hash_equals(secret_setting($conn, 'kiosk_key'), $_GET['key'] ?? '')) {
    http_response_code(403);
    exit('This counter link is not valid any more. Ask the owner for the new link (Admin -> Attendance).');
}

// The page asks for a fresh QR every few seconds
if (isset($_GET['json'])) {
    header('Content-Type: application/json');
    $today = date('Y-m-d');
    $rows = mysqli_fetch_all(mysqli_query($conn, "
        SELECT s.name, a.clock_in, a.clock_out FROM attendance a JOIN staff s ON s.staff_id = a.staff_id
        WHERE a.work_date = '$today' ORDER BY a.clock_in"), MYSQLI_ASSOC);
    echo json_encode([
        'url'   => admin_url('scan.php?t=' . attendance_token($conn)),
        'today' => array_map(fn($r) => [
            'name' => $r['name'],
            'in'   => date('g:i A', strtotime($r['clock_in'])),
            'out'  => $r['clock_out'] ? date('g:i A', strtotime($r['clock_out'])) : '',
        ], $rows),
    ]);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex">
    <title>Staff attendance | KI'AD</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            min-height: 100vh;
            background: #1C1F25;
            color: #fff;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 18px;
            padding: 24px 16px;
            text-align: center;
        }
        .logo { height: 70px; }
        h1 { font-size: 1.6rem; font-weight: 600; letter-spacing: 1px; }
        .clock { font-size: 3rem; font-weight: 600; color: #D2B48C; font-variant-numeric: tabular-nums; }
        .date { color: #b9bcc2; margin-top: -12px; }
        #qr {
            background: #fff;
            padding: 16px;
            border-radius: 16px;
            width: 312px;
            height: 312px;
        }
        #qr img, #qr canvas { width: 280px !important; height: 280px !important; }
        .help { max-width: 420px; color: #d7d9dd; line-height: 1.5; }
        .help strong { color: #D2B48C; }
        .today { width: 100%; max-width: 420px; border-top: 1px solid #3a3e46; padding-top: 12px; }
        .today h2 { font-size: 1rem; color: #b9bcc2; font-weight: 500; margin-bottom: 8px; }
        .today li { list-style: none; display: flex; justify-content: space-between; padding: 4px 0; }
        .today li span:last-child { color: #b9bcc2; font-variant-numeric: tabular-nums; }
        .offline { color: #f0a39e; display: none; }
    </style>
</head>
<body>
    <img class="logo" src="../<?php echo e(logo($conn)); ?>" alt="KI'AD Barbershop">
    <h1>STAFF ATTENDANCE</h1>
    <div class="clock" id="clock"></div>
    <div class="date"><?php echo date('l, j F Y'); ?></div>
    <div id="qr" role="img" aria-label="Attendance QR code"></div>
    <p class="help">Open your phone camera and scan this code.<br>
        <strong>First scan</strong> = arrive &middot; <strong>second scan</strong> = go home.<br>
        The code changes every minute.</p>
    <p class="offline" id="offline">Cannot reach the system. Check the internet connection.</p>
    <div class="today">
        <h2>Today</h2>
        <ul id="today"><li><span>No one yet</span><span></span></li></ul>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script>
    const qr = new QRCode(document.getElementById('qr'), { width: 280, height: 280, correctLevel: QRCode.CorrectLevel.M });
    let lastUrl = '';

    async function refresh() {
        try {
            const res = await fetch(location.pathname + location.search + '&json=1', { cache: 'no-store' });
            const data = await res.json();
            if (data.url !== lastUrl) {
                qr.makeCode(data.url);
                lastUrl = data.url;
            }
            const list = document.getElementById('today');
            list.innerHTML = '';
            if (data.today.length === 0) {
                list.innerHTML = '<li><span>No one yet</span><span></span></li>';
            }
            for (const r of data.today) {
                const li = document.createElement('li');
                const name = document.createElement('span');
                const time = document.createElement('span');
                name.textContent = r.name;
                time.textContent = r.in + (r.out ? ' → ' + r.out : '');
                li.append(name, time);
                list.append(li);
            }
            document.getElementById('offline').style.display = 'none';
        } catch (e) {
            document.getElementById('offline').style.display = 'block';
        }
    }

    function tick() {
        document.getElementById('clock').textContent =
            new Date().toLocaleTimeString('en-MY', { hour: 'numeric', minute: '2-digit', second: '2-digit' });
    }

    refresh();
    tick();
    setInterval(refresh, 10000);
    setInterval(tick, 1000);
    // Reload now and then so the date stays right on a screen left on for days
    setTimeout(() => location.reload(), 3 * 60 * 60 * 1000);
    </script>
</body>
</html>
