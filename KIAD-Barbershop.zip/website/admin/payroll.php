<?php
include __DIR__ . '/_auth.php';
include __DIR__ . '/_layout.php';
include __DIR__ . '/_stats.php';

$month = month_param();

// ---------- owner actions ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_owner) {
    $staff_id = (int)($_POST['staff_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    $amount = trim($_POST['amount'] ?? '');
    $note = trim($_POST['note'] ?? '');

    $stmt = mysqli_prepare($conn, "SELECT name FROM staff WHERE staff_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $staff_id);
    mysqli_stmt_execute($stmt);
    $person = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$person) {
        flash('Staff not found.', 'danger');
    } elseif ($action === 'unpaid') {
        $stmt = mysqli_prepare($conn, "UPDATE payroll SET paid_at = NULL WHERE staff_id = ? AND month = ?");
        mysqli_stmt_bind_param($stmt, 'is', $staff_id, $month);
        mysqli_stmt_execute($stmt);
        flash($person['name'] . "'s salary is not paid any more. You can change the amount now.", 'warning');
    } elseif (!is_numeric($amount) || $amount < 0 || $amount > 99999) {
        flash('Please enter a salary amount for ' . $person['name'] . ', for example 1200.', 'danger');
    } else {
        // Save the amount; "paid" also records today's date. A paid salary is locked.
        $paid = $action === 'paid' ? date('Y-m-d H:i:s') : null;
        $amount = round((float)$amount, 2);
        $stmt = mysqli_prepare($conn, "INSERT INTO payroll (staff_id, month, amount, note, paid_at) VALUES (?, ?, ?, ?, ?)
                                       ON DUPLICATE KEY UPDATE amount = IF(paid_at IS NULL, VALUES(amount), amount),
                                                               note = VALUES(note),
                                                               paid_at = COALESCE(paid_at, VALUES(paid_at))");
        mysqli_stmt_bind_param($stmt, 'isdss', $staff_id, $month, $amount, $note, $paid);
        mysqli_stmt_execute($stmt);
        flash($person['name'] . ': ' . rm($amount) . ($paid ? ' paid.' : ' saved (not paid yet).'));
    }
    header("Location: payroll.php?m=$month");
    exit();
}

if ($is_owner) {
    $perf = performance_summary($conn, $month);
    $attend = attendance_summary($conn, $month);
    $prev = date('Y-m', strtotime("$month-01 -1 month"));

    // Staff to pay: everyone except owners, plus anyone already given a salary this month
    $rows = mysqli_fetch_all(mysqli_query($conn, "
        SELECT s.staff_id, s.name, s.active, s.is_barber, p.amount, p.note, p.paid_at, last.amount AS last_amount
        FROM staff s
        LEFT JOIN payroll p ON p.staff_id = s.staff_id AND p.month = '$month'
        LEFT JOIN payroll last ON last.staff_id = s.staff_id AND last.month = '$prev'
        WHERE (s.role = 'staff' AND s.active = 1) OR p.payroll_id IS NOT NULL
        ORDER BY s.staff_id"), MYSQLI_ASSOC);
    $total_saved = array_sum(array_map(fn($r) => (float)$r['amount'], $rows));
    $total_paid = array_sum(array_map(fn($r) => $r['paid_at'] ? (float)$r['amount'] : 0, $rows));
} else {
    $mine = mysqli_fetch_all(mysqli_query($conn, "
        SELECT month, amount, paid_at FROM payroll
        WHERE staff_id = " . (int)$me['staff_id'] . " AND paid_at IS NOT NULL ORDER BY month DESC"), MYSQLI_ASSOC);
}

admin_header($is_owner ? 'Payroll' : 'My salary', 'payroll');
?>
<?php if ($is_owner) { ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h3 mb-0">Salary &middot; <?php echo date('F Y', strtotime("$month-01")); ?></h1>
    <?php month_picker($month); ?>
</div>

<div class="row g-3 mb-3">
    <div class="col-6 col-lg-3"><div class="stat"><div class="label">Salary this month</div><div class="value"><?php echo rm($total_saved); ?></div></div></div>
    <div class="col-6 col-lg-3"><div class="stat"><div class="label">Already paid</div><div class="value"><?php echo rm($total_paid); ?></div></div></div>
</div>

<div class="card">
<div class="table-responsive">
<table class="table mb-0 align-middle">
    <thead>
        <tr>
            <th>Staff</th>
            <th class="num">Days worked</th>
            <th class="num">Late</th>
            <th class="num">Customers</th>
            <th class="num">Sales</th>
            <th class="num">Picked by name</th>
            <th>Rating</th>
            <th style="min-width: 150px">Salary</th>
            <th style="min-width: 160px">Note (only you see it)</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
    <?php if (count($rows) === 0) { ?>
        <tr><td colspan="10" class="text-center text-muted py-4">No staff yet. Add them in Staff.</td></tr>
    <?php } ?>
    <?php foreach ($rows as $r) {
        $id = $r['staff_id'];
        $p = $perf[$id] ?? ['customers' => 0, 'sales' => 0, 'chosen' => 0, 'rating' => null, 'reviews' => 0];
        $a = $attend[$id] ?? ['days' => 0, 'late_count' => 0];
        $paid = (bool)$r['paid_at'];
        $value = $r['amount'] ?? $r['last_amount'] ?? ''; ?>
        <tr class="<?php echo $paid ? 'table-success' : ''; ?>">
            <td><strong><?php echo e($r['name']); ?></strong><?php echo $r['active'] ? '' : ' <span class="badge bg-secondary">Disabled</span>'; ?></td>
            <td class="num"><?php echo (int)$a['days']; ?></td>
            <td class="num <?php echo $a['late_count'] > 0 ? 'text-danger' : ''; ?>"><?php echo (int)$a['late_count']; ?>x</td>
            <td class="num"><?php echo $r['is_barber'] ? (int)$p['customers'] : '-'; ?></td>
            <td class="num"><?php echo $r['is_barber'] ? rm($p['sales']) : '-'; ?></td>
            <td class="num"><?php echo $r['is_barber'] ? (int)$p['chosen'] : '-'; ?></td>
            <td><?php echo $r['is_barber'] ? stars_text($p['rating'], $p['reviews']) : '-'; ?></td>
            <td>
                <div class="input-group input-group-sm">
                    <span class="input-group-text">RM</span>
                    <input class="form-control" type="number" name="amount" form="pay-<?php echo $id; ?>" min="0" step="0.01" required
                           value="<?php echo e($value); ?>" <?php echo $paid ? 'readonly' : ''; ?> aria-label="Salary for <?php echo e($r['name']); ?>">
                </div>
                <?php if ($r['amount'] === null && $r['last_amount'] !== null) { ?><div class="form-text">Same as last month</div><?php } ?>
            </td>
            <td><input class="form-control form-control-sm" name="note" form="pay-<?php echo $id; ?>" maxlength="255" value="<?php echo e($r['note'] ?? ''); ?>" placeholder="e.g. good month" aria-label="Note for <?php echo e($r['name']); ?>"></td>
            <td class="text-nowrap">
                <form method="post" id="pay-<?php echo $id; ?>" class="d-flex gap-1 align-items-center">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="staff_id" value="<?php echo $id; ?>">
                    <?php if ($paid) { ?>
                        <span class="small text-success fw-semibold"><i class="fa-solid fa-check"></i> Paid <?php echo date('j M', strtotime($r['paid_at'])); ?></span>
                        <button class="btn btn-sm btn-outline-secondary" name="action" value="save">Save note</button>
                        <button class="btn btn-sm btn-link text-danger" name="action" value="unpaid" formnovalidate onclick="return confirm('Mark as NOT paid?')">Undo</button>
                    <?php } else { ?>
                        <button class="btn btn-sm btn-outline-dark" name="action" value="save">Save</button>
                        <button class="btn btn-sm btn-success" name="action" value="paid" onclick="return confirm('Mark <?php echo e(addslashes($r['name'])); ?>\'s salary as paid?')">Paid</button>
                    <?php } ?>
                </form>
            </td>
        </tr>
    <?php } ?>
    </tbody>
</table>
</div>
<div class="card-footer small text-muted">Days worked and late come from the attendance QR. Customers, sales and picked by name count finished haircuts this month. The staff only see the amount after you press <strong>Paid</strong>.</div>
</div>

<?php } else { ?>
<h1 class="h3 mb-3">My salary</h1>
<div class="card">
    <table class="table mb-0">
        <thead><tr><th>Month</th><th class="num">Salary</th><th>Paid on</th></tr></thead>
        <tbody>
        <?php if (count($mine) === 0) { ?>
            <tr><td colspan="3" class="text-center text-muted py-4">No salary paid yet.</td></tr>
        <?php } ?>
        <?php foreach ($mine as $r) { ?>
            <tr>
                <td><?php echo date('F Y', strtotime($r['month'] . '-01')); ?></td>
                <td class="num fw-semibold"><?php echo rm($r['amount']); ?></td>
                <td><?php echo date('j M Y', strtotime($r['paid_at'])); ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php } ?>
<?php admin_footer(); ?>
