<?php
include __DIR__ . '/_auth.php';
include __DIR__ . '/_layout.php';
include __DIR__ . '/_stats.php';

$today = date('Y-m-d');
$month_start = date('Y-m-01');
$month_end = date('Y-m-t');

// A booking still counts unless it was cancelled or its payment rejected
$live = "r.job_status <> 'cancelled' AND (r.payment_status IS NULL OR r.payment_status <> 'rejected')";
// Staff only see their own bookings
$mine = $is_owner ? '' : ' AND r.barber_id = ' . (int)$me['staff_id'];

function one_value($conn, $sql) {
    return mysqli_fetch_row(mysqli_query($conn, $sql))[0] ?? 0;
}

$bookings_today = one_value($conn, "SELECT COUNT(*) FROM receipt r WHERE r.date = '$today' AND $live $mine");

// Today's schedule
$schedule = mysqli_fetch_all(mysqli_query($conn, "
    SELECT r.*, s.name AS barber,
           (SELECT GROUP_CONCAT(i.service_name SEPARATOR ', ') FROM receipt_item i WHERE i.receipt_ID = r.receipt_ID) AS services
    FROM receipt r LEFT JOIN staff s ON s.staff_id = r.barber_id
    WHERE r.date = '$today' AND $live $mine
    ORDER BY r.time"), MYSQLI_ASSOC);

if ($is_owner) {
    $value_today = one_value($conn, "SELECT COALESCE(SUM(r.total), 0) FROM receipt r WHERE r.date = '$today' AND $live");
    $collected_month = one_value($conn, "SELECT COALESCE(SUM(r.total), 0) FROM receipt r
                                         WHERE r.payment_status = 'verified' AND r.date BETWEEN '$month_start' AND '$month_end'");
    $pending = one_value($conn, "SELECT COUNT(*) FROM receipt r WHERE r.payment_status = 'pending' AND r.job_status <> 'cancelled'");

    // Paid sales for the last 7 days (by appointment date)
    $week = [];
    for ($i = 6; $i >= 0; $i--) {
        $week[date('Y-m-d', strtotime("-$i day"))] = 0;
    }
    $week_start = array_key_first($week);
    $result = mysqli_query($conn, "SELECT r.date, SUM(r.total) AS total FROM receipt r
                                   WHERE r.payment_status = 'verified' AND r.date BETWEEN '$week_start' AND '$today'
                                   GROUP BY r.date");
    while ($row = mysqli_fetch_assoc($result)) {
        $week[$row['date']] = (float)$row['total'];
    }
    // Clean y-axis: 4 gridlines at a round step
    $step = 10;
    foreach ([10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 2500, 5000, 10000] as $s) {
        $step = $s;
        if ($s * 4 >= max($week)) {
            break;
        }
    }
    $top = $step * 4;
    $best_day = max($week) > 0 ? array_search(max($week), $week) : null;

    $top_services = mysqli_fetch_all(mysqli_query($conn, "
        SELECT i.service_name, COUNT(*) AS n, SUM(i.price) AS sales
        FROM receipt_item i JOIN receipt r ON r.receipt_ID = i.receipt_ID
        WHERE r.date BETWEEN '$month_start' AND '$month_end' AND $live
        GROUP BY i.service_name ORDER BY n DESC, sales DESC LIMIT 5"), MYSQLI_ASSOC);

    // Who has scanned in today
    $staff_today = mysqli_fetch_all(mysqli_query($conn, "
        SELECT s.staff_id, s.name, s.start_time, a.clock_in, a.clock_out, a.late_minutes
        FROM staff s LEFT JOIN attendance a ON a.staff_id = s.staff_id AND a.work_date = '$today'
        WHERE s.active = 1 AND s.role = 'staff' ORDER BY a.clock_in IS NULL, a.clock_in, s.staff_id"), MYSQLI_ASSOC);

    $barber_stats = mysqli_fetch_all(mysqli_query($conn, "
        SELECT s.name, s.active, COUNT(r.receipt_ID) AS n,
               COALESCE(SUM(r.job_status = 'done'), 0) AS done,
               COALESCE(SUM(CASE WHEN r.payment_status = 'verified' THEN r.total END), 0) AS paid
        FROM staff s
        LEFT JOIN receipt r ON r.barber_id = s.staff_id AND r.date BETWEEN '$month_start' AND '$month_end' AND $live
        WHERE s.is_barber = 1
        GROUP BY s.staff_id, s.name, s.active ORDER BY s.staff_id"), MYSQLI_ASSOC);
} else {
    $upcoming = mysqli_fetch_all(mysqli_query($conn, "
        SELECT r.*,
               (SELECT GROUP_CONCAT(i.service_name SEPARATOR ', ') FROM receipt_item i WHERE i.receipt_ID = r.receipt_ID) AS services
        FROM receipt r
        WHERE r.date > '$today' AND r.date <= DATE_ADD('$today', INTERVAL 7 DAY) AND $live $mine
        ORDER BY r.date, r.time"), MYSQLI_ASSOC);
    $done_month = one_value($conn, "SELECT COUNT(*) FROM receipt r WHERE r.job_status = 'done'
                                    AND r.date BETWEEN '$month_start' AND '$month_end' $mine");
    // Sales brought in = finished haircuts
    $sales_today = one_value($conn, "SELECT COALESCE(SUM(r.total), 0) FROM receipt r WHERE r.job_status = 'done' AND r.date = '$today' AND $live $mine");
    $sales_month = one_value($conn, "SELECT COALESCE(SUM(r.total), 0) FROM receipt r WHERE r.job_status = 'done'
                                     AND r.date BETWEEN '$month_start' AND '$month_end' AND $live $mine");
    $my_rating = mysqli_fetch_assoc(mysqli_query($conn, "SELECT AVG(stars) AS avg, COUNT(*) AS n FROM review WHERE barber_id = " . (int)$me['staff_id']));
    $attendance_today = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM attendance WHERE staff_id = " . (int)$me['staff_id'] . " AND work_date = '$today'"));
}

// Accounts still using a starter password (checked once per login: password checks are slow on purpose)
if (!isset($_SESSION['weak_passwords'])) {
    $starter = ['admin123', 'barber123', 'kiad2026', 'password', '123456'];
    $weak = [];
    $who = $is_owner ? "active = 1" : "staff_id = " . (int)$me['staff_id'];
    foreach (mysqli_fetch_all(mysqli_query($conn, "SELECT username, password_hash FROM staff WHERE $who"), MYSQLI_ASSOC) as $s) {
        foreach ($starter as $pw) {
            if (password_verify($pw, $s['password_hash'])) {
                $weak[] = $s['username'];
                break;
            }
        }
    }
    $_SESSION['weak_passwords'] = $weak;
}
$weak_passwords = $_SESSION['weak_passwords'];

admin_header('Dashboard', 'index');
?>
<div class="d-flex flex-wrap align-items-baseline gap-2 mb-3">
    <h1 class="h3 me-auto mb-0">Hi, <?php echo e($me['name']); ?></h1>
    <span class="text-muted"><?php echo date('l, j F Y'); ?></span>
</div>

<?php if (!$is_owner) { ?>
<!-- attendance today -->
<a href="attendance.php" class="text-reset text-decoration-none">
<div class="alert <?php echo $attendance_today ? 'alert-light border' : 'alert-warning'; ?> d-flex align-items-center gap-3 mb-3">
    <i class="fa-solid <?php echo $attendance_today ? 'fa-circle-check text-success' : 'fa-qrcode'; ?> fs-3"></i>
    <div>
    <?php if (!$attendance_today) { ?>
        <strong>You haven't clocked in today.</strong> Scan the QR at the counter with your phone camera.
    <?php } else {
        [$colour, $label] = arrival_label($conn, (int)$attendance_today['late_minutes']); ?>
        <strong>Arrived <?php echo date('g:i A', strtotime($attendance_today['clock_in'])); ?></strong>
        <span class="badge bg-<?php echo $colour; ?>"><?php echo $label; ?></span>
        <?php echo $attendance_today['clock_out'] ? '&middot; went home ' . date('g:i A', strtotime($attendance_today['clock_out'])) : '&middot; scan again when you go home'; ?>
    <?php } ?>
    </div>
</div>
</a>
<?php } ?>

<?php if (count($weak_passwords) > 0) { ?>
<div class="alert alert-warning d-flex gap-3 align-items-start">
    <i class="fa-solid fa-shield-halved fs-4"></i>
    <div>
        <?php if ($is_owner) { ?>
        <strong>These accounts still use an easy starter password:</strong> <?php echo e(implode(', ', $weak_passwords)); ?>.<br>
        Change them before customers start using the website: your own in <a href="account.php">My account</a>, the others in <a href="staff.php">Manage &rarr; Staff</a>.
        <?php } else { ?>
        <strong>Your password is still the starter password.</strong> Please change it in <a href="account.php">My account</a>.
        <?php } ?>
    </div>
</div>
<?php } ?>

<!-- headline numbers -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="stat">
            <div class="label"><?php echo $is_owner ? 'Bookings today' : 'My bookings today'; ?></div>
            <div class="value"><?php echo $bookings_today; ?></div>
        </div>
    </div>
    <?php if ($is_owner) { ?>
    <div class="col-6 col-lg-3">
        <div class="stat">
            <div class="label">Booked value today</div>
            <div class="value"><?php echo rm($value_today); ?></div>
            <div class="note">Paid and unpaid</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat">
            <div class="label">Collected this month</div>
            <div class="value"><?php echo rm($collected_month); ?></div>
            <div class="note">Payments marked paid</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <a href="bookings.php?status=pending" class="text-reset text-decoration-none">
        <div class="stat <?php echo $pending > 0 ? 'attention' : ''; ?>">
            <div class="label">Waiting for payment check</div>
            <div class="value"><?php echo $pending; ?></div>
            <div class="note"><?php echo $pending > 0 ? '<i class="fa-solid fa-triangle-exclamation text-warning"></i> Check the receipts &rarr;' : 'All checked'; ?></div>
        </div>
        </a>
    </div>
    <?php } else { ?>
    <div class="col-6 col-lg-3">
        <div class="stat">
            <div class="label">My sales today</div>
            <div class="value"><?php echo rm($sales_today); ?></div>
            <div class="note">Finished haircuts</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat">
            <div class="label">My sales this month</div>
            <div class="value"><?php echo rm($sales_month); ?></div>
            <div class="note"><?php echo $done_month; ?> customers done</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="stat">
            <div class="label">My rating</div>
            <div class="value"><?php echo $my_rating['n'] ? number_format($my_rating['avg'], 1) : '-'; ?></div>
            <div class="note"><?php echo $my_rating['n'] ? stars_text($my_rating['avg'], $my_rating['n'], false) . ' ' . $my_rating['n'] . ' reviews' : 'No reviews yet'; ?></div>
        </div>
    </div>
    <?php } ?>
</div>

<div class="row g-4">
    <!-- today's schedule -->
    <div class="<?php echo $is_owner ? 'col-xl-7' : 'col-12'; ?>">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><?php echo $is_owner ? "Today's schedule" : 'My schedule today'; ?></span>
                <a href="bookings.php?when=today" class="small">Open in Bookings &rarr;</a>
            </div>
            <div class="table-responsive">
            <table class="table mb-0">
                <thead><tr><th>Time</th><?php if ($is_owner) { ?><th>Barber</th><?php } ?><th>Customer</th><th>Services</th><th>Payment</th><th>Status</th></tr></thead>
                <tbody>
                <?php if (count($schedule) === 0) { ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">No bookings today.</td></tr>
                <?php } ?>
                <?php foreach ($schedule as $r) { ?>
                    <tr>
                        <td class="text-nowrap fw-semibold"><?php echo date('g:i A', strtotime($r['time'])); ?></td>
                        <?php if ($is_owner) { ?><td><?php echo e($r['barber'] ?? '-'); ?></td><?php } ?>
                        <td><?php echo e(explode('/', $r['name'])[0]); ?></td>
                        <td><?php echo e($r['services'] ?? $r['notes']); ?></td>
                        <td><?php echo payment_badge($r['payment_method'], $r['payment_status']); ?></td>
                        <td><?php echo job_badge($r['job_status']); ?></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>

    <?php if ($is_owner) { ?>
    <!-- paid sales, last 7 days -->
    <div class="col-xl-5">
        <div class="card h-100">
            <div class="card-header">Paid sales, last 7 days</div>
            <div class="card-body">
                <div class="chart" role="img" aria-label="Column chart of paid sales for the last 7 days">
                    <?php for ($g = 4; $g >= 0; $g--) { ?>
                    <div class="grid" style="top: <?php echo (4 - $g) * 25; ?>%"><span>RM<?php echo number_format($step * $g); ?></span></div>
                    <?php } ?>
                    <div class="cols">
                        <?php foreach ($week as $day => $total) {
                            $h = $top > 0 ? round($total / $top * 100, 1) : 0; ?>
                        <div class="column" tabindex="0" style="--h: <?php echo $h; ?>%">
                            <div class="tip"><?php echo date('D j M', strtotime($day)); ?>: <?php echo rm($total); ?></div>
                            <?php if ($day === $best_day) { ?><div class="cap"><?php echo rm($total); ?></div><?php } ?>
                            <div class="bar" style="height: <?php echo $h; ?>%"></div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="chart-days">
                    <?php foreach ($week as $day => $total) { ?>
                    <div class="<?php echo $day === $today ? 'today' : ''; ?>"><?php echo $day === $today ? 'Today' : date('D', strtotime($day)); ?></div>
                    <?php } ?>
                </div>
                <details class="mt-3 small">
                    <summary>Show as table</summary>
                    <table class="table table-sm mt-2 mb-0">
                        <thead><tr><th>Date</th><th class="num">Paid sales</th></tr></thead>
                        <tbody>
                        <?php foreach ($week as $day => $total) { ?>
                            <tr><td><?php echo date('D, j M', strtotime($day)); ?></td><td class="num"><?php echo rm($total); ?></td></tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </details>
            </div>
        </div>
    </div>

    <!-- staff at work today -->
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Staff today</span>
                <a href="attendance.php" class="small">Attendance &rarr;</a>
            </div>
            <ul class="list-group list-group-flush">
                <?php if (count($staff_today) === 0) { ?>
                <li class="list-group-item text-muted">No staff yet.</li>
                <?php } ?>
                <?php foreach ($staff_today as $s) { ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <span><?php echo e($s['name']); ?></span>
                    <?php if ($s['clock_in']) {
                        [$colour, $label] = arrival_label($conn, (int)$s['late_minutes']); ?>
                    <span class="small text-nowrap"><?php echo date('g:i A', strtotime($s['clock_in'])); ?> <span class="badge bg-<?php echo $colour; ?>"><?php echo $label; ?></span><?php echo $s['clock_out'] ? ' <span class="text-muted">home</span>' : ''; ?></span>
                    <?php } else { ?>
                    <span class="small text-muted">Not in yet</span>
                    <?php } ?>
                </li>
                <?php } ?>
            </ul>
        </div>
    </div>

    <!-- this month -->
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-header">Top services this month</div>
            <table class="table mb-0">
                <thead><tr><th>Service</th><th class="num">Bookings</th><th class="num">Value</th></tr></thead>
                <tbody>
                <?php if (count($top_services) === 0) { ?>
                    <tr><td colspan="3" class="text-center text-muted py-4">No bookings yet this month.</td></tr>
                <?php } ?>
                <?php foreach ($top_services as $s) { ?>
                    <tr><td><?php echo e($s['service_name']); ?></td><td class="num"><?php echo $s['n']; ?></td><td class="num"><?php echo rm($s['sales']); ?></td></tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span>Barbers this month</span>
                <a href="performance.php" class="small">Performance &rarr;</a>
            </div>
            <table class="table mb-0">
                <thead><tr><th>Barber</th><th class="num">Bookings</th><th class="num">Done</th><th class="num">Paid</th></tr></thead>
                <tbody>
                <?php foreach ($barber_stats as $b) { ?>
                    <tr>
                        <td><?php echo e($b['name']); ?><?php echo $b['active'] ? '' : ' <span class="badge bg-secondary">Disabled</span>'; ?></td>
                        <td class="num"><?php echo $b['n']; ?></td>
                        <td class="num"><?php echo $b['done']; ?></td>
                        <td class="num"><?php echo rm($b['paid']); ?></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php } else { ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">My next 7 days</div>
            <div class="table-responsive">
            <table class="table mb-0">
                <thead><tr><th>Date</th><th>Time</th><th>Customer</th><th>Services</th><th>Note</th></tr></thead>
                <tbody>
                <?php if (count($upcoming) === 0) { ?>
                    <tr><td colspan="5" class="text-center text-muted py-4">No upcoming bookings.</td></tr>
                <?php } ?>
                <?php foreach ($upcoming as $r) { ?>
                    <tr>
                        <td class="text-nowrap"><?php echo date('D, j M', strtotime($r['date'])); ?></td>
                        <td class="text-nowrap"><?php echo date('g:i A', strtotime($r['time'])); ?></td>
                        <td><?php echo e(explode('/', $r['name'])[0]); ?></td>
                        <td><?php echo e($r['services'] ?? '-'); ?></td>
                        <td><?php echo e($r['notes']); ?></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
    <?php } ?>
</div>
<?php admin_footer(); ?>
