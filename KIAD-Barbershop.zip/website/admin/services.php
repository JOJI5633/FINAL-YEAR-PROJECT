<?php
include __DIR__ . '/_auth.php';
include __DIR__ . '/_layout.php';
require_owner();

function find_service($conn, $id) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM service WHERE service_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

// Remove an image file once no service uses it any more
function remove_unused_image($conn, $path) {
    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) FROM service WHERE image = ?");
    mysqli_stmt_bind_param($stmt, 's', $path);
    mysqli_stmt_execute($stmt);
    $used = mysqli_fetch_row(mysqli_stmt_get_result($stmt))[0];
    if (!$used && strpos($path, 'images/services/') === 0 && is_file(__DIR__ . '/../' . $path)) {
        unlink(__DIR__ . '/../' . $path);
    }
}

$editing = isset($_GET['edit']) ? find_service($conn, (int)$_GET['edit']) : null;
$form = $editing ?? ['service_id' => 0, 'name' => '', 'price' => ''];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'delete') {
        $service = find_service($conn, (int)$_POST['service_id']);
        if ($service) {
            $stmt = mysqli_prepare($conn, "DELETE FROM service WHERE service_id = ?");
            mysqli_stmt_bind_param($stmt, 'i', $service['service_id']);
            mysqli_stmt_execute($stmt);
            remove_unused_image($conn, $service['image']);
            flash('"' . $service['name'] . '" deleted. Old receipts still show it.');
        }
        header("Location: services.php");
        exit();
    }

    // Add or edit
    $form = [
        'service_id' => (int)($_POST['service_id'] ?? 0),
        'name'       => trim($_POST['name'] ?? ''),
        'price'      => trim($_POST['price'] ?? ''),
    ];
    $old = $form['service_id'] ? find_service($conn, $form['service_id']) : null;
    $has_file = isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE;

    if ($form['name'] === '' || strlen($form['name']) > 100) {
        $error = 'Please enter a service name (max 100 characters).';
    } elseif (!is_numeric($form['price']) || $form['price'] < 0 || $form['price'] > 9999) {
        $error = 'Please enter a price, for example 15 or 18.50.';
    } elseif (!$old && !$has_file) {
        $error = 'Please choose a picture for the new service.';
    } else {
        $image = $old['image'] ?? '';
        if ($has_file) {
            $upload = save_image_upload($_FILES['image'], 'images/services', 'svc-');
            if (isset($upload['error'])) {
                $error = $upload['error'];
            } else {
                $image = $upload['path'];
            }
        }
    }

    if ($error === '') {
        $price = round((float)$form['price'], 2);
        if ($old) {
            $stmt = mysqli_prepare($conn, "UPDATE service SET name = ?, price = ?, image = ? WHERE service_id = ?");
            mysqli_stmt_bind_param($stmt, 'sdsi', $form['name'], $price, $image, $old['service_id']);
            mysqli_stmt_execute($stmt);
            if ($image !== $old['image']) {
                remove_unused_image($conn, $old['image']);
            }
            flash('"' . $form['name'] . '" updated.');
        } else {
            $stmt = mysqli_prepare($conn, "INSERT INTO service (name, price, image) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($stmt, 'sds', $form['name'], $price, $image);
            mysqli_stmt_execute($stmt);
            flash('"' . $form['name'] . '" added. Customers can book it now.');
        }
        header("Location: services.php");
        exit();
    }
    $editing = $old;
}

$services = mysqli_fetch_all(mysqli_query($conn, "SELECT * FROM service ORDER BY service_id"), MYSQLI_ASSOC);

admin_header('Services', 'services');
?>
<h1 class="h3 mb-3">Services &amp; prices</h1>

<div class="row g-4">
    <div class="col-lg-4">
        <form method="post" enctype="multipart/form-data" class="card" id="service-form">
            <div class="card-header"><?php echo $editing ? 'Edit service' : 'Add a service'; ?></div>
            <div class="card-body">
                <?php if ($error) { ?><div class="alert alert-danger py-2"><?php echo e($error); ?></div><?php } ?>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="service_id" value="<?php echo (int)$form['service_id']; ?>">
                <div class="mb-3">
                    <label class="form-label" for="name">Name</label>
                    <input class="form-control" id="name" name="name" maxlength="100" required value="<?php echo e($form['name']); ?>" placeholder="e.g. Skin Fade">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="price">Price</label>
                    <div class="input-group">
                        <span class="input-group-text">RM</span>
                        <input class="form-control" id="price" name="price" type="number" min="0" max="9999" step="0.50" required value="<?php echo e($form['price']); ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="image">Picture</label>
                    <?php if ($editing) { ?>
                    <div class="mb-2"><img src="../<?php echo e($editing['image']); ?>" class="thumb" alt=""> <span class="small text-muted">Leave empty to keep this picture</span></div>
                    <?php } ?>
                    <input class="form-control" id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp" <?php echo $editing ? '' : 'required'; ?>>
                    <div class="form-text">JPG, PNG or WEBP, max 3MB. A landscape (4:3) photo looks best.</div>
                </div>
                <button class="btn btn-brand"><?php echo $editing ? 'Save changes' : 'Add service'; ?></button>
                <?php if ($editing) { ?><a href="services.php" class="btn btn-link">Cancel</a><?php } ?>
            </div>
        </form>
    </div>

    <div class="col-lg-8">
        <div class="card">
            <?php if (count($services) > 0) { ?>
            <div class="card-header d-flex align-items-center gap-2 flex-wrap">
                <div class="input-group input-group-sm" style="max-width: 300px">
                    <span class="input-group-text"><i class="fa-solid fa-magnifying-glass"></i></span>
                    <input type="search" class="form-control" id="service-filter" placeholder="Search services" aria-label="Search services" autocomplete="off">
                </div>
                <span class="small text-muted fw-normal ms-auto" id="service-filter-count"><?php echo count($services); ?> services</span>
            </div>
            <?php } ?>
            <div class="table-responsive">
            <table class="table mb-0">
                <thead><tr><th>Picture</th><th>Name</th><th class="num">Price</th><th></th></tr></thead>
                <tbody>
                <?php if (count($services) === 0) { ?>
                    <tr><td colspan="4" class="text-center text-muted py-4">No services yet. Add the first one on the left.</td></tr>
                <?php } ?>
                <tr id="service-filter-none" hidden><td colspan="4" class="text-center text-muted py-4">No service matches your search.</td></tr>
                <?php foreach ($services as $s) { ?>
                    <tr class="<?php echo $editing && (int)$editing['service_id'] === (int)$s['service_id'] ? 'table-warning' : ''; ?>" data-search="<?php echo e(strtolower($s['name'] . ' ' . rm($s['price']))); ?>">
                        <td><img src="../<?php echo e($s['image']); ?>" class="thumb" alt=""></td>
                        <td><?php echo e($s['name']); ?></td>
                        <td class="num"><?php echo rm($s['price']); ?></td>
                        <td class="text-end text-nowrap">
                            <a href="services.php?edit=<?php echo $s['service_id']; ?>#service-form" class="btn btn-sm btn-outline-dark"><i class="fa-solid fa-pen"></i> Edit</a>
                            <form method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="service_id" value="<?php echo $s['service_id']; ?>">
                                <button class="btn btn-sm btn-outline-danger" name="action" value="delete" onclick="return confirm('Delete <?php echo e(addslashes($s['name'])); ?>? Customers will not see it any more.')"><i class="fa-solid fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<script>
// Same search as the customer Services page: every word must be in the name or price
document.getElementById('service-filter')?.addEventListener('input', (event) => {
    const words = event.target.value.toLowerCase().split(/\s+/).filter(Boolean);
    const rows = document.querySelectorAll('tr[data-search]');
    let shown = 0;
    rows.forEach(row => {
        row.hidden = !words.every(w => row.dataset.search.includes(w));
        if (!row.hidden) shown++;
    });
    document.getElementById('service-filter-none').hidden = shown > 0;
    document.getElementById('service-filter-count').textContent =
        words.length ? `${shown} of ${rows.length} services` : `${rows.length} services`;
});
</script>
<?php admin_footer(); ?>
