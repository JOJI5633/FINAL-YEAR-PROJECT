<?php
// Booking rules shared by the customer pages and /admin:
// opening hours, closed days, barbers and which time slots are still free.
date_default_timezone_set('Asia/Kuala_Lumpur');

// All rows from the `setting` table, loaded once per request
function settings($conn) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        $result = mysqli_query($conn, "SELECT name, value FROM setting");
        while ($row = mysqli_fetch_assoc($result)) {
            $cache[$row['name']] = $row['value'];
        }
    }
    return $cache;
}

function setting($conn, $name) {
    return settings($conn)[$name] ?? '';
}

// Shop logo, changed in Admin -> Settings
function logo($conn) {
    $logo = setting($conn, 'logo_image');
    return $logo !== '' ? $logo : 'images/logo.png';
}

// Login page wallpaper, changed in Admin -> Settings.
// 'plain' (dark colour), 'video' (the home page video) or an image path.
define('LOGIN_BG_DEFAULT', 'barbershop.about.jpg');
define('LOGIN_BG_DIR', 'images/login-bg');

function login_background($conn) {
    $bg = setting($conn, 'login_bg');
    if ($bg === '' || ($bg !== 'plain' && $bg !== 'video' && !is_file(__DIR__ . '/' . $bg))) {
        $bg = LOGIN_BG_DEFAULT;   // never set, or the picture was deleted
    }
    $dim = setting($conn, 'login_bg_dim');
    // dim = how dark the picture is made (%), so the form stays easy to read
    return ['bg' => $bg, 'dim' => $dim === '' ? 20 : max(0, min(85, (int)$dim))];
}

// Wallpapers the owner uploaded, newest first
function login_bg_uploads() {
    $files = [];
    foreach (glob(__DIR__ . '/' . LOGIN_BG_DIR . '/bg-*') ?: [] as $file) {
        if (preg_match('/^bg-[a-f0-9]{16}\.(jpg|png|webp)$/', basename($file))) {
            $files[LOGIN_BG_DIR . '/' . basename($file)] = filemtime($file);
        }
    }
    arsort($files);
    return array_keys($files);
}

// Map on the home page: the owner's own Google Maps embed link, or one made from the address
function map_src($conn) {
    $custom = setting($conn, 'map_embed');
    if ($custom !== '') {
        return $custom;
    }
    return 'https://maps.google.com/maps?q=' . rawurlencode(setting($conn, 'shop_address')) . '&z=16&output=embed';
}

// Footer icons the owner has filled in (empty ones are hidden): [icon class, name, link]
function social_links($conn) {
    $links = [];
    foreach (['instagram' => 'Instagram', 'facebook' => 'Facebook', 'twitter' => 'Twitter'] as $key => $name) {
        $url = setting($conn, 'social_' . $key);
        if ($url !== '') {
            $links[] = [$key === 'facebook' ? 'fa-facebook-f' : 'fa-' . $key, $name, $url];
        }
    }
    $whatsapp = preg_replace('/\D/', '', setting($conn, 'whatsapp_number'));
    if ($whatsapp !== '') {
        $links[] = ['fa-whatsapp', 'WhatsApp', 'https://wa.me/' . $whatsapp];
    }
    return $links;
}

function rm($amount) {
    return 'RM' . number_format($amount, 2);
}

// Every bookable time, e.g. 10:00, 10:30 ... 21:30
function slot_list($conn) {
    $slots = [];
    $step = max(10, (int)setting($conn, 'slot_minutes')) * 60;
    $t = strtotime(setting($conn, 'open_time'));
    $end = strtotime(setting($conn, 'close_time'));
    while ($t < $end) {
        $slots[] = date('H:i', $t);
        $t += $step;
    }
    return $slots;
}

// Barbers customers can choose
function active_barbers($conn) {
    $result = mysqli_query($conn, "SELECT staff_id, name FROM staff WHERE is_barber = 1 AND active = 1 ORDER BY staff_id");
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function barber_name($conn, $id) {
    $stmt = mysqli_prepare($conn, "SELECT name FROM staff WHERE staff_id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    return $row['name'] ?? '-';
}

// Why the shop is closed on a date, or '' when it is open
function closed_reason($conn, $date) {
    $days = array_filter(explode(',', setting($conn, 'closed_days')), 'strlen');
    $weekday = date('w', strtotime($date));
    if (in_array($weekday, $days)) {
        return 'The shop is closed every ' . date('l', strtotime($date)) . '.';
    }

    $stmt = mysqli_prepare($conn, "SELECT note FROM holiday WHERE holiday_date = ?");
    mysqli_stmt_bind_param($stmt, 's', $date);
    mysqli_stmt_execute($stmt);
    $holiday = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if ($holiday) {
        return 'The shop is closed on this date' . ($holiday['note'] !== '' ? ' (' . $holiday['note'] . ')' : '') . '.';
    }

    if (count(active_barbers($conn)) === 0) {
        return 'No barber is available right now.';
    }
    return '';
}

// Bookings that still hold a chair on a date (rejected payments and cancelled bookings don't)
function day_bookings($conn, $date) {
    $stmt = mysqli_prepare($conn, "SELECT TIME_FORMAT(time, '%H:%i') AS t, barber_id FROM receipt
                                   WHERE date = ? AND job_status <> 'cancelled'
                                   AND (payment_status IS NULL OR payment_status <> 'rejected')");
    mysqli_stmt_bind_param($stmt, 's', $date);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
}

// Barbers still free at a time, the one with the fewest bookings that day first
function free_barbers($conn, $date, $time, $bookings = null) {
    $bookings = $bookings ?? day_bookings($conn, $date);
    $busy = [];
    $load = [];
    $unassigned = 0;
    foreach ($bookings as $b) {
        if ($b['barber_id']) {
            $load[$b['barber_id']] = ($load[$b['barber_id']] ?? 0) + 1;
        }
        if ($b['t'] === $time) {
            if ($b['barber_id']) {
                $busy[] = $b['barber_id'];
            } else {
                $unassigned++;
            }
        }
    }

    $free = [];
    foreach (active_barbers($conn) as $barber) {
        if (!in_array($barber['staff_id'], $busy)) {
            $free[] = (int)$barber['staff_id'];
        }
    }
    usort($free, function ($a, $b) use ($load) {
        return (($load[$a] ?? 0) <=> ($load[$b] ?? 0)) ?: $a <=> $b;
    });
    // Old bookings made before barbers existed still take one chair each
    return array_slice($free, 0, max(0, count($free) - $unassigned));
}

function barber_is_free($conn, $date, $time, $barber_id, $bookings = null) {
    $bookings = $bookings ?? day_bookings($conn, $date);
    foreach ($bookings as $b) {
        if ($b['t'] === $time && (int)$b['barber_id'] === (int)$barber_id) {
            return false;
        }
    }
    return true;
}

// Times that cannot be booked: closed day, already passed, or no chair left
// $barber is 'any' or a staff_id
function unavailable_times($conn, $date, $barber) {
    if (closed_reason($conn, $date) !== '') {
        return slot_list($conn);
    }
    $bookings = day_bookings($conn, $date);
    $times = [];
    foreach (slot_list($conn) as $slot) {
        if ($date === date('Y-m-d') && $slot <= date('H:i')) {
            $times[] = $slot;
        } elseif ($barber === 'any') {
            if (count(free_barbers($conn, $date, $slot, $bookings)) === 0) {
                $times[] = $slot;
            }
        } elseif (!barber_is_free($conn, $date, $slot, $barber, $bookings)) {
            $times[] = $slot;
        }
    }
    return $times;
}
