<?php
include 'shop_functions.php';

$items = cart_items($conn);
if (count($items) === 0) {
    header("Location: service.php");
    exit();
}
if (!isset($_SESSION['booking']['barber'], $_SESSION['booking']['time'])) {
    header("Location: date-time.php");
    exit();
}
$booking = $_SESSION['booking'];
$total = cart_total($items);
$method = $_POST['method'] ?? '';
$error = '';

if (isset($_POST['confirm'])) {
    $proof = null;

    // "Any barber" gets the free barber with the fewest bookings that day
    if ($booking['barber'] === 'any') {
        $barber_id = free_barbers($conn, $booking['date'], $booking['time'])[0] ?? null;
    } else {
        $barber_id = barber_is_free($conn, $booking['date'], $booking['time'], $booking['barber']) ? $booking['barber'] : null;
    }

    if (!in_array($method, ['cash', 'online'])) {
        $error = "Please choose a payment method.";
    } elseif ($barber_id === null || closed_reason($conn, $booking['date']) !== '') {
        // Someone took the slot while this customer was paying
        unset($_SESSION['booking']['time']);
        header("Location: date-time.php?busy=1");
        exit();
    } elseif ($method === 'online') {
        // Online payment needs a receipt (image or PDF) for the admin to check
        $file = $_FILES['proof'] ?? null;
        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'];

        if (!$file || $file['error'] === UPLOAD_ERR_NO_FILE) {
            $error = "Please upload your payment receipt.";
        } elseif ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > 5 * 1024 * 1024) {
            $error = "Upload failed. The receipt must be smaller than 5MB.";
        } else {
            $type = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
            if (!isset($allowed[$type])) {
                $error = "Receipt must be a JPG, PNG, WEBP or PDF file.";
            } else {
                $proof = 'uploads/receipts/' . bin2hex(random_bytes(16)) . '.' . $allowed[$type];
                if (!move_uploaded_file($file['tmp_name'], __DIR__ . '/' . $proof)) {
                    $error = "Could not save the receipt. Please try again.";
                    $proof = null;
                }
            }
        }
    }

    if ($error === '') {
        // Same "name/email" format as the old bookings
        $stmt = mysqli_prepare($conn, "SELECT username, email FROM customer WHERE cust_id = ?");
        mysqli_stmt_bind_param($stmt, 'i', $cust_id);
        mysqli_stmt_execute($stmt);
        $customer = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        $name = $customer['username'] . '/' . $customer['email'];
        $status = $method === 'cash' ? 'cash' : 'pending';

        mysqli_begin_transaction($conn);
        try {
            // Remember if the customer asked for this barber by name (used to rank staff)
            $chosen = $booking['barber'] === 'any' ? 0 : 1;
            $stmt = mysqli_prepare($conn, "INSERT INTO receipt (cust_id, name, date, time, notes, total, payment_method, payment_proof, payment_status, barber_id, chosen_barber)
                                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, 'issssdsssii', $cust_id, $name, $booking['date'], $booking['time'],
                                   $booking['notes'], $total, $method, $proof, $status, $barber_id, $chosen);
            mysqli_stmt_execute($stmt);
            $receiptid = mysqli_insert_id($conn);

            $stmt = mysqli_prepare($conn, "INSERT INTO receipt_item (receipt_ID, service_name, price) VALUES (?, ?, ?)");
            foreach ($items as $item) {
                mysqli_stmt_bind_param($stmt, 'isd', $receiptid, $item['name'], $item['price']);
                mysqli_stmt_execute($stmt);
            }
            mysqli_commit($conn);
        } catch (mysqli_sql_exception $e) {
            mysqli_rollback($conn);
            if ($proof) {
                unlink(__DIR__ . '/' . $proof);
            }
            $error = "Booking failed. Please try again.";
        }

        if ($error === '') {
            // Booking done, empty the cart
            $_SESSION['cart'] = [];
            unset($_SESSION['booking']);
            header("Location: Receipt.php?receiptID=$receiptid");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment | KI'AD BARBER BOOKING SYSTEM</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="shop-style.css">
</head>
<body>
<?php include 'customer-nav.php'; ?>

<main class="page narrow">
    <?php render_steps(4); ?>
    <h1 class="heading"><span>payment</span></h1>
    <p class="sub">Check your booking, then choose how you want to pay.</p>

    <?php if ($error) { ?>
    <div class="alert error"><i class="fas fa-circle-exclamation"></i> <?php echo $error; ?></div>
    <?php } ?>

    <div class="panel">
        <h2>Booking summary</h2>
        <ul class="summary">
            <?php foreach ($items as $item) { ?>
            <li><span><?php echo htmlspecialchars($item['name']); ?></span><span><?php echo rm($item['price']); ?></span></li>
            <?php } ?>
            <li><span>Barber</span><span><?php echo $booking['barber'] === 'any' ? 'Any barber (first available)' : htmlspecialchars(barber_name($conn, $booking['barber'])); ?></span></li>
            <li><span>Date</span><span><?php echo date('l, j F Y', strtotime($booking['date'])); ?></span></li>
            <li><span>Time</span><span><?php echo date('g:i A', strtotime($booking['time'])); ?></span></li>
            <li><span>Notes</span><span><?php echo $booking['notes'] !== '' ? htmlspecialchars($booking['notes']) : '-'; ?></span></li>
        </ul>
        <div class="total-row"><span>Total</span><span><?php echo rm($total); ?></span></div>
        <p class="hint"><a href="cart.php">Change services</a> &middot; <a href="date-time.php">Change barber / date / time</a></p>
    </div>

    <form method="POST" enctype="multipart/form-data" class="panel">
        <?php echo csrf_field(); ?>
        <h2>Payment method</h2>
        <div class="pay-options">
            <label class="pay-option">
                <input type="radio" name="method" value="cash" <?php echo $method === 'cash' ? 'checked' : ''; ?>>
                <i class="fas fa-money-bill-wave"></i>
                <strong>Cash</strong>
                <small>Pay at the shop</small>
            </label>
            <label class="pay-option">
                <input type="radio" name="method" value="online" <?php echo $method === 'online' ? 'checked' : ''; ?>>
                <i class="fas fa-qrcode"></i>
                <strong>Online payment</strong>
                <small>Scan QR &amp; upload receipt</small>
            </label>
        </div>

        <div class="qr-box" id="online-box" <?php echo $method === 'online' ? '' : 'hidden'; ?>>
            <img src="<?php echo htmlspecialchars(setting($conn, 'qr_image')); ?>" alt="Payment QR code">
            <p class="amount">Pay <strong><?php echo rm($total); ?></strong></p>
            <div class="field">
                <label for="proof">Upload payment receipt</label>
                <input type="file" id="proof" name="proof" accept="image/jpeg,image/png,image/webp,application/pdf">
                <p class="hint">Screenshot or PDF of your transfer (max 5MB). The admin will check it before your appointment.</p>
            </div>
        </div>

        <button type="submit" name="confirm" value="1" class="btn full"><i class="fas fa-check"></i> Confirm booking</button>
    </form>
</main>

<script>
// Show the QR and upload box only for online payment
const onlineBox = document.getElementById('online-box');
const proof = document.getElementById('proof');
document.querySelectorAll('input[name="method"]').forEach(radio => {
    radio.addEventListener('change', () => {
        const online = radio.value === 'online';
        onlineBox.hidden = !online;
        proof.required = online;
    });
});
proof.required = !onlineBox.hidden;
</script>
</body>
</html>
