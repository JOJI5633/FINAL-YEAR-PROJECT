<?php
include 'bootstrap.php';

// Only log out the customer (and their cart), keep any admin session
unset($_SESSION['cust_id'], $_SESSION['cust_name'], $_SESSION['cart'], $_SESSION['booking'], $_SESSION['must_change_password']);

header("Location: Login.php");
exit();
