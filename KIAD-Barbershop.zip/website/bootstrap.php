<?php
// First file every web page loads: settings, safety options, session, database.
$config = require __DIR__ . '/config.php';
$is_production = $config['env'] === 'production';
date_default_timezone_set('Asia/Kuala_Lumpur');   // also for the times written in the error log

// ---------- errors ----------
// On the real website errors are written to storage/logs, never shown to visitors
error_reporting(E_ALL);
ini_set('display_errors', $is_production ? '0' : '1');
ini_set('log_errors', '1');
if (is_writable(__DIR__ . '/storage/logs')) {
    ini_set('error_log', __DIR__ . '/storage/logs/php-errors.log');
}

// ---------- https + browser safety headers ----------
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
      || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
if ($is_production && !$https && PHP_SAPI !== 'cli') {
    header('Location: https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'], true, 301);
    exit();
}
header_remove('X-Powered-By');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');

// ---------- session ----------
// Cookie can't be read by scripts, isn't sent from other sites, and only over https on the real site.
// Logins last 8 hours of inactivity (PHP's default of 24 minutes kept logging staff out).
ini_set('session.use_strict_mode', '1');
ini_set('session.gc_maxlifetime', (string)(8 * 3600));
if (is_writable(__DIR__ . '/storage/sessions')) {
    // our own folder, so other websites on shared hosting can't clear our sessions early
    session_save_path(__DIR__ . '/storage/sessions');
}
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => $https,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

// ---------- forms ----------
// Every form carries this token, so another website can't submit forms as the visitor
function csrf_field() {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return '<input type="hidden" name="csrf" value="' . $_SESSION['csrf'] . '">';
}

function check_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(400);
        exit('This page has expired. Go back, refresh the page and try again.');
    }
}

include __DIR__ . '/connection.php';
include __DIR__ . '/booking_lib.php';
