<?php
include 'bootstrap.php';

$receipt_ID = (int)($_GET['receiptID'] ?? 0);

$stmt = mysqli_prepare($conn, "SELECT r.*, s.name AS barber FROM receipt r LEFT JOIN staff s ON s.staff_id = r.barber_id WHERE r.receipt_ID = ?");
mysqli_stmt_bind_param($stmt, 'i', $receipt_ID);
mysqli_stmt_execute($stmt);
$row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Only the customer who booked it, or shop staff, can see a receipt
$is_admin = isset($_SESSION['staff_id']);
$is_owner = $row && isset($_SESSION['cust_id']) && $_SESSION['cust_id'] == $row['cust_id'];
if (!$is_admin && !$is_owner) {
    $row = null;
}

$items = [];
$can_rate = false;
if ($row && $is_owner && $row['job_status'] === 'done' && $row['barber_id']) {
    $can_rate = mysqli_num_rows(mysqli_query($conn, "SELECT 1 FROM review WHERE receipt_ID = " . (int)$receipt_ID)) === 0;
}
if ($row) {
    $stmt = mysqli_prepare($conn, "SELECT service_name, price FROM receipt_item WHERE receipt_ID = ?");
    mysqli_stmt_bind_param($stmt, 'i', $receipt_ID);
    mysqli_stmt_execute($stmt);
    $items = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
}

$status_text = [
    'cash'     => 'Pay cash at the shop',
    'pending'  => 'Waiting for admin to check your receipt',
    'verified' => 'Paid',
    'rejected' => 'Payment rejected - please contact the shop',
];
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt</title>
    <style>
        /* CSS styles for the receipt */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h1 {
            text-align: center;
        }
        .receipt {
            max-width: 640px;
            margin: 0 auto;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 20px;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            width: 40%;
            color: #555;
        }
        .items th {
            width: auto;
            background: #f4f4f4;
        }
        .right {
            text-align: right;
        }
        .total td {
            font-weight: bold;
            font-size: 1.1em;
        }
        .status {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 12px;
            background: #eee;
            font-weight: bold;
        }
        .status.verified { background: #d4edda; color: #155724; }
        .status.pending  { background: #fff3cd; color: #856404; }
        .status.rejected { background: #f8d7da; color: #721c24; }
        .center {
            text-align: center;
        }
        .print-button {
            text-align: center;
            margin-top: 20px;
        }
        .print-button button {
            padding: 8px 18px;
            margin: 0 4px;
            cursor: pointer;
        }
        .note {
            text-align: center;
            margin-top: 20px;
            font-style: italic;
        }
        @media print {
            .print-button { display: none; }
        }
    </style>
</head>
<body>
<div class="receipt">
    <h1>Receipt</h1>

    <?php if (!$row) { ?>
    <p class="center">Receipt not found.</p>
    <?php } else { ?>
    <table>
        <tr><th>Receipt ID</th><td>#<?php echo $row['receipt_ID']; ?></td></tr>
        <tr><th>Customer ID</th><td><?php echo $row['cust_id']; ?></td></tr>
        <tr><th>Name/Email</th><td><?php echo htmlspecialchars($row['name']); ?></td></tr>
        <?php if ($row['barber']) { ?>
        <tr><th>Barber</th><td><?php echo htmlspecialchars($row['barber']); ?></td></tr>
        <?php } ?>
        <tr><th>Date</th><td><?php echo date('l, j F Y', strtotime($row['date'])); ?></td></tr>
        <tr><th>Time</th><td><?php echo date('g:i A', strtotime($row['time'])); ?></td></tr>
        <tr><th>Note(Haircut)</th><td><?php echo $row['notes'] !== '' ? htmlspecialchars($row['notes']) : '-'; ?></td></tr>
        <?php if ($row['payment_method']) { ?>
        <tr><th>Payment</th><td><?php echo $row['payment_method'] === 'cash' ? 'Cash' : 'Online (QR)'; ?></td></tr>
        <tr><th>Status</th><td><span class="status <?php echo $row['payment_status']; ?>"><?php echo $status_text[$row['payment_status']] ?? $row['payment_status']; ?></span></td></tr>
        <?php } ?>
        <?php if ($row['job_status'] === 'cancelled') { ?>
        <tr><th>Booking</th><td><span class="status rejected">Cancelled by the shop</span></td></tr>
        <?php } ?>
    </table>

    <?php if (count($items) > 0) { ?>
    <table class="items">
        <tr><th>Service</th><th class="right">Price</th></tr>
        <?php foreach ($items as $item) { ?>
        <tr><td><?php echo htmlspecialchars($item['service_name']); ?></td><td class="right">RM<?php echo number_format($item['price'], 2); ?></td></tr>
        <?php } ?>
        <tr class="total"><td>Total</td><td class="right">RM<?php echo number_format($row['total'], 2); ?></td></tr>
    </table>
    <?php } ?>

    <div class="note">
        PLEASE SCREENSHOT THIS RECEIPT BEFORE HAVING A HAIRCUT
    </div>
    <?php } ?>

    <!-- Print button -->
    <div class="print-button">
        <button onclick="window.print()">Print</button>
        <?php if ($can_rate) { ?>
        <button onclick="location.href='my-bookings.php#booking-<?php echo $receipt_ID; ?>'">Rate your barber</button>
        <?php } ?>
        <button onclick="location.href='home.php'">Back to Home</button>
    </div>
</div>
</body>
</html>
