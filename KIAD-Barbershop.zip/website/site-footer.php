<section class="footer">
    <?php $social = social_links($conn); ?>
    <?php if (count($social) > 0) { ?>
    <!-- links are set in Admin -> Manage -> Settings -> Social media -->
    <div class="social">
        <?php foreach ($social as [$icon, $name, $url]) { ?>
        <a href="<?php echo htmlspecialchars($url); ?>" target="_blank" rel="noopener" aria-label="KI'AD on <?php echo $name; ?>" title="<?php echo $name; ?>"><i class="fab <?php echo $icon; ?>"></i></a>
        <?php } ?>
    </div>
    <?php } ?>

    <ul class="list">
        <li>
            <a href="policy.php#terms">Terms</a>
        </li>
        <li>
            <a href="policy.php#privacy">Privacy Policy</a>
        </li>
    </ul>

    <p class="copyright">
        &copy; <?php echo date('Y'); ?> KI'AD Barbershop
    </p>
</section>
