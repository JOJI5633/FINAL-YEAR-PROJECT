<?php
include 'bootstrap.php';
$logged_in = isset($_SESSION['cust_id']);

// Newest good reviews from real customers; the Review section stays hidden until there are some
$real_reviews = mysqli_fetch_all(mysqli_query($conn, "
    SELECT v.stars, v.comment, c.username, s.name AS barber FROM review v
    JOIN customer c ON c.cust_id = v.cust_id LEFT JOIN staff s ON s.staff_id = v.barber_id
    WHERE v.stars >= 4 AND v.comment <> '' ORDER BY v.created_at DESC LIMIT 3"), MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X_UA_Compatible" content="IE-edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>KI'AD BARBER BOOKING SYSTEM</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />  
        <link rel="stylesheet" href="home-style.css">
        <link rel="icon" type="image/png" href="favicon-32x32.png">
        <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    </head>    
    <body>
        <div class="hero">
    
            <video autoplay loop muted playsinline class="back-video">
                <source src="background.mp4" type="video/mp4">
            </video>
    
            <nav>
                <img src="<?php echo htmlspecialchars(logo($conn)); ?>" class="logo" alt="KI'AD Barbershop">
                <!-- phones: the links fold into this menu button -->
                <button type="button" class="menu-toggle" aria-expanded="false" aria-controls="main-menu" aria-label="Menu"><i class="fas fa-bars"></i></button>
                <ul id="main-menu">
                   <li><a href="#">Home</a></li> 
                   <li><a href="#about">About us</a></li>  
                   <?php if (count($real_reviews) > 0) { ?><li><a href="#review">Review</a></li><?php } ?>
                   <li><a href="#contact">Contacts</a></li>
                   <?php if ($logged_in) { ?>
                   <li><a href="my-account.php" class="nav-user"><i class="fas fa-user"></i> Hi, <?php echo htmlspecialchars($_SESSION['cust_name']); ?></a></li>
                   <li><a href="logout.php">Logout</a></li>
                   <?php } else { ?>
                   <li><a href="Login.php">Log in</a></li>
                   <?php } ?>
                </ul>
            </nav>
            <div class="content">
                <h1>We Create & Renovate</h1>
                <h2> Hair Style Trends</h2>
                <!-- logged in customers go straight to the services -->
                <a href="<?php echo $logged_in ? 'service.php' : 'Login.php'; ?>">MAKE AN APPOINTMENT</a>
            </div>
        </div>
                <section class="about" id="about">
                    <h1 class="heading"> <span>about</span> us </h1>
                    <div class="row">
                        <div class="image">
                            <img src="barbershop.about.jpg" alt="">
                        </div>
                        <div class="content">
                            <h3>WE WELCOME ANY GUY, ANY AGE.</h3>
                            <p>Do you need a great haircut and shave? You simply cannot 
                            trust just any barber to cut your hair or shave your beard. At 
                            KI'AD Barber Shop, we specialize in delivering the ultimate 
                            barber shop experience by giving haircuts and shaves that are
                            truly exceptional.</p>
                            <p>From the moment our clients walk through the 
                            door, they instantly realize that we are a barber shop that
                            values excellent customer service and above all else amazing 
                            shaves and haircuts.</p>  
                        </div>
                    </div>
                </section>

   
                <?php if (count($real_reviews) > 0) { ?>
                <section class="review" id="review">

                    <h1 class="heading"> customer's <span>review</span> </h1>

                    <div class="box-container">

                        <?php foreach ($real_reviews as $v) {
                            $initials = strtoupper(mb_substr($v['username'], 0, 2)); ?>
                        <div class="box">
                            <img src="quote-icon-quotation-symbol-flat-vector-6690297_prev_ui.png" alt="" class="quote">
                            <p><?php echo htmlspecialchars($v['comment']); ?></p>
                            <div class="avatar"><?php echo htmlspecialchars($initials); ?></div>
                            <h3><?php echo htmlspecialchars($v['username']); ?></h3>
                            <?php if ($v['barber']) { ?><p class="review-barber">Barber: <?php echo htmlspecialchars($v['barber']); ?></p><?php } ?>
                            <div class="stars" role="img" aria-label="<?php echo $v['stars']; ?> out of 5 stars">
                                <?php echo str_repeat('<i class="fas fa-star"></i>', $v['stars']) . str_repeat('<i class="far fa-star"></i>', 5 - $v['stars']); ?>
                            </div>
                        </div>
                        <?php } ?>


                    </div>

                </section>
                <?php } ?>

                <section class="contact" id="contact">

                    <h1 class="heading"> <span>contact</span> us </h1>
                    <!-- address, phone and map are edited in Admin -> Manage -> Settings -->
                    <div class="col">
                        <div class="row">
                            <iframe class="map" src="<?php echo htmlspecialchars(map_src($conn)); ?>" title="Map to KI'AD Barbershop"
                            allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                            <div class="call">
                                <span class="fas fa-phone"></span>
                                <p><a href="tel:<?php echo htmlspecialchars(preg_replace('/[^\d+]/', '', setting($conn, 'shop_phone'))); ?>"><?php echo htmlspecialchars(setting($conn, 'shop_phone')); ?></a></p>

                                <span class="fas fa-map"></span>
                                <p><?php echo nl2br(htmlspecialchars(setting($conn, 'shop_address'))); ?></p>
                                <p><a class="directions" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&amp;query=<?php echo rawurlencode(setting($conn, 'shop_address')); ?>"><i class="fas fa-location-arrow"></i> Get directions</a></p>
                            </div>
                        </div>
                    </div>
                </section>
                
    
<?php include 'site-footer.php'; ?>

<script>
// Phone menu: open / close, and close again after choosing a link
const menuButton = document.querySelector('.menu-toggle');
const menu = document.getElementById('main-menu');
menuButton.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', open);
    menuButton.innerHTML = open ? '<i class="fas fa-xmark"></i>' : '<i class="fas fa-bars"></i>';
});
menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    menu.classList.remove('open');
    menuButton.setAttribute('aria-expanded', false);
    menuButton.innerHTML = '<i class="fas fa-bars"></i>';
}));
</script>
                            </body>
</html>
