<?php
// Returns the times that cannot be booked for ?date=YYYY-MM-DD&barber=any|<staff_id> (used by date-time.php)
include 'shop_functions.php';

header('Content-Type: application/json');
$date = $_GET['date'] ?? '';
$barber = ($_GET['barber'] ?? 'any') === 'any' ? 'any' : (int)$_GET['barber'];
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    echo json_encode(['unavailable' => [], 'closed' => '']);
    exit();
}
echo json_encode([
    'unavailable' => unavailable_times($conn, $date, $barber),
    'closed'      => closed_reason($conn, $date),
]);
