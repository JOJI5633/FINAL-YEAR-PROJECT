# Panduan pasang KI'AD ke hosting sebenar

Panduan ni untuk hosting yang guna **cPanel** (kebanyakan hosting di Malaysia). Ikut ikut urutan.

---

## 0. Apa yang perlu ada

- Hosting cPanel dengan **PHP 8.1 ke atas** dan **MySQL / MariaDB**
- **Domain** (contoh `kiadbarber.com`)
- **SSL** (https). Kebanyakan cPanel bagi percuma melalui *AutoSSL*.

---

## 1. Siapkan kandungan DI LAPTOP dulu

Login admin kat laptop, dan pastikan semua ni dah betul:

| Perkara | Tempat |
|---|---|
| QR bayaran sebenar | Manage → Settings → **Payment QR** |
| Harga + gambar servis | Manage → **Services** |
| Nama pekerja sebenar | Manage → **Staff** |
| Alamat, telefon, peta | Manage → Settings → **Location & contact** |
| Nombor WhatsApp kedai | Manage → Settings → **Shop WhatsApp** |
| Instagram / Facebook / Twitter | Manage → Settings → **Social media** |
| Terms & Privacy | Manage → Settings → **Terms & privacy** |
| Logo | Manage → Settings → **Logo** |
| **Password admin + semua barber** | My account / Manage → Staff → Edit |

Dashboard akan tunjuk amaran kuning selagi ada akaun yang masih guna password permulaan (`admin123`, `barber123`).

---

## 2. Jana fail database bersih

Buka **Command Prompt** dan jalankan:

```
C:\xampp\php\php.exe C:\Users\User\Downloads\kiad\tools\export-for-hosting.php
```

Fail `database\kiad_install.sql` akan dikemas kini. Isinya semua tetapan, servis dan akaun staf, **tanpa** customer, tempahan atau data ujian.

---

## 3. Buat database dalam cPanel

1. cPanel → **MySQL® Database Wizard**
2. Cipta database, contoh `kiad` (cPanel akan jadikan dia `namaakaun_kiad`)
3. Cipta user database dengan password yang kuat, dan **catat password tu**
4. Beri user tu **ALL PRIVILEGES** pada database tadi
5. cPanel → **phpMyAdmin** → pilih database baru → tab **Import** → pilih `kiad_install.sql` → **Import**

---

## 4. Upload fail website

1. Kat laptop, zip folder `kiad`. **Jangan masukkan** isi folder `storage\sessions` dan `uploads\receipts` (tu data ujian laptop).
2. cPanel → **File Manager** → buka `public_html` (atau folder domain kau)
3. **Upload** zip tu → klik kanan → **Extract**
4. Pastikan fail seperti `home.php`, `Login.php`, `config.php` berada terus dalam `public_html`, bukan dalam `public_html/kiad/`.
   (Kalau tersilap, pindahkan semua fail naik satu folder.)

---

## 5. Edit `config.php` (dalam File Manager → Edit)

```php
return [
    'env' => 'production',

    'db_host' => 'localhost',
    'db_port' => 3306,
    'db_name' => 'namaakaun_kiad',      // nama penuh database dari langkah 3
    'db_user' => 'namaakaun_kiaduser',  // nama penuh user dari langkah 3
    'db_pass' => 'password-user-database',
];
```

Bila `'env' => 'production'`:
- Ralat PHP tak ditunjuk kepada customer (dia disimpan dalam `storage/logs/php-errors.log`)
- Semua pelawat dihantar ke **https** secara automatik

---

## 6. Kebenaran folder

Folder ni mesti boleh ditulis oleh website. Dalam File Manager, klik kanan → **Change Permissions** → **755** (kalau upload masih gagal, cuba **775**):

- `uploads/receipts` (resit bayaran customer)
- `images` dan `images/services` (logo, QR, gambar servis)
- `storage/sessions` dan `storage/logs`

---

## 7. Hidupkan SSL (https)

cPanel → **SSL/TLS Status** → **Run AutoSSL**. Tunggu beberapa minit, lepas tu buka `https://domain-kau.com`.

---

## 8. Uji sebelum umumkan kepada customer

- [ ] `https://domain-kau.com` buka home page (video, peta, footer)
- [ ] Login `admin` dengan password baru → Dashboard keluar
- [ ] Daftar satu akaun customer ujian → buat tempahan → pilih **Online** → upload resit
- [ ] Admin → Bookings → **Verify payment** jalan, resit boleh dibuka
- [ ] Admin → **Attendance** → buka link *Counter QR screen* kat tablet kaunter → staf scan guna telefon
      (link kaunter **baru**. Link dari laptop tak jalan kat hosting)
- [ ] Buka dari telefon, semua page kemas
- [ ] Padam tempahan dan akaun ujian tadi (Bookings → Cancel)

---

## 9. Lepas publish

- **Backup** setiap minggu: cPanel → **Backup** → *Download a MySQL Database Backup* (dan folder `images`, `uploads`)
- Kalau owner lupa password: cPanel → **Terminal** → `php tools/reset-password.php admin PasswordBaru123`

---

## Masalah biasa

| Apa yang nampak | Punca biasa |
|---|---|
| *"Sorry, the booking system is not available right now"* | Butiran database dalam `config.php` salah (nama/user/password) |
| Page putih kosong | Tengok `storage/logs/php-errors.log` |
| Upload resit/gambar gagal | Kebenaran folder (langkah 6) |
| *"This page has expired"* | Page dibuka terlalu lama. Refresh dan cuba lagi |
| Terlalu banyak cubaan login | Tunggu 15 minit, atau guna *Forgot password* |
