<?php
// ============================================================
//  KI'AD settings for THIS computer / server.
//  On hosting, change the database lines to the ones cPanel gives you,
//  and set 'env' to 'production'. See PANDUAN-HOSTING.md.
// ============================================================

return [
    // 'development' = this laptop (shows PHP errors on screen)
    // 'production'  = real website (hides errors, forces https)
    'env' => 'production',

    'db_host' => 'localhost',
    'db_port' => 3306,
    'db_name' => 'NAMA_DATABASE',
    'db_user' => 'USER_DATABASE',
    'db_pass' => 'PASSWORD_DATABASE',
];
