<?php
// The website starts at the customer home page (staff use /admin)
header("Location: home.php");
exit();
