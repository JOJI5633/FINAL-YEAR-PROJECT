<?php
// Shared by the booking pages: service.php -> cart.php -> date-time.php -> payment.php
include __DIR__ . '/bootstrap.php';
include __DIR__ . '/customer_lib.php';

// Customer must log in before booking
if (!isset($_SESSION['cust_id'])) {
    header("Location: Login.php");
    exit();
}
$cust_id = $_SESSION['cust_id'];

// Logged in with a temporary password: choose a new one before anything else
if (!empty($_SESSION['must_change_password']) && basename($_SERVER['SCRIPT_NAME']) !== 'my-account.php') {
    header("Location: my-account.php");
    exit();
}

// Every form on the booking pages carries the page token
check_csrf();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Services currently in the cart, read fresh from the database
function cart_items($conn) {
    if (empty($_SESSION['cart'])) {
        return [];
    }
    $ids = implode(',', array_map('intval', $_SESSION['cart']));
    $result = mysqli_query($conn, "SELECT * FROM service WHERE service_id IN ($ids) ORDER BY service_id");
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function cart_total($items) {
    return array_sum(array_column($items, 'price'));
}

// Progress bar at the top of each booking page
function render_steps($current) {
    $steps = ['Services', 'Cart', 'Barber & Time', 'Payment'];
    echo '<ol class="steps">';
    foreach ($steps as $i => $label) {
        $n = $i + 1;
        $class = $n < $current ? 'done' : ($n == $current ? 'active' : '');
        echo "<li class=\"$class\"><span>$n</span> $label</li>";
    }
    echo '</ol>';
}
