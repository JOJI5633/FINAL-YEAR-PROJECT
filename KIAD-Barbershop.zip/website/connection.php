<?PHP
// Database connection, using the settings in config.php
$config = $config ?? require __DIR__ . '/config.php';

// Create connection
try {
    $conn = mysqli_connect($config['db_host'], $config['db_user'], $config['db_pass'], $config['db_name'], (int)$config['db_port']);
    mysqli_set_charset($conn, 'utf8mb4');
} catch (mysqli_sql_exception $e) {
    // Details go to the error log; visitors only see a short message
    error_log('KIAD database connection failed: ' . $e->getMessage());
    http_response_code(503);
    die($config['env'] === 'production'
        ? 'Sorry, the booking system is not available right now. Please try again later.'
        : 'Connection failed: ' . $e->getMessage() . ' (check config.php)');
}
