<?php
include 'shop_functions.php';

$services = mysqli_fetch_all(mysqli_query($conn, "SELECT * FROM service ORDER BY service_id"), MYSQLI_ASSOC);
$items = cart_items($conn);

// Search: every word typed must appear in the name or price ("fade", "kids", "rm15")
$q = trim($_GET['q'] ?? '');
$words = preg_split('/\s+/', strtolower($q), -1, PREG_SPLIT_NO_EMPTY);
function service_search_text($s) {
    return strtolower($s['name'] . ' ' . rm($s['price']));
}
$shown = 0;
foreach ($services as $i => $s) {
    $match = true;
    foreach ($words as $w) {
        if (strpos(service_search_text($s), $w) === false) {
            $match = false;
        }
    }
    $services[$i]['match'] = $match;
    $shown += $match ? 1 : 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services | KI'AD BARBER BOOKING SYSTEM</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="shop-style.css">
</head>
<body>
<?php include 'customer-nav.php'; ?>

<main class="page">
    <?php render_steps(1); ?>
    <h1 class="heading">our <span>services</span></h1>
    <p class="sub">Choose one or more services, then continue to your cart.</p>

    <!-- Works without JavaScript too (Enter reloads the page with ?q=) -->
    <form class="service-search" method="get" action="service.php" role="search">
        <i class="fas fa-search" aria-hidden="true"></i>
        <input type="search" name="q" id="service-q" value="<?php echo htmlspecialchars($q); ?>"
               placeholder="Search a cut, e.g. fade, beard, kids" aria-label="Search services" autocomplete="off" enterkeyhint="search">
        <button type="button" class="search-clear" id="service-q-clear" aria-label="Clear search" <?php echo $q === '' ? 'hidden' : ''; ?>><i class="fas fa-times"></i></button>
    </form>
    <p class="search-count" id="search-count" aria-live="polite"><?php
        if ($q !== '' && $shown > 0) {
            echo $shown . ' of ' . count($services) . ' services';
        } ?></p>

    <div class="service-grid">
        <?php foreach ($services as $s) {
            $in_cart = in_array($s['service_id'], $_SESSION['cart']); ?>
        <div class="service-card <?php echo $in_cart ? 'in-cart' : ''; ?>" id="service-<?php echo $s['service_id']; ?>"
             data-search="<?php echo htmlspecialchars(service_search_text($s)); ?>" <?php echo $s['match'] ? '' : 'hidden'; ?>>
            <img src="<?php echo htmlspecialchars($s['image']); ?>" alt="<?php echo htmlspecialchars($s['name']); ?>" loading="lazy">
            <div class="info">
                <h3><?php echo htmlspecialchars($s['name']); ?></h3>
                <div class="price"><?php echo rm($s['price']); ?></div>
                <form method="post" action="cart.php">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="service_id" value="<?php echo $s['service_id']; ?>">
                    <input type="hidden" name="back" value="service">
                    <input type="hidden" name="q" value="<?php echo htmlspecialchars($q); ?>" class="keep-q">
                    <?php if ($in_cart) { ?>
                    <button class="btn outline full" name="action" value="remove"><i class="fas fa-check"></i> In cart &middot; Remove</button>
                    <?php } else { ?>
                    <button class="btn full" name="action" value="add"><i class="fas fa-cart-plus"></i> Add to cart</button>
                    <?php } ?>
                </form>
            </div>
        </div>
        <?php } ?>
    </div>

    <div class="empty" id="search-empty" <?php echo $shown === 0 && $q !== '' ? '' : 'hidden'; ?>>
        <i class="fas fa-search"></i>
        <p>No service matches &ldquo;<span id="search-empty-q"><?php echo htmlspecialchars($q); ?></span>&rdquo;.</p>
        <a href="service.php" class="btn outline small" id="search-show-all">Show all services</a>
    </div>
</main>

<?php if (count($items) > 0) { ?>
<div class="cart-bar">
    <div><?php echo count($items); ?> service(s) &middot; <strong><?php echo rm(cart_total($items)); ?></strong></div>
    <a href="cart.php" class="btn">View cart <i class="fas fa-arrow-right"></i></a>
</div>
<?php } ?>

<script>
// Filter the cards while typing (same rule as the PHP above)
(() => {
    const input = document.getElementById('service-q');
    const clear = document.getElementById('service-q-clear');
    const count = document.getElementById('search-count');
    const empty = document.getElementById('search-empty');
    const cards = [...document.querySelectorAll('.service-card')];

    function filter() {
        const q = input.value.trim();
        const words = q.toLowerCase().split(/\s+/).filter(Boolean);
        let shown = 0;
        cards.forEach(card => {
            const match = words.every(w => card.dataset.search.includes(w));
            card.hidden = !match;
            if (match) shown++;
        });
        clear.hidden = q === '';
        count.textContent = q !== '' && shown > 0 ? `${shown} of ${cards.length} services` : '';
        empty.hidden = !(q !== '' && shown === 0);
        document.getElementById('search-empty-q').textContent = q;
        // Add to cart comes back to the same search
        document.querySelectorAll('.keep-q').forEach(field => field.value = q);
        history.replaceState(null, '', q === '' ? 'service.php' : 'service.php?q=' + encodeURIComponent(q));
    }

    input.addEventListener('input', filter);
    input.form.addEventListener('submit', event => {
        event.preventDefault();
        input.blur();   // closes the phone keyboard
    });
    clear.addEventListener('click', () => {
        input.value = '';
        filter();
        input.focus();
    });
    document.getElementById('search-show-all').addEventListener('click', event => {
        event.preventDefault();
        clear.click();
    });
})();
</script>
</body>
</html>
