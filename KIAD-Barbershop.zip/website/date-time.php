<?php
include 'shop_functions.php';

// Nothing to book yet
if (count($_SESSION['cart']) === 0) {
    header("Location: service.php");
    exit();
}

$barbers = active_barbers($conn);
$barber_ids = array_map('intval', array_column($barbers, 'staff_id'));
$booking = ($_SESSION['booking'] ?? []) + ['barber' => 'any', 'date' => '', 'time' => '', 'notes' => ''];
$error = '';

if (isset($_GET['busy'])) {
    $error = "Sorry, someone just booked that time slot. Please choose another time.";
}

if (isset($_POST['submit'])) {
    $booking = [
        'barber' => ($_POST['barber'] ?? 'any') === 'any' ? 'any' : (int)$_POST['barber'],
        'date'   => $_POST['date'] ?? '',
        'time'   => $_POST['time'] ?? '',
        'notes'  => trim($_POST['notes'] ?? ''),
    ];
    $d = DateTime::createFromFormat('Y-m-d', $booking['date']);

    if ($booking['barber'] !== 'any' && !in_array($booking['barber'], $barber_ids)) {
        $error = "Please choose a barber.";
    } elseif (!$d || $d->format('Y-m-d') !== $booking['date']) {
        $error = "Please choose a date.";
    } elseif ($booking['date'] < date('Y-m-d')) {
        $error = "That date has already passed. Please choose another date.";
    } elseif (($closed = closed_reason($conn, $booking['date'])) !== '') {
        $error = $closed . " Please choose another date.";
    } elseif (!in_array($booking['time'], slot_list($conn))) {
        $error = "Please choose a time.";
    } elseif (in_array($booking['time'], unavailable_times($conn, $booking['date'], $booking['barber']))) {
        // The slot is already booked, inform the customer
        $error = "Sorry, the selected time slot is not available. Please choose another time.";
    } else {
        // Slot is free, go to payment
        $_SESSION['booking'] = $booking;
        header("Location: payment.php");
        exit();
    }
}

$unavailable = $booking['date'] ? unavailable_times($conn, $booking['date'], $booking['barber']) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barber & Time | KI'AD BARBER BOOKING SYSTEM</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="shop-style.css">
</head>
<body>
<?php include 'customer-nav.php'; ?>

<main class="page narrow">
    <?php render_steps(3); ?>
    <h1 class="heading">barber <span>&amp; time</span></h1>
    <p class="sub">Open <?php echo date('g:i A', strtotime(setting($conn, 'open_time'))); ?> &ndash; <?php echo date('g:i A', strtotime(setting($conn, 'close_time'))); ?>. Each slot is <?php echo (int)setting($conn, 'slot_minutes'); ?> minutes.</p>

    <?php if ($error) { ?>
    <div class="alert error"><i class="fas fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?></div>
    <?php } ?>

    <form method="POST" class="panel">
        <?php echo csrf_field(); ?>
        <div class="field">
            <label>Barber</label>
            <div class="barber-options">
                <label class="barber-option">
                    <input type="radio" name="barber" value="any" <?php echo $booking['barber'] === 'any' ? 'checked' : ''; ?>>
                    <span class="avatar"><i class="fas fa-users"></i></span>
                    <span>Any barber<small>First available</small></span>
                </label>
                <?php foreach ($barbers as $b) {
                    $initials = strtoupper(implode('', array_map(fn($w) => $w[0], array_slice(preg_split('/\s+/', trim($b['name'])), 0, 2)))); ?>
                <label class="barber-option">
                    <input type="radio" name="barber" value="<?php echo $b['staff_id']; ?>" <?php echo $booking['barber'] === (int)$b['staff_id'] ? 'checked' : ''; ?>>
                    <span class="avatar"><?php echo htmlspecialchars($initials); ?></span>
                    <span><?php echo htmlspecialchars($b['name']); ?></span>
                </label>
                <?php } ?>
            </div>
        </div>
        <div class="field">
            <label for="date">Date</label>
            <input type="date" id="date" name="date" required
                   min="<?php echo date('Y-m-d'); ?>" value="<?php echo htmlspecialchars($booking['date']); ?>">
        </div>
        <div class="field">
            <label for="time">Time</label>
            <select id="time" name="time" required>
                <option value="">-- Choose a time --</option>
                <?php foreach (slot_list($conn) as $slot) {
                    $taken = in_array($slot, $unavailable); ?>
                <option value="<?php echo $slot; ?>" <?php echo $taken ? 'disabled' : ''; ?> <?php echo (!$taken && $slot === $booking['time']) ? 'selected' : ''; ?>><?php echo date('g:i A', strtotime($slot)) . ($taken ? ' (not available)' : ''); ?></option>
                <?php } ?>
            </select>
            <p class="hint" id="slot-hint">Choose a barber and date to see the free times.</p>
        </div>
        <div class="field">
            <label for="notes">Notes (Haircut)</label>
            <textarea id="notes" name="notes" placeholder="Example: low fade, keep the top long"><?php echo htmlspecialchars($booking['notes']); ?></textarea>
        </div>
        <div class="actions">
            <a href="cart.php" class="btn outline"><i class="fas fa-arrow-left"></i> Back to cart</a>
            <button type="submit" name="submit" value="submit" class="btn">Continue to payment <i class="fas fa-arrow-right"></i></button>
        </div>
    </form>
</main>

<script>
// When the barber or date changes, grey out the times that are not free
const dateInput = document.getElementById('date');
const timeSelect = document.getElementById('time');
const hint = document.getElementById('slot-hint');

async function refreshSlots() {
    if (!dateInput.value) return;
    const barber = document.querySelector('input[name="barber"]:checked').value;
    const res = await fetch('slots.php?date=' + encodeURIComponent(dateInput.value) + '&barber=' + encodeURIComponent(barber));
    const data = await res.json();
    let free = 0;
    for (const opt of timeSelect.options) {
        if (!opt.value) continue;
        const taken = data.unavailable.includes(opt.value);
        opt.disabled = taken;
        opt.textContent = opt.textContent.replace(' (not available)', '') + (taken ? ' (not available)' : '');
        if (taken && opt.selected) timeSelect.value = '';
        if (!taken) free++;
    }
    if (data.closed) {
        hint.textContent = data.closed + ' Please choose another date.';
    } else {
        hint.textContent = free > 0
            ? free + ' time slot(s) still free.'
            : 'Fully booked. Please choose another date or barber.';
    }
}

dateInput.addEventListener('change', refreshSlots);
document.querySelectorAll('input[name="barber"]').forEach(r => r.addEventListener('change', refreshSlots));
refreshSlots();
</script>
</body>
</html>
