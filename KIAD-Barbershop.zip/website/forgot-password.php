<?php
include 'bootstrap.php';
include 'customer_lib.php';

// Customer asks the shop on WhatsApp; the owner resets it in Admin -> Customers
$who = trim($_GET['who'] ?? '');
if ($who !== '') {
    $message = "Hi KI'AD, I forgot my password for the booking website.\nMy username / email: " . mb_substr($who, 0, 100) . "\nPlease reset it for me. Thank you!";
    header("Location: " . whatsapp_link($conn, $message));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot password | KI'AD BARBER BOOKING SYSTEM</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="shop-style.css">
</head>
<body>
<header class="shop-nav">
    <a href="home.php" class="shop-logo"><img src="<?php echo htmlspecialchars(logo($conn)); ?>" alt="KI'AD Barbershop"></a>
    <nav>
        <a href="home.php">Home</a>
        <a href="Login.php">Log in</a>
    </nav>
</header>

<main class="page narrow">
    <h1 class="heading">forgot <span>password?</span></h1>
    <p class="sub">No problem. The shop will give you a temporary password.</p>

    <form method="get" class="panel">
        <h2><i class="fab fa-whatsapp"></i> Customers</h2>
        <ol class="forgot-steps">
            <li>Type your username or email below and tap the button. WhatsApp opens with a message to the shop.</li>
            <li>The shop replies with a <strong>temporary password</strong>.</li>
            <li>Log in with it, then choose your own new password.</li>
        </ol>
        <div class="field">
            <label for="who">Your username or email</label>
            <input id="who" name="who" required maxlength="100" autocomplete="username">
        </div>
        <button class="btn full"><i class="fab fa-whatsapp"></i> Ask the shop on WhatsApp</button>
    </form>

    <div class="panel">
        <h2><i class="fas fa-scissors"></i> Staff</h2>
        <p class="hint" style="font-size: 15px">Ask the owner. They can set a new password for you in <strong>Admin &rarr; Staff &rarr; Edit</strong>.</p>
    </div>

    <p class="hint" style="text-align: center">Remembered it? <a href="Login.php">Back to log in</a></p>
</main>
</body>
</html>
