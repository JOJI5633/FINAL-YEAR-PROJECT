<header class="shop-nav">
    <a href="home.php" class="shop-logo"><img src="<?php echo htmlspecialchars(logo($conn)); ?>" alt="KI'AD Barbershop"></a>
    <nav>
        <a href="home.php">Home</a>
        <a href="service.php">Services</a>
        <a href="cart.php" class="cart-link">
            <i class="fas fa-shopping-cart"></i> Cart
            <?php if (count($_SESSION['cart']) > 0) { ?>
            <span class="badge"><?php echo count($_SESSION['cart']); ?></span>
            <?php } ?>
        </a>
        <a href="my-bookings.php">My bookings</a>
        <a href="my-account.php" class="nav-user"><i class="fas fa-user"></i> Hi, <?php echo htmlspecialchars($_SESSION['cust_name']); ?></a>
        <a href="logout.php">Logout</a>
    </nav>
</header>
