// Log in / Sign up tabs: the box stays in place, only the form inside changes
const tabs = [...document.querySelectorAll('[role="tab"]')];

function showTab(name, focusForm) {
  tabs.forEach(tab => {
    const active = tab.id === 'tab-' + name;
    tab.setAttribute('aria-selected', active);
    tab.tabIndex = active ? 0 : -1;
    document.getElementById(tab.getAttribute('aria-controls')).hidden = !active;
  });
  if (focusForm) {
    document.querySelector('#panel-' + name + ' input:not([type=hidden])').focus();
  }
}

tabs.forEach(tab => {
  tab.addEventListener('click', () => showTab(tab.id.replace('tab-', ''), false));
  // left / right arrow keys move between the two tabs
  tab.addEventListener('keydown', (event) => {
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
    const other = tabs[(tabs.indexOf(tab) + 1) % tabs.length];
    showTab(other.id.replace('tab-', ''), false);
    other.focus();
  });
});

// "Create an account" / "Log in" links under each form
document.querySelectorAll('[data-tab]').forEach(link => {
  link.addEventListener('click', (event) => {
    event.preventDefault();
    showTab(link.dataset.tab, true);
  });
});

// Eye button: show or hide the password
document.querySelectorAll('.pass-toggle').forEach(button => {
  button.addEventListener('click', () => {
    const input = button.previousElementSibling;
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    button.setAttribute('aria-pressed', show);
    button.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    button.firstElementChild.className = show ? 'far fa-eye-slash' : 'far fa-eye';
  });
});

// Moving background: stay still for people who turned off animations
const video = document.querySelector('video.auth-bg');
if (video && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  video.pause();
}
