<?php
// Makes database/kiad_install.sql from THIS computer's database, ready to import on hosting.
// Keeps: every table, all settings, services and staff logins.
// Leaves out: customers, bookings, reviews, attendance, payroll, login attempts (test data).
// Command line only:
//
//   C:\xampp\php\php.exe tools\export-for-hosting.php

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit();
}

$config = require __DIR__ . '/../config.php';
include __DIR__ . '/../connection.php';

$keep_rows = ['setting', 'service', 'staff'];
// Secrets are made fresh on the new server, so this PC's QR/counter links can't be reused there
$blank_settings = ['attendance_secret', 'kiosk_key'];

$out = "-- ============================================================\n"
     . "--  KI'AD Barbershop booking system - CLEAN INSTALL\n"
     . "--  Made " . date('Y-m-d H:i') . " by tools/export-for-hosting.php\n"
     . "--  Import this ONE file into an empty database (phpMyAdmin -> Import).\n"
     . "--  It has every table, the settings, services and staff logins,\n"
     . "--  but no customers, bookings or other test data.\n"
     . "-- ============================================================\n\n"
     . "SET NAMES utf8mb4;\nSET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n\n";

$tables = array_column(mysqli_fetch_all(mysqli_query($conn, "SHOW TABLES"), MYSQLI_NUM), 0);
foreach ($tables as $table) {
    $create = mysqli_fetch_row(mysqli_query($conn, "SHOW CREATE TABLE `$table`"))[1];
    $out .= "DROP TABLE IF EXISTS `$table`;\n" . preg_replace('/ AUTO_INCREMENT=\d+/', '', $create) . ";\n\n";
}

$counts = [];
foreach ($keep_rows as $table) {
    $rows = mysqli_fetch_all(mysqli_query($conn, "SELECT * FROM `$table`"), MYSQLI_ASSOC);
    $counts[$table] = count($rows);
    foreach ($rows as $row) {
        if ($table === 'setting' && in_array($row['name'], $blank_settings)) {
            $row['value'] = '';
        }
        $values = array_map(function ($v) use ($conn) {
            return $v === null ? 'NULL' : "'" . mysqli_real_escape_string($conn, $v) . "'";
        }, array_values($row));
        $out .= "INSERT INTO `$table` (`" . implode('`, `', array_keys($row)) . "`) VALUES (" . implode(', ', $values) . ");\n";
    }
    $out .= "\n";
}

$file = __DIR__ . '/../database/kiad_install.sql';
file_put_contents($file, $out);
echo "Saved database/kiad_install.sql\n";
echo count($tables) . " tables, " . $counts['setting'] . " settings, " . $counts['service'] . " services, " . $counts['staff'] . " staff.\n";
echo "Upload it together with the images/ folder (service pictures, logo and QR live there).\n";
