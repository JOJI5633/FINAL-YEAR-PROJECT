<?php
// Emergency password reset for the owner (or any staff account) when nobody can log in.
// Runs ONLY from the command line on the computer/server where KI'AD is installed,
// never from a browser. Usage:
//
//   C:\xampp\php\php.exe tools\reset-password.php <username> <new password>
//   e.g.  C:\xampp\php\php.exe tools\reset-password.php admin MyNewPass123
//
// On cPanel hosting: open Terminal (or ask the host) and run: php tools/reset-password.php admin MyNewPass123

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit();
}

include __DIR__ . '/../connection.php';

[$script, $username, $password] = $argv + [null, '', ''];
$username = strtolower(trim($username));

if ($username === '' || strlen($password) < 6) {
    fwrite(STDERR, "Usage: php tools/reset-password.php <username> <new password (6+ characters)>\n");
    exit(1);
}

$stmt = mysqli_prepare($conn, "SELECT staff_id, name, role FROM staff WHERE username = ?");
mysqli_stmt_bind_param($stmt, 's', $username);
mysqli_stmt_execute($stmt);
$staff = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$staff) {
    fwrite(STDERR, "No staff account with username \"$username\". Staff accounts:\n");
    $result = mysqli_query($conn, "SELECT username, name, role, active FROM staff ORDER BY staff_id");
    while ($row = mysqli_fetch_assoc($result)) {
        fwrite(STDERR, "  - {$row['username']} ({$row['name']}, {$row['role']}" . ($row['active'] ? '' : ', disabled') . ")\n");
    }
    exit(1);
}

// New password, and switch the account back on in case it was disabled
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = mysqli_prepare($conn, "UPDATE staff SET password_hash = ?, active = 1 WHERE staff_id = ?");
mysqli_stmt_bind_param($stmt, 'si', $hash, $staff['staff_id']);
mysqli_stmt_execute($stmt);

echo "Done. {$staff['name']} ({$staff['role']}) can now log in as \"$username\" with the new password.\n";
