<?php
// Terms & Privacy Policy (text is edited in Admin -> Manage -> Settings)
include 'bootstrap.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms & Privacy | KI'AD BARBER BOOKING SYSTEM</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="shop-style.css">
</head>
<body>
<header class="shop-nav">
    <a href="home.php" class="shop-logo"><img src="<?php echo htmlspecialchars(logo($conn)); ?>" alt="KI'AD Barbershop"></a>
    <nav>
        <a href="home.php">Home</a>
        <a href="<?php echo isset($_SESSION['cust_id']) ? 'service.php' : 'Login.php'; ?>">Book now</a>
    </nav>
</header>

<main class="page narrow">
    <div class="panel policy" id="terms">
        <h2><i class="fas fa-file-contract"></i> Terms of booking</h2>
        <p><?php echo nl2br(htmlspecialchars(setting($conn, 'policy_terms'))); ?></p>
    </div>

    <div class="panel policy" id="privacy">
        <h2><i class="fas fa-user-shield"></i> Privacy policy</h2>
        <p><?php echo nl2br(htmlspecialchars(setting($conn, 'policy_privacy'))); ?></p>
    </div>

    <p class="hint" style="text-align: center">Questions? Contact us on
        <a href="https://wa.me/<?php echo htmlspecialchars(preg_replace('/\D/', '', setting($conn, 'whatsapp_number'))); ?>" target="_blank" rel="noopener">WhatsApp</a>.</p>
</main>
</body>
</html>
