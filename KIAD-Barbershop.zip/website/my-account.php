<?php
include 'shop_functions.php';

$must_change = !empty($_SESSION['must_change_password']);
$error = '';
$saved = false;

$stmt = mysqli_prepare($conn, "SELECT * FROM customer WHERE cust_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $cust_id);
mysqli_stmt_execute($stmt);
$customer = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = $_POST['current'] ?? '';
    $new = $_POST['new'] ?? '';

    if (!customer_password_ok($conn, $customer, $current)) {
        $error = $must_change ? 'The temporary password is wrong.' : 'Your current password is wrong.';
    } elseif (strlen($new) < 6) {
        $error = 'The new password must be at least 6 characters.';
    } elseif ($new !== ($_POST['confirm'] ?? '')) {
        $error = 'The two new passwords are not the same.';
    } elseif ($new === $current) {
        $error = 'Please choose a password different from the old one.';
    } else {
        set_customer_password($conn, $cust_id, $new, 0);
        unset($_SESSION['must_change_password']);
        $must_change = false;
        $saved = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My account | KI'AD BARBER BOOKING SYSTEM</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="shop-style.css">
</head>
<body>
<?php include 'customer-nav.php'; ?>

<main class="page narrow">
    <h1 class="heading">my <span>account</span></h1>

    <?php if ($must_change) { ?>
    <div class="alert"><i class="fas fa-key"></i> You logged in with a <strong>temporary password</strong> from the shop. Please choose your own password to continue.</div>
    <?php } ?>
    <?php if ($saved) { ?>
    <div class="alert"><i class="fas fa-check"></i> Password changed. Use your new password next time you log in.</div>
    <?php } ?>
    <?php if ($error) { ?>
    <div class="alert error"><i class="fas fa-circle-exclamation"></i> <?php echo htmlspecialchars($error); ?></div>
    <?php } ?>

    <div class="panel">
        <h2>Your details</h2>
        <ul class="summary">
            <li><span>Username</span><span><?php echo htmlspecialchars($customer['username']); ?></span></li>
            <li><span>Email</span><span><?php echo htmlspecialchars($customer['email']); ?></span></li>
        </ul>
        <p class="hint">You can log in with either your username or your email.</p>
    </div>

    <form method="post" class="panel">
        <?php echo csrf_field(); ?>
        <h2>Change password</h2>
        <div class="field">
            <label for="current"><?php echo $must_change ? 'Temporary password from the shop' : 'Current password'; ?></label>
            <input type="password" id="current" name="current" required autocomplete="current-password">
        </div>
        <div class="field">
            <label for="new">New password</label>
            <input type="password" id="new" name="new" minlength="6" required autocomplete="new-password">
            <p class="hint">At least 6 characters.</p>
        </div>
        <div class="field">
            <label for="confirm">New password again</label>
            <input type="password" id="confirm" name="confirm" minlength="6" required autocomplete="new-password">
        </div>
        <button class="btn full">Save new password</button>
    </form>

    <?php if (!$must_change) { ?>
    <div class="actions">
        <a href="my-bookings.php" class="btn outline"><i class="fas fa-calendar"></i> My bookings</a>
        <a href="service.php" class="btn">Make an appointment</a>
    </div>
    <?php } ?>
</main>
</body>
</html>
