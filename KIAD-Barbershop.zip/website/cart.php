<?php
include 'shop_functions.php';

// Add / remove a service, then go back to where the customer was
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['service_id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($action === 'add' && !in_array($id, $_SESSION['cart'])) {
        $check = mysqli_query($conn, "SELECT service_id FROM service WHERE service_id = $id");
        if (mysqli_num_rows($check) === 1) {
            $_SESSION['cart'][] = $id;
        }
    } elseif ($action === 'remove') {
        $_SESSION['cart'] = array_values(array_diff($_SESSION['cart'], [$id]));
    }

    if (($_POST['back'] ?? '') === 'service') {
        // keep the customer's search, if any
        $q = trim($_POST['q'] ?? '');
        header("Location: service.php" . ($q !== '' ? '?q=' . urlencode($q) : '') . "#service-$id");
    } else {
        header("Location: cart.php");
    }
    exit();
}

$items = cart_items($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart | KI'AD BARBER BOOKING SYSTEM</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="shop-style.css">
</head>
<body>
<?php include 'customer-nav.php'; ?>

<main class="page narrow">
    <?php render_steps(2); ?>
    <h1 class="heading">your <span>cart</span></h1>
    <p class="sub">Check your services before choosing a date and time.</p>

    <div class="panel">
        <?php if (count($items) === 0) { ?>
            <div class="empty">
                <i class="fas fa-shopping-cart"></i>
                <p>Your cart is empty.</p><br>
                <a href="service.php" class="btn">Choose a service</a>
            </div>
        <?php } else { ?>
            <?php foreach ($items as $item) { ?>
            <div class="cart-row">
                <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="">
                <div class="name"><?php echo htmlspecialchars($item['name']); ?></div>
                <div class="price"><?php echo rm($item['price']); ?></div>
                <form method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="service_id" value="<?php echo $item['service_id']; ?>">
                    <button class="btn danger small" name="action" value="remove" aria-label="Remove <?php echo htmlspecialchars($item['name']); ?>"><i class="fas fa-trash"></i></button>
                </form>
            </div>
            <?php } ?>
            <div class="total-row"><span>Total</span><span><?php echo rm(cart_total($items)); ?></span></div>
        <?php } ?>
    </div>

    <?php if (count($items) > 0) { ?>
    <div class="actions">
        <a href="service.php" class="btn outline"><i class="fas fa-plus"></i> Add more</a>
        <a href="date-time.php" class="btn">Continue <i class="fas fa-arrow-right"></i></a>
    </div>
    <?php } ?>
</main>
</body>
</html>
