<?php
include 'bootstrap.php';
include 'customer_lib.php';

// One login page for customers, staff and the owner.
// ?next= sends staff back to an admin page after logging in (e.g. an attendance scan)
$next = $_GET['next'] ?? '';
if (!preg_match('/^[a-z_]+\.php(\?[\w=&%.-]*)?$/', $next)) {
    $next = '';
}

// Already logged in
if ($next !== '' && isset($_SESSION['staff_id'])) {
    header("Location: admin/$next");
    exit;
}
if ($next === '' && isset($_SESSION['cust_id'])) {
    header("Location: home.php");
    exit;
}

$notice = '';
if (strpos($next, 'scan.php') === 0) {
    $notice = 'Staff: log in to save your attendance.';
} elseif (isset($_GET['disabled'])) {
    $notice = 'This staff account has been disabled. Please ask the owner.';
}

// Which form shows first: "Log in" or "Sign up"
$tab = ($_GET['tab'] ?? '') === 'signup' ? 'signup' : 'login';
$login_error = '';
$login_user = '';
$signup_error = '';
$signup = ['username' => '', 'email' => ''];

check_csrf();

// Too many wrong passwords in 15 minutes: stop checking for a while (stops password guessing)
function login_blocked($conn, $ip, $user) {
    $stmt = mysqli_prepare($conn, "SELECT
            SUM(username = ?) AS for_user,
            SUM(ip = ?) AS for_ip
        FROM login_attempt WHERE attempted_at > NOW() - INTERVAL 15 MINUTE AND (username = ? OR ip = ?)");
    mysqli_stmt_bind_param($stmt, 'ssss', $user, $ip, $user, $ip);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    return $row['for_user'] >= 5 || $row['for_ip'] >= 20;
}

function clear_login_attempts($conn, $user_key) {
    $stmt = mysqli_prepare($conn, "DELETE FROM login_attempt WHERE username = ?");
    mysqli_stmt_bind_param($stmt, 's', $user_key);
    mysqli_stmt_execute($stmt);
}

if (isset($_POST['login'])) {
    $tab = 'login';
    // Customers can type their email or their username
    $user = trim($_POST['user'] ?? '');
    $password = $_POST['password'] ?? '';
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $user_key = strtolower($user);
    $login_user = $user;

    if ($user === '' || $password === '') {
        $login_error = 'Please enter your username (or email) and password.';
    } elseif (login_blocked($conn, $ip, $user_key)) {
        $login_error = 'Too many wrong passwords. Please wait 15 minutes and try again, or use "Forgot password?".';
    } else {
        $stmt = mysqli_prepare($conn, "SELECT * FROM `customer` WHERE email = ? OR username = ? limit 1");
        mysqli_stmt_bind_param($stmt, 'ss', $user, $user);
        mysqli_stmt_execute($stmt);
        $user_data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if ($user_data && customer_password_ok($conn, $user_data, $password)) {
            // remember the customer, then go to home
            clear_login_attempts($conn, $user_key);
            session_regenerate_id(true);
            $_SESSION['cust_id'] = $user_data['cust_id'];
            $_SESSION['cust_name'] = $user_data['username'];

            // Logged in with a temporary password from the shop: choose a new one first
            if ($user_data['must_change_password']) {
                $_SESSION['must_change_password'] = true;
                header("Location: my-account.php");
                exit;
            }
            header("Location: home.php");
            exit;
        }

        // Not a customer? Staff can log in here too and go to the admin panel
        $stmt = mysqli_prepare($conn, "SELECT staff_id, password_hash, role FROM staff WHERE username = ? AND active = 1");
        mysqli_stmt_bind_param($stmt, 's', $user);
        mysqli_stmt_execute($stmt);
        $staff = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        if ($staff && password_verify($password, $staff['password_hash'])) {
            clear_login_attempts($conn, $user_key);
            session_regenerate_id(true);
            $_SESSION['staff_id'] = $staff['staff_id'];

            // Staff who haven't clocked in today go straight to the scanner
            $landing = 'index.php';
            if ($staff['role'] === 'staff') {
                $today = date('Y-m-d');   // Malaysian date, same as the attendance records
                $stmt = mysqli_prepare($conn, "SELECT 1 FROM attendance WHERE staff_id = ? AND work_date = ?");
                mysqli_stmt_bind_param($stmt, 'is', $staff['staff_id'], $today);
                mysqli_stmt_execute($stmt);
                if (!mysqli_fetch_row(mysqli_stmt_get_result($stmt))) {
                    $landing = 'attendance.php';
                }
            }
            header("Location: admin/" . ($next !== '' ? $next : $landing));
            exit;
        }

        // Wrong: remember it (and forget attempts older than a day)
        $stmt = mysqli_prepare($conn, "INSERT INTO login_attempt (ip, username) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, 'ss', $ip, $user_key);
        mysqli_stmt_execute($stmt);
        mysqli_query($conn, "DELETE FROM login_attempt WHERE attempted_at < NOW() - INTERVAL 1 DAY");
        $login_error = 'Wrong username/email or password.';
    }
} elseif (isset($_POST['signup'])) {
    $tab = 'signup';
    $signup = ['username' => trim($_POST['username'] ?? ''), 'email' => trim($_POST['email'] ?? '')];
    $password = $_POST['password'] ?? '';

    // Username and email must not belong to someone else (both are used to log in)
    $stmt = mysqli_prepare($conn, "SELECT username, email FROM customer WHERE username = ? OR email = ?");
    mysqli_stmt_bind_param($stmt, 'ss', $signup['username'], $signup['email']);
    mysqli_stmt_execute($stmt);
    $taken = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    // Staff log in on this page too, so customers can't take a staff username (e.g. "admin")
    $stmt = mysqli_prepare($conn, "SELECT staff_id FROM staff WHERE username = ?");
    mysqli_stmt_bind_param($stmt, 's', $signup['username']);
    mysqli_stmt_execute($stmt);
    if (mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))) {
        $taken = ['username' => $signup['username']];
    }

    if ($signup['username'] === '' || $signup['email'] === '' || $password === '') {
        $signup_error = 'Please fill in a username, your email and a password.';
    } elseif (strlen($signup['username']) > 50) {
        $signup_error = 'Please choose a shorter username (max 50 characters).';
    } elseif (!filter_var($signup['email'], FILTER_VALIDATE_EMAIL)) {
        $signup_error = 'Please enter a valid email.';
    } elseif ($taken && strcasecmp($taken['username'], $signup['username']) === 0) {
        $signup_error = 'That username is already taken, please choose another one.';
    } elseif ($taken) {
        $signup_error = 'That email already has an account. Please log in instead.';
    } elseif (strlen($password) < 6) {
        $signup_error = 'Password must be at least 6 characters.';
    } else {
        // Never store the password itself, only its hash
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "INSERT INTO customer (username, password, email) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, 'sss', $signup['username'], $hash, $signup['email']);
        mysqli_stmt_execute($stmt);
        // Show the log in form with the new username filled in (a refresh won't sign up twice)
        $_SESSION['signup_done'] = $signup['username'];
        header("Location: Login.php");
        exit;
    }
}

$signup_done = '';
if (isset($_SESSION['signup_done'])) {
    $signup_done = $login_user = $_SESSION['signup_done'];
    unset($_SESSION['signup_done']);
}

// Wallpaper chosen in Admin -> Settings -> Login page background
$bg = login_background($conn);

// Small real facts on the picture side: is the shop open today, and the star rating
$now = time();
$open_at = strtotime(date('Y-m-d') . ' ' . setting($conn, 'open_time'));
$close_at = strtotime(date('Y-m-d') . ' ' . setting($conn, 'close_time'));
if (closed_reason($conn, date('Y-m-d')) !== '') {
    $hours = ['closed', 'Closed today'];
} elseif ($now < $open_at) {
    $hours = ['soon', 'Opens today at ' . date('g:i A', $open_at)];
} elseif ($now < $close_at) {
    $hours = ['open', 'Open now &middot; until ' . date('g:i A', $close_at)];
} else {
    $hours = ['closed', 'Closed for today'];
}
$rating = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n, AVG(stars) AS avg FROM review"));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="theme-color" content="#0c0c0d">
  <title>Log in | KI'AD BARBER BOOKING SYSTEM</title>
  <link rel="icon" type="image/png" href="favicon-32x32.png">
  <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;1,600&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="Login-style.css">
</head>
<body>
<div class="auth <?php echo $bg['bg'] === 'plain' ? 'bg-plain' : ''; ?>" style="--dim: <?php echo $bg['dim'] / 100; ?>">

  <!-- Picture side: the wallpaper from Admin -> Settings -->
  <section class="auth-visual">
    <?php if ($bg['bg'] === 'video') { ?>
    <video class="auth-bg" src="background.mp4" poster="<?php echo LOGIN_BG_DEFAULT; ?>" autoplay muted loop playsinline aria-hidden="true"></video>
    <?php } elseif ($bg['bg'] !== 'plain') { ?>
    <div class="auth-bg is-photo" style="background-image: url('<?php echo htmlspecialchars($bg['bg']); ?>')"></div>
    <?php } ?>
    <div class="auth-shade"></div>

    <a href="home.php" class="auth-logo"><img src="<?php echo htmlspecialchars(logo($conn)); ?>" alt="KI'AD Barbershop home"></a>

    <div class="visual-copy">
      <p class="eyebrow"><span class="pole" aria-hidden="true"><span></span></span> KI'AD Barbershop</p>
      <p class="visual-title">Look sharp.<br><em>Book in seconds.</em></p>
      <ul class="perks">
        <li><i class="fas fa-user-check" aria-hidden="true"></i> Choose your own barber</li>
        <li><i class="far fa-clock" aria-hidden="true"></i> Pick a free time that suits you</li>
        <li><i class="fas fa-qrcode" aria-hidden="true"></i> Pay cash at the shop or scan QR</li>
      </ul>
      <div class="chips">
        <span class="chip"><span class="dot <?php echo $hours[0]; ?>" aria-hidden="true"></span> <?php echo $hours[1]; ?></span>
        <?php if ($rating['n'] > 0) { ?>
        <span class="chip"><i class="fas fa-star" aria-hidden="true"></i> <?php echo number_format($rating['avg'], 1); ?> &middot; <?php echo $rating['n']; ?> review<?php echo $rating['n'] == 1 ? '' : 's'; ?></span>
        <?php } ?>
      </div>
    </div>

    <p class="visual-foot"><i class="fas fa-location-dot" aria-hidden="true"></i> <?php echo htmlspecialchars(setting($conn, 'shop_address')); ?></p>
  </section>

  <!-- Form side -->
  <main class="auth-main">
    <a class="auth-home" href="home.php"><i class="fas fa-arrow-left" aria-hidden="true"></i> Back to home</a>

    <div class="auth-box">
      <div class="auth-tabs" role="tablist" aria-label="Log in or sign up">
        <button type="button" role="tab" id="tab-login" aria-controls="panel-login" aria-selected="<?php echo $tab === 'login' ? 'true' : 'false'; ?>" <?php echo $tab === 'login' ? '' : 'tabindex="-1"'; ?>>Log in</button>
        <button type="button" role="tab" id="tab-signup" aria-controls="panel-signup" aria-selected="<?php echo $tab === 'signup' ? 'true' : 'false'; ?>" <?php echo $tab === 'signup' ? '' : 'tabindex="-1"'; ?>>Sign up</button>
      </div>

      <div class="auth-panel" id="panel-login" role="tabpanel" aria-labelledby="tab-login" <?php echo $tab === 'login' ? '' : 'hidden'; ?>>
        <h1>Welcome <em>back</em></h1>
        <p class="auth-sub">Log in with your username or email.</p>
        <?php if ($signup_done) { ?>
        <p class="msg ok" role="status"><i class="fas fa-circle-check"></i> Account created! Enter your password to log in.</p>
        <?php } ?>
        <?php if ($notice) { ?>
        <p class="msg info"><i class="fas fa-circle-info"></i> <?php echo htmlspecialchars($notice); ?></p>
        <?php } ?>
        <?php if ($login_error) { ?>
        <p class="msg error" role="alert"><i class="fas fa-circle-exclamation"></i> <?php echo htmlspecialchars($login_error); ?></p>
        <?php } ?>
        <form method="post" action="">
          <?php echo csrf_field(); ?>
          <div class="field">
            <label for="login-user">Email or username</label>
            <div class="control">
              <i class="far fa-user" aria-hidden="true"></i>
              <input type="text" id="login-user" name="user" autocomplete="username" required autocapitalize="none" spellcheck="false"
                     placeholder="e.g. ahmad@gmail.com" value="<?php echo htmlspecialchars($login_user); ?>">
            </div>
          </div>
          <div class="field">
            <div class="label-row">
              <label for="login-pass">Password</label>
              <a href="forgot-password.php">Forgot password?</a>
            </div>
            <div class="control">
              <i class="fas fa-lock" aria-hidden="true"></i>
              <input type="password" id="login-pass" name="password" autocomplete="current-password" required placeholder="Your password" <?php echo $signup_done || $login_error ? 'autofocus' : ''; ?>>
              <button type="button" class="pass-toggle" aria-label="Show password" aria-pressed="false"><i class="far fa-eye"></i></button>
            </div>
          </div>
          <button type="submit" class="auth-btn" name="login" value="submit">Log in <i class="fas fa-arrow-right" aria-hidden="true"></i></button>
        </form>
        <p class="auth-switch">New to KI'AD? <a href="Login.php?tab=signup" data-tab="signup">Create an account</a></p>
      </div>

      <div class="auth-panel" id="panel-signup" role="tabpanel" aria-labelledby="tab-signup" <?php echo $tab === 'signup' ? '' : 'hidden'; ?>>
        <h1>Hello, <em>gentlemen</em></h1>
        <p class="auth-sub">Create a free account &mdash; it takes less than a minute.</p>
        <?php if ($signup_error) { ?>
        <p class="msg error" role="alert"><i class="fas fa-circle-exclamation"></i> <?php echo htmlspecialchars($signup_error); ?></p>
        <?php } ?>
        <form method="post" action="Login.php">
          <?php echo csrf_field(); ?>
          <div class="field">
            <label for="signup-user">Username</label>
            <div class="control">
              <i class="far fa-user" aria-hidden="true"></i>
              <input type="text" id="signup-user" name="username" maxlength="50" autocomplete="username" required autocapitalize="none" spellcheck="false"
                     placeholder="Choose a username" value="<?php echo htmlspecialchars($signup['username']); ?>">
            </div>
          </div>
          <div class="field">
            <label for="signup-email">Email</label>
            <div class="control">
              <i class="far fa-envelope" aria-hidden="true"></i>
              <input type="email" id="signup-email" name="email" autocomplete="email" required placeholder="you@example.com" value="<?php echo htmlspecialchars($signup['email']); ?>">
            </div>
          </div>
          <div class="field">
            <label for="signup-pass">Password</label>
            <div class="control">
              <i class="fas fa-lock" aria-hidden="true"></i>
              <input type="password" id="signup-pass" name="password" minlength="6" autocomplete="new-password" required placeholder="At least 6 characters">
              <button type="button" class="pass-toggle" aria-label="Show password" aria-pressed="false"><i class="far fa-eye"></i></button>
            </div>
          </div>
          <button type="submit" class="auth-btn" name="signup" value="1">Create account <i class="fas fa-arrow-right" aria-hidden="true"></i></button>
        </form>
        <p class="auth-switch">Already have an account? <a href="Login.php" data-tab="login">Log in</a></p>
      </div>
    </div>

    <?php include 'site-footer.php'; ?>
  </main>
</div>

<script src="Login-script.js"></script>
</body>
</html>
