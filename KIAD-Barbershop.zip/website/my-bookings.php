<?php
include 'shop_functions.php';

// Rate a finished haircut (once per booking)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['receipt_ID'] ?? 0);
    $stars = (int)($_POST['stars'] ?? 0);
    $comment = mb_substr(trim($_POST['comment'] ?? ''), 0, 500);

    $stmt = mysqli_prepare($conn, "SELECT r.barber_id FROM receipt r LEFT JOIN review v ON v.receipt_ID = r.receipt_ID
                                   WHERE r.receipt_ID = ? AND r.cust_id = ? AND r.job_status = 'done'
                                   AND r.barber_id IS NOT NULL AND v.review_id IS NULL");
    mysqli_stmt_bind_param($stmt, 'ii', $id, $cust_id);
    mysqli_stmt_execute($stmt);
    $booking = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($booking && $stars >= 1 && $stars <= 5) {
        $stmt = mysqli_prepare($conn, "INSERT IGNORE INTO review (receipt_ID, cust_id, barber_id, stars, comment) VALUES (?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, 'iiiis', $id, $cust_id, $booking['barber_id'], $stars, $comment);
        mysqli_stmt_execute($stmt);
        $_SESSION['review_thanks'] = true;
    }
    header("Location: my-bookings.php#booking-$id");
    exit();
}

$bookings = mysqli_fetch_all(mysqli_query($conn, "
    SELECT r.*, s.name AS barber, v.stars, v.comment,
           (SELECT GROUP_CONCAT(i.service_name SEPARATOR ', ') FROM receipt_item i WHERE i.receipt_ID = r.receipt_ID) AS services
    FROM receipt r
    LEFT JOIN staff s ON s.staff_id = r.barber_id
    LEFT JOIN review v ON v.receipt_ID = r.receipt_ID
    WHERE r.cust_id = " . (int)$cust_id . "
    ORDER BY r.date DESC, r.time DESC"), MYSQLI_ASSOC);

$thanks = !empty($_SESSION['review_thanks']);
unset($_SESSION['review_thanks']);

function booking_state($r) {
    if ($r['job_status'] === 'cancelled') return ['bad', 'Cancelled'];
    if ($r['payment_status'] === 'rejected') return ['bad', 'Payment rejected'];
    if ($r['job_status'] === 'done') return ['good', 'Done'];
    if ($r['payment_status'] === 'pending') return ['wait', 'Waiting for payment check'];
    return ['wait', 'Booked'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My bookings | KI'AD BARBER BOOKING SYSTEM</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="shop-style.css">
</head>
<body>
<?php include 'customer-nav.php'; ?>

<main class="page narrow">
    <h1 class="heading">my <span>bookings</span></h1>
    <p class="sub">After your haircut, tell us how your barber did.</p>

    <?php if ($thanks) { ?>
    <div class="alert"><i class="fas fa-heart"></i> Thank you for your review!</div>
    <?php } ?>

    <?php if (count($bookings) === 0) { ?>
    <div class="panel empty">
        <i class="fas fa-calendar"></i>
        <p>You have no bookings yet.</p><br>
        <a href="service.php" class="btn">Make an appointment</a>
    </div>
    <?php } ?>

    <?php foreach ($bookings as $r) {
        [$state, $label] = booking_state($r); ?>
    <div class="panel booking-card" id="booking-<?php echo $r['receipt_ID']; ?>">
        <div class="booking-top">
            <div>
                <div class="booking-date"><?php echo date('D, j M Y', strtotime($r['date'])); ?> &middot; <?php echo date('g:i A', strtotime($r['time'])); ?></div>
                <div class="booking-what"><?php echo htmlspecialchars($r['services'] ?? $r['notes']); ?></div>
                <div class="hint"><?php echo $r['barber'] ? 'Barber: ' . htmlspecialchars($r['barber']) : ''; ?><?php echo $r['total'] !== null ? ' &middot; ' . rm($r['total']) : ''; ?></div>
            </div>
            <span class="state <?php echo $state; ?>"><?php echo $label; ?></span>
        </div>

        <?php if ($r['stars']) { ?>
        <div class="my-review">
            <span class="stars-show" role="img" aria-label="<?php echo $r['stars']; ?> out of 5 stars"><?php echo str_repeat('<i class="fas fa-star"></i>', $r['stars']) . str_repeat('<i class="far fa-star"></i>', 5 - $r['stars']); ?></span>
            <?php if ($r['comment'] !== '') { ?><span>&ldquo;<?php echo htmlspecialchars($r['comment']); ?>&rdquo;</span><?php } ?>
        </div>
        <?php } elseif ($r['job_status'] === 'done' && $r['barber_id']) { ?>
        <form method="post" class="rate-form">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="receipt_ID" value="<?php echo $r['receipt_ID']; ?>">
            <fieldset>
                <legend>Rate <?php echo htmlspecialchars($r['barber']); ?></legend>
                <div class="star-input">
                    <?php for ($n = 5; $n >= 1; $n--) { ?>
                    <input type="radio" id="s<?php echo $r['receipt_ID'] . '-' . $n; ?>" name="stars" value="<?php echo $n; ?>" required>
                    <label for="s<?php echo $r['receipt_ID'] . '-' . $n; ?>" title="<?php echo $n; ?> star<?php echo $n > 1 ? 's' : ''; ?>"><i class="fas fa-star"></i><span class="sr-only"><?php echo $n; ?> stars</span></label>
                    <?php } ?>
                </div>
            </fieldset>
            <div class="field">
                <label for="c<?php echo $r['receipt_ID']; ?>">Comment (optional)</label>
                <textarea id="c<?php echo $r['receipt_ID']; ?>" name="comment" maxlength="500" placeholder="How was your haircut?"></textarea>
            </div>
            <button class="btn small">Send review</button>
        </form>
        <?php } ?>

        <div class="booking-links"><a href="Receipt.php?receiptID=<?php echo $r['receipt_ID']; ?>">View receipt</a></div>
    </div>
    <?php } ?>
</main>
</body>
</html>
